//
//  AppDelegate.m
//  TRProject
//
//  Created by yingxin on 16/7/10.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "AppDelegate.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "AppDelegate+LWD.h"
#import "LoginViewController.h"
#import "JstTabBarViewController.h"



#import "TestViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (UIWindow *)window {
    if(_window == nil) {
        _window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
        [_window makeKeyAndVisible];
        //_window.rootViewController = [LoginViewController new];
        //直接跳转到首页
        _window.rootViewController = [JstTabBarViewController new];
        //测试VC
        //_window.rootViewController = [TestViewController new];
    }
    return _window;
}
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [self configApplication:launchOptions];
    
    [self window];
    return YES;
}


@end
