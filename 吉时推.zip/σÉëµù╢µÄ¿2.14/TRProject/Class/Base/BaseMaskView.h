//
//  FaceView.h
//  自定义FaceView
//
//  Created by tarena on 16/5/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface BaseMaskView : UIView
/* 无网络蒙层视图 */
@property(nonatomic,strong)UIImageView * wifiImg;
@property(nonatomic,strong)UILabel * networkLab;
@property(nonatomic,strong)UILabel * infoLab;
@property(nonatomic,strong)UIButton * bufferBtn;


@property (nonatomic, strong) void(^bufferHandler)();
@end
