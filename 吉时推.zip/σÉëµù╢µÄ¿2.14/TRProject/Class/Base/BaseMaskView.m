//
//  FaceView.m
//  自定义FaceView
//
//  Created by tarena on 16/5/5.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import "BaseMaskView.h"
@implementation BaseMaskView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
    }
    return self;
}

- (UIImageView *) wifiImg {
    if(_wifiImg == nil) {
        _wifiImg = [[UIImageView alloc] init];
        _wifiImg.image = [UIImage imageNamed:@"baseNetwork"];
        [self addSubview:_wifiImg];
        [_wifiImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.3);
            make.size.equalTo(CGSizeMake(63, 50));
        }];
    }
    return _wifiImg;
}

- (UILabel *) networkLab {
    if(_networkLab == nil) {
        _networkLab = [[UILabel alloc] init];
        _networkLab.font = [UIFont systemFontOfSize:17];
        _networkLab.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_networkLab];
        [_networkLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.wifiImg.mas_bottom).equalTo(10);
            make.centerX.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 30));
        }];
    }
    return _networkLab;
}

- (UILabel *) infoLab {
    if(_infoLab == nil) {
        _infoLab = [[UILabel alloc] init];
        _infoLab.font = [UIFont systemFontOfSize:13];
        _infoLab.textAlignment = NSTextAlignmentCenter;
        _infoLab.text = @"请检查您的网络";
        [self addSubview:_infoLab];
        [_infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.networkLab.mas_bottom).equalTo(10);
            make.centerX.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 30));
        }];

    }
    return _infoLab;
}

- (UIButton *) bufferBtn {
    if(_bufferBtn == nil) {
        _bufferBtn = [[UIButton alloc] init];
        [_bufferBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [_bufferBtn setTitle:@"重新加载" forState:UIControlStateNormal];
        _bufferBtn.layer.borderWidth = 1.0;
        _bufferBtn.layer.borderColor = [UIColor blackColor].CGColor;
        _bufferBtn.layer.masksToBounds = YES;
        [_bufferBtn bk_addEventHandler:^(id sender) {
            !self.bufferHandler ?: self.bufferHandler();
        } forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:_bufferBtn];
        [_bufferBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.infoLab.mas_bottom).equalTo(10);
            make.centerX.equalTo(0);
            make.size.equalTo(CGSizeMake(80, 30));
        }];
    }
    return _bufferBtn;
}


@end
