//
//  BaseNetworking.h
//  TRProject
//
//  Created by tarena on 16/7/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseNetworking : NSObject

//网络请求
+ (id)GET:(NSString *)path parameters:(NSDictionary *)parameters completionHandler:(void(^)(id repsonseObj, NSError *error))completionHandler;

+ (id)POST:(NSString *)path parameters:(NSDictionary *)parameters completionHandler:(void(^)(id repsonseObj, NSError *error))completionHandler;



//上传图片到服务器
/**
 *  李伟东
 *
 *  @param path              上传图片url路径
 *  @param parameters        上传图片url的参数值
 *  @param imgData            图片转化的data数据
 *  @param parmsKey          服务器的kvc的key
 *  @param completionHandler 回调
 *
 *  @return nil
 */
+ (id)POSTFile:(NSString *)path parameters:(NSDictionary *)parameters Data:(NSData *)imgData ParmsKey:(NSString *)parmsKey completionHandler:(void(^)(id repsonseObj, NSError *error))completionHandler;


@end













