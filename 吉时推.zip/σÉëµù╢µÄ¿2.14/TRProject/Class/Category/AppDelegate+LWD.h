//
//  AppDelegate+LWD.h
//  GameLive
//
//  Created by apple on 16/7/29.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "AppDelegate.h"


@interface AppDelegate (LWD) 
- (void)configApplication:(NSDictionary *)options;



@end
