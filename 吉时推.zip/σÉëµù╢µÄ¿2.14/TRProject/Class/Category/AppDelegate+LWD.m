//
//  AppDelegate+LWD.m
//  GameLive
//
//  Created by apple on 16/7/29.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "AppDelegate+LWD.h"
#import "AFNetworkActivityIndicatorManager.h"

@implementation AppDelegate (LWD)
- (void)configApplication:(NSDictionary *)options
{
    
    //枚举值一共两个, 一个屏幕边缘返回, 一个只要滑动就返回
    [MLTransition validatePanBackWithMLTransitionGestureRecognizerType:MLTransitionGestureRecognizerTypeScreenEdgePan];
    
    [AFNetworkActivityIndicatorManager sharedManager].enabled = YES;
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        NSLog(@"%@", AFStringFromNetworkReachabilityStatus(status));
    }];
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];

    //初始化第三方SDK
    [self initSDK];
}
- (void)initSDK{
    
    [self setThirdLogin];
    [self setShare];
    [self setBaiduSDK];
}
-(void)setBaiduSDK
{
        _mapManager = [[BMKMapManager alloc]init];
        NSString *mapKey = @"gZUr0KsT9N4PhsI9ncGUQW6VG2XDXy1s";
    
        // 如果要关注网络及授权验证事件，请设定generalDelegate参数
        BOOL ret = [_mapManager start:mapKey generalDelegate:nil];
        if (ret) {
            NSLog(@"百度引擎设置成功！");
        }else {
             NSLog(@"manager start failed!");
        }
}
-(void)setShare
{
    //三方分享
        //3ee3f64c74b2
        [ShareSDK registerApp:@"3ee3f64c74b2"
    
              activePlatforms:@[
                                @(SSDKPlatformTypeWechat),
                                @(SSDKPlatformTypeQQ),
                                @(SSDKPlatformTypeSinaWeibo),
                                @(SSDKPlatformTypeCopy),
                                ]
                     onImport:^(SSDKPlatformType platformType)
         {
             switch (platformType)
             {
                 case SSDKPlatformTypeWechat:
                     [ShareSDKConnector connectWeChat:[WXApi class]];
                     break;
                 case SSDKPlatformTypeQQ:
                     [ShareSDKConnector connectQQ:[QQApiInterface class] tencentOAuthClass:[TencentOAuth class]];
                     break;
                 case SSDKPlatformTypeSinaWeibo:
                     [ShareSDKConnector connectWeibo:[WeiboSDK class]];
                     break;
                 default:
                     break;
             }
         }
              onConfiguration:^(SSDKPlatformType platformType, NSMutableDictionary *appInfo)
         {
    
             switch (platformType)
             {
                 case SSDKPlatformTypeWechat:
                     /*wx945b58aef3a271f0   0ae78dd42761fd9681b04833c79a857b
                      如下是本人的微信生成的ID和秘钥*/
                     [appInfo SSDKSetupWeChatByAppId:@"wx1a479f8f023bb82b"
                                           appSecret:@"d03169220634ddf032c3d80524236ab0"];
                     break;
                 case SSDKPlatformTypeQQ:
                     /*1104539912      eFVgRits2fqf36Jf
                      如下是本人腾讯开放平台生成的ID和秘钥*/
                     [appInfo SSDKSetupQQByAppId:@"1105758399"
                                          appKey:@"KHJkhDWPrQI3LBji"
                                        authType:SSDKAuthTypeBoth];
                     break;
    
                 case SSDKPlatformTypeSinaWeibo:
                     /*568898243      38a4f8204cc784f81f9f0daaf31e02e3  http://www.sharesdk.cn
                      如下是本人新浪微博开放平台生成的KEY和秘钥*/
                     //设置新浪微博应用信息,其中authType设置为使用SSO＋Web形式授权
                     [appInfo SSDKSetupSinaWeiboByAppKey:@"2019668195"
                                               appSecret:@"1d71d6dc997e5aff84ab550316d3654f"
                                             redirectUri:@"http://www.sharesdk.cn"
                                                authType:SSDKAuthTypeBoth];
                     break;
                 default:
                     break;
             }
         }];
}
-(void)setThirdLogin
{
        /**三方登陆的信息设置*/
        [ShareSDK registerApp:@"315c496335fa44"
    
    
              activePlatforms:@[
                                @(SSDKPlatformTypeSinaWeibo),
                                @(SSDKPlatformTypeWechat)
                                ]
                     onImport:^(SSDKPlatformType platformType)
         {
             switch (platformType)
             {
                 case SSDKPlatformTypeWechat:
                     [ShareSDKConnector connectWeChat:[WXApi class]];
                     break;
    
                 case SSDKPlatformTypeSinaWeibo:
                     [ShareSDKConnector connectWeibo:[WeiboSDK class]];
                     break;
                 default:
                     break;
             }
         }
              onConfiguration:^(SSDKPlatformType platformType, NSMutableDictionary *appInfo)
         {
    
             switch (platformType)
             {
                 case SSDKPlatformTypeSinaWeibo:
                     //设置新浪微博应用信息,其中authType设置为使用SSO＋Web形式授权
                     [appInfo SSDKSetupSinaWeiboByAppKey:@"2019668195"
                                               appSecret:@"1d71d6dc997e5aff84ab550316d3654f"
                                             redirectUri:@"http://itunes.apple.com/cn/app/ran-wen-pai+/id1151352318?mt=8"
                                                authType:SSDKAuthTypeBoth];
                     break;
                 case SSDKPlatformTypeWechat:
                     //wx1a479f8f023bb82b   d03169220634ddf032c3d80524236ab0
                     //wx6728c484bd5dc177   91e08324071299966e76eeea9b5c1161
                     [appInfo SSDKSetupWeChatByAppId:@"wx6728c484bd5dc177"
                                           appSecret:@"91e08324071299966e76eeea9b5c1161"];
                     break;
                 default:
                     break;
             }
         }];
}

- (void)applicationDidEnterBackground:(UIApplication *)application{}
- (void)applicationWillEnterForeground:(UIApplication *)application{}
- (void)applicationWillResignActive:(UIApplication *)application {}
- (void)applicationDidBecomeActive:(UIApplication *)application {}
- (void)applicationWillTerminate:(UIApplication *)application {
    //卸载前清空缓存
    NSString *docPath = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject;
    NSError *error = nil;
    [[NSFileManager defaultManager] removeItemAtPath:docPath error:&error];
}
@end
