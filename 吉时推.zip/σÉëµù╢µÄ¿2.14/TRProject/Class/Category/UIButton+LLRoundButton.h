//
//  UIButton+LLRoundButton.h
//  酷游
//
//  Created by tarena on 15/12/9.
//  Copyright © 2015年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (LLRoundButton)
- (void) setRoundLayer;
@end
