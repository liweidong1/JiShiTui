//
//  ChinaCharaViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/7.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "ChinaCharaViewController.h"

@interface ChinaCharaViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)UIWebView *webView;
@end


@implementation ChinaCharaViewController
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
}

@end
