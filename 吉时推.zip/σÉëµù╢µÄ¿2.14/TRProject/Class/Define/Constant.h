//
//  Constant.h
//  TRProject
//
//  Created by yingxin on 16/7/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#ifndef Constant_h
#define Constant_h

//存放常用宏定义
//存放常用宏定义
#define bgColor(r,g,b) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1.0]
#define jRGBA(r, g, b, a) ([UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a])
#define gameWidth [UIScreen mainScreen].bounds.size.width
#define gameHeight [UIScreen mainScreen].bounds.size.height
// 弱引用
#define JSTWeakSelf __weak typeof(self) weakSelf = self;

/** 状态栏高度*/
#define STATUSBAR_HEIGHT 20
/** 导航栏加状态栏高度*/
#define TOPLAYOUT_HEIGHT 64
/** 屏幕高度*/
#define SCREEN_HEIGHT [UIScreen mainScreen].bounds.size.height
/** 屏幕宽度*/
#define SCREEN_WIDTH [UIScreen mainScreen].bounds.size.width
#define IS_IPHONE_4_SCREEN SCREEN_WIDTH == 320.0f && SCREEN_HEIGHT == 480.0f
#define IS_IPHONE_5_SCREEN SCREEN_WIDTH == 320.0f && SCREEN_HEIGHT == 568.0f
#define IS_IPHONE_6_SCREEN SCREEN_WIDTH == 375.0f && SCREEN_HEIGHT == 667.0f
#define IS_IPHONE_6PLUS_SCREEN SCREEN_WIDTH == 414.0f && SCREEN_HEIGHT == 736.0f
/** 获得当前设备的类型,返回值4为IPONE4设备,5为IPONE5及5S设备,6为IPHONE6及6S设备,7为IPHONE6PLUS及6SPLUS设备,0为其它设备*/
#define CURRENT_DEVICE \
({ \
int type = 0;\
if (IS_IPHONE_4_SCREEN) { \
type = 4; \
} else if (IS_IPHONE_5_SCREEN) { \
type = 5; \
} else if (IS_IPHONE_6_SCREEN){ \
type = 6; \
} else if (IS_IPHONE_6PLUS_SCREEN){ \
type = 7; \
} else {\
type = 0;\
}\
type;\
}\
)



///////////////////////=========== 验证字符串是否为空
#define isStr(obj) ((obj) && ![(obj) isKindOfClass:[NSNull class]] && ![obj isEqualToString:@"(null)"]  && obj.length != 0)?1:0


/** 注册微博应用,获取appKey 等信息*/
#define sinaAppKey @"2019668195"
#define sinaSecret  @"1d71d6dc997e5aff84ab550316d3654f"
//回调地址
#define REDIRECT_URI @"http://www.tedu.cn"

//微信SDK头文件
//微信
#define APP_ID @"wx6728c484bd5dc177"//开趴
#define APP_SECRET @"91e08324071299966e76eeea9b5c1161"


#endif /* Constant_h */
