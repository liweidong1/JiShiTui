//
//  RequestPath.h
//  TRProject
//
//  Created by yingxin on 16/7/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#ifndef RequestPath_h
#define RequestPath_h

//存放请求路径
#define jstURL @"http://api.51jishitui.com"
//登录注册 验证码
#define jstRegister @"/Register?name=%@&pass=%@"
#define jstLogin @"/Login?name=%@&pass=%@"
#define jstSMS @"/SMS?phone=%@"
#define jstTest @"/Register?name=18610361457&pass=123"
/**
 *  首页
 *
 *  @return  导航栏数据:定位地点 城市切换   头部滚动  中部滚动图标    天气    为您优选
 */
#define jstAddressPath @"/City?%@"
#define jstCitysPath @"/Citys?id=%@"
#define jstCitysSubTableViewPath @"/Coords?id=%@"
#define jstSearchPath @"/Search?name=%@&page=%ld"
#define jstCoordMapPath @"/Map?cid=4"


#define jstBanner @"/Banner?lng=%@,%@"
#define jstNavScrollBannerPath @"/Ico"
/**
 *  天气接口发通知到请求类，然后改变请求的方式：不带基类
 */
#define jstWeatherPathbase @"http://api.worldweatheronline.com/free/v2/weather.ashx?q=%@,%@&num_of_days=5&format=json&tp=6&key=24e50e714f4fccf1911a8b2d23637"
#define jstSelectFirst @"/Gselect?lat=%@&lng=%@&page=%ld"
/**
 *  首页横向滚动商家页面接口
 *
 *  @return  商家页    关注信息接口   关注接口  取消关注接口    商家详情   回复评论  发送评论   添加到购物车 购物车页面   增减购物车上商品数量   删除购物车数据
 *   参数说明： id 为商家注册登录时返回的“uid”数据
 */
#define jstNavScrollShopPath @"/Shop?id=1&page=%ld"
#define jstNavScrollShopayAttentionInfoPath @"/Statu?id=1&uid=2"
#define jstNavScrollShopayAttentionPath @"/Attention?id=1&uid=2"
#define jstNavScrollShopDetailPath @"/Product?pid=%ld&lat=40.074074&lng=116.311492&uid=1&page=%ld"
#define jstNavScrollShopDetailReplyPath @"/Replys?cid=%ld&page=%ld"
#define jstNavScrollShopDetailSendReplyPath @"/Reply?parentid=%ld&uid=%ld&content=%@"
#define jstNavScrollShopCarAddPath @"/Caradd?uid=%ld&pid=%ld"
#define jstNavScrollShopCarPath @"/Car?uid=%ld"
#define jstNavScrollShopCarAddJianPath @"/Carchange?id=%ld&num=%ld"
#define jstNavScrollShopDeletePath @"/Cardel?id=%ld"
#define jstNavScrollShopOrderPath @"/Buy?uid=%ld&pid=%ld&info=2&cid=%@"


/**
 *  我的
 *
 *  @return  个人信息(查询服务器数据)接口     个人信息修改的选择城市接口  个人信息提交修改  个人信息修改的绑定商家接口   我要开店类型选择接口   个人订单  我关注的店铺   广告推广1所属商圈  1商品修列表 2 商品修改详情  1粉丝列表 2粉丝详情   1店面广告查询 2店面广告修改
 */
#define jstMepersonShowInfoPath @"/Users?uid=%ld"
#define jstMepersonInfoChooseCityPath @"/Ucity"
#define jstMepersonInfoPath @"/Update?"
#define jstMepersonInfoProductBundingPath @"/Udetail?lat=%@&lng=%@&page=%ld"

#define jstMepersonInfoShopStylePath @"/Stype"

#define jstMeOrderPath @"/Olist?uid=%ld"

#define jstMePayAttentionProductPath @"/Ugz?uid=%ld"

#define jstMeAdCoordPath @"/Adsq"

#define jstMeProductReviseListPath @"/Plist?uid=%ld"
#define jstMeProductReviseDetailPath @"/Pdetail?pid=%ld"
#define jstMeFansListPath @"/Uflist?uid=%ld"
#define jstMeFansOrderProductPath @"/Ufdetail?uid=%ld&id=%ld"

#define jstAlterShopAdPath @"/Sbanner?uid=%ld"


/**
 *  测试图片上传  和文本上传到服务器http://www.zhdp.com/Update?content=aa
 */
#define jstUpdatePath @"/Update?"

#endif /* RequestPath_h */
