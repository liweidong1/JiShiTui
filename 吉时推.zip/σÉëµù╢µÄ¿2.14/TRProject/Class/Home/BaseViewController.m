//
//  BaseViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewController.h"


@interface BaseViewController ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIPageControl* pc;
@property (nonatomic) NSArray<UIImage *> *imageList;
@end

@implementation BaseViewController
- (NSArray<UIImage *> *)imageList{
    if (!_imageList) {
        NSArray *imageNames = @[@"header1", @"header2", @"header3", @"header4"];
        NSMutableArray *tmpArr = [NSMutableArray new];
        [imageNames enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [tmpArr addObject:[UIImage imageNamed:obj]];
        }];
        self.imageList = tmpArr.copy;
    }
    return _imageList;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
    // Do any additional setup after loading the view from its nib.
    //配置滚动视图
    [self setUpScrollView];
    //配置分页界面
    [self setUpPageController];
    
}
//配置滚动视图
-(void)setUpScrollView
{
    //1创建滚动视图
    UIScrollView* sv=[[UIScrollView alloc]init];
    //2设置可见区域=view的
    sv.frame=CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_WIDTH * 615 / 1125);
    //设置滚动视图的代理为当前控制器*******************************************************************************11111
    //代理就负责响应滚动视图发出的各种消息
    sv.delegate=self;
    
    
    
    //2.1想滚动视图中添加多个子视图
    for(int i=0;i<4;i++)
    {
//        //格式化出图片名称
//        NSString* imageName=[NSString stringWithFormat:@"welcome%d.png",i+1];
//        //2.11创建一个视图对象
        UIImageView* iv=[[UIImageView alloc]initWithImage:self.imageList[i]];
        //2.12设置图片视图的位置大小
        //声明了一个结构体的变量，其中xywh初始化为0
        CGRect iFrame=CGRectZero;
        iFrame.origin=CGPointMake(i*sv.bounds.size.width, 0);
        iFrame.size=sv.frame.size;//等同于iFrame.size=sv.bounds.size;
        iv.frame=iFrame;
        
        
        //2.2将图片添加到滚动视图
        [sv addSubview:iv];
    }
    
    
    
    //2.3设置子视图的内容大小
    sv.contentSize=CGSizeMake(4*sv.bounds.size.width, sv.bounds.size.width * 615 / 1125);
    //配置滚动视图到达边缘不弹跳*********************************************************
    sv.bounces=NO;
    ////配置滚动视图整页跳动
    sv.pagingEnabled=YES;
    
    //配置滚动视图不显示水平滚动条
    
    sv.showsHorizontalScrollIndicator=NO;
    
    
    
    //3添加到view
    [self.view addSubview:sv];
    
    
    
    
}
-(void)setUpPageController
{
    //1创建pagecontroller的实例
    UIPageControl* pc=[[UIPageControl alloc]init];
    self.pc=pc;
    //2设置frame
    pc.frame=CGRectMake(0, SCREEN_WIDTH * 615 / 1125+4, self.view.bounds.size.width, 30);
    //颜色
    //pc.backgroundColor=[UIColor yellowColor];
    //3添加控制器view
    [self.view addSubview:pc];
    //4配置pagecontroller
    pc.numberOfPages=4;
    //5配置提示符颜色
    pc.pageIndicatorTintColor=[UIColor blackColor];
    //6配置选中的提示符的颜色
    pc.currentPageIndicatorTintColor=[UIColor redColor];
    //关闭原点与用户的交互
    pc.userInteractionEnabled=NO;
    
    
    
}

#pragma - UIScrollViewDelegate 协议
- (void)scrollViewDidScroll:(UIScrollView *)scrollView//**************************************************3333333333
{
    //    NSLog(@"%@",NSStringFromCGPoint(scrollView.contentOffset));
    //round函数的作用是四舍五入
    
    int index=round(scrollView.contentOffset.x/self.view.bounds.size.width);
    self.pc.currentPage=index;
    
    
    
}









@end
