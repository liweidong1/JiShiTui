//
//  AddressModel.m
//  TRProject
//
//  Created by liweidong on 16/12/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "AddressModel.h"

@implementation AddressModel


@end



