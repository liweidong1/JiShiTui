//
//  HomeHeaderModel.h
//  TRProject
//
//  Created by liweidong on 16/12/15.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class HeaderDataModel;
@interface HomeHeaderModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<HeaderDataModel *> *data;

@end
@interface HeaderDataModel : NSObject

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, copy) NSString *link_addr;

@end

