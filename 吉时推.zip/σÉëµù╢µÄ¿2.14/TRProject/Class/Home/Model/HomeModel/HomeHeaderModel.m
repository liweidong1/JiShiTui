//
//  HomeHeaderModel.m
//  TRProject
//
//  Created by liweidong on 16/12/15.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeHeaderModel.h"

@implementation HomeHeaderModel
//+ (NSDictionary *)objectClassInArray{
//    return @{@"data" : [Data class]};
//}
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
   return @{@"data" : [HeaderDataModel class]};
}

@end



@implementation HeaderDataModel
//+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
//    return @{@"data": @"datas" };
//}
@end


