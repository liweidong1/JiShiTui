//
//  HomeOtherModel.h
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class HomeOtherDataModel;
@interface HomeOtherModel : NSObject

//@property (nonatomic, strong) Datas *datas;

@property (nonatomic, assign) NSInteger status;

//
//@end

//@interface Datas : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<HomeOtherDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface HomeOtherDataModel : NSObject

@property (nonatomic, copy) NSString *lng;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, copy) NSString *lat;

@property (nonatomic, copy) NSString *juli;
@property (nonatomic, copy) NSString *addr;
@end

