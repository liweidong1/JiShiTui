//
//  HomeOtherModel.m
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeOtherModel.h"

@implementation HomeOtherModel
+(NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass
{
    return @{@"data" : [HomeOtherDataModel class]};
}
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper
{
    return @{@"data" : @"datas.data"};
}
@end

@implementation HomeOtherDataModel

@end


