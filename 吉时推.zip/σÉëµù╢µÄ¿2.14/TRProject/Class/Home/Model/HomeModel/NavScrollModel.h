//
//  NavScrollModel.h
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Nav;
@interface NavScrollModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<Nav *> *nav;

@end

@interface Nav : NSObject

@property (nonatomic, copy) NSString *bname;

@property (nonatomic, copy) NSString *blogo;

@end

