//
//  NavScrollModel.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "NavScrollModel.h"

@implementation NavScrollModel
+(NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass
{
    return @{@"nav" : [Nav class]};
}
@end
@implementation Nav

@end

