//
//  WeatherModel.h
//  中银鞍山社保
//
//  Created by liweidong on 16/9/7.
//  Copyright © 2016年 董攀立. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Request,Current_Condition,Weatherdesc,Weathericonurl,Weather,Hourly,Weatherdesc,Weathericonurl,Astronomy;
@interface WeatherModel : NSObject

//@property (nonatomic, strong) Data *data;
//
//@end
//@interface Data : NSObject

@property (nonatomic, strong) NSArray<Request *> *request;

@property (nonatomic, strong) NSArray<Current_Condition *> *current_condition;

@property (nonatomic, strong) NSArray<Weather *> *weather;

@end

@interface Request : NSObject

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *query;

@end

@interface Current_Condition : NSObject

@property (nonatomic, copy) NSString *windspeedKmph;

@property (nonatomic, copy) NSString *winddirDegree;

@property (nonatomic, copy) NSString *winddir16Point;

@property (nonatomic, copy) NSString *pressure;

@property (nonatomic, copy) NSString *humidity;

@property (nonatomic, copy) NSString *FeelsLikeF;

@property (nonatomic, copy) NSString *FeelsLikeC;

@property (nonatomic, copy) NSString *temp_F;

@property (nonatomic, copy) NSString *cloudcover;

@property (nonatomic, copy) NSString *observation_time;

@property (nonatomic, strong) NSArray<Weatherdesc *> *weatherDesc;

@property (nonatomic, copy) NSString *visibility;

@property (nonatomic, copy) NSString *precipMM;

@property (nonatomic, copy) NSString *windspeedMiles;

@property (nonatomic, copy) NSString *temp_C;

@property (nonatomic, copy) NSString *weatherCode;

@property (nonatomic, strong) NSArray<Weathericonurl *> *weatherIconUrl;

@end

@interface Weatherdesc : NSObject

@property (nonatomic, copy) NSString *value;

@end

@interface Weathericonurl : NSObject

@property (nonatomic, copy) NSString *value;

@end

////****************************************
@interface Weather : NSObject

@property (nonatomic, strong) NSArray<Hourly *> *hourly;

@property (nonatomic, copy) NSString *maxtempC;

@property (nonatomic, strong) NSArray<Astronomy *> *astronomy;

@property (nonatomic, copy) NSString *mintempC;

@property (nonatomic, copy) NSString *maxtempF;

@property (nonatomic, copy) NSString *date;

@property (nonatomic, copy) NSString *mintempF;

@property (nonatomic, copy) NSString *uvIndex;

@end

@interface Hourly : NSObject

@property (nonatomic, copy) NSString *winddir16Point;

@property (nonatomic, copy) NSString *cloudcover;

@property (nonatomic, copy) NSString *WindChillC;

@property (nonatomic, copy) NSString *humidity;

@property (nonatomic, copy) NSString *DewPointC;

@property (nonatomic, copy) NSString *tempF;

@property (nonatomic, copy) NSString *WindGustMiles;

@property (nonatomic, copy) NSString *chanceofremdry;

@property (nonatomic, copy) NSString *HeatIndexC;

@property (nonatomic, copy) NSString *chanceofthunder;

@property (nonatomic, copy) NSString *FeelsLikeC;

@property (nonatomic, copy) NSString *weatherCode;

@property (nonatomic, copy) NSString *WindChillF;

@property (nonatomic, copy) NSString *chanceoffrost;

@property (nonatomic, copy) NSString *chanceoffog;

@property (nonatomic, copy) NSString *chanceofovercast;

@property (nonatomic, copy) NSString *windspeedKmph;

@property (nonatomic, strong) NSArray<Weathericonurl *> *weatherIconUrl;

@property (nonatomic, copy) NSString *pressure;

@property (nonatomic, copy) NSString *windspeedMiles;

@property (nonatomic, copy) NSString *HeatIndexF;

@property (nonatomic, copy) NSString *chanceofwindy;

@property (nonatomic, copy) NSString *chanceofsnow;

@property (nonatomic, copy) NSString *FeelsLikeF;

@property (nonatomic, copy) NSString *chanceofrain;

@property (nonatomic, strong) NSArray<Weatherdesc *> *weatherDesc;

@property (nonatomic, copy) NSString *visibility;

@property (nonatomic, copy) NSString *tempC;

@property (nonatomic, copy) NSString *precipMM;

@property (nonatomic, copy) NSString *DewPointF;

@property (nonatomic, copy) NSString *chanceofsunshine;

@property (nonatomic, copy) NSString *time;

@property (nonatomic, copy) NSString *chanceofhightemp;

@property (nonatomic, copy) NSString *WindGustKmph;

@property (nonatomic, copy) NSString *winddirDegree;

@end

//@interface Weatherdesc : NSObject

//@property (nonatomic, copy) NSString *value;
//
//@end
//
//@interface Weathericonurl : NSObject
//
//@property (nonatomic, copy) NSString *value;
//
//@end

@interface Astronomy : NSObject

@property (nonatomic, copy) NSString *sunset;

@property (nonatomic, copy) NSString *moonrise;

@property (nonatomic, copy) NSString *moonset;

@property (nonatomic, copy) NSString *sunrise;

@end

