//
//  WeatherModel.m
//  中银鞍山社保
//
//  Created by liweidong on 16/9/7.
//  Copyright © 2016年 董攀立. All rights reserved.
//

#import "WeatherModel.h"

@implementation WeatherModel

//@end
//@implementation Data

//+ (NSDictionary *)objectClassInArray{
//    return @{@"request" : [Request class], @"current_condition" : [Current_Condition class], @"weather" : [Weather class]};
//}
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"request": [Request class],
             @"current_condition" : [Current_Condition class],
             @"weather" : [Weather class]
             };
}
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"request" : @"data.request",
             @"current_condition" : @"data.current_condition",
             @"weather" : @"data.weather"
             };
    
}
@end


@implementation Request

@end


@implementation Current_Condition

//+ (NSDictionary *)objectClassInArray{
//    return @{@"weatherDesc" : [Weatherdesc class], @"weatherIconUrl" : [Weathericonurl class]};
//}
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"weatherDesc" : [Weatherdesc class],
             @"weatherIconUrl" : [Weathericonurl class]
             };
}
@end


@implementation Weatherdesc

@end


@implementation Weathericonurl

@end


@implementation Weather

//+ (NSDictionary *)objectClassInArray{
//    return @{@"hourly" : [Hourly class], @"astronomy" : [Astronomy class]};
//}
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
   return @{@"hourly" : [Hourly class], @"astronomy" : [Astronomy class]};
}
@end


@implementation Hourly

//+ (NSDictionary *)objectClassInArray{
//    return @{@"weatherDesc" : [Weatherdesc class], @"weatherIconUrl" : [Weathericonurl class]};
//}
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"weatherDesc" : [Weatherdesc class], @"weatherIconUrl" : [Weathericonurl class]};
}
@end


//@implementation Weatherdesc
//
//@end
//
//
//@implementation Weathericonurl
//
//@end


@implementation Astronomy

@end


