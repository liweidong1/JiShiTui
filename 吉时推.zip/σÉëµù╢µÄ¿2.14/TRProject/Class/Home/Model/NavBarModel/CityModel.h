//
//  CityModel.h
//  TRProject
//
//  Created by liweidong on 16/12/21.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>
@class CurrentCityModel,CityDataModel,CityShopModel;
//@class Data,Shop;
@interface CityModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<CurrentCityModel *> *data;
@property (nonatomic, strong) NSArray<CityDataModel *> *city;
@property (nonatomic, strong) NSArray<CityShopModel *> *shop;


@end
@interface CurrentCityModel : NSObject

@property (nonatomic, copy) NSString *name;
//id ID
@property (nonatomic, assign) NSInteger ID;
@end

@interface CityDataModel : NSObject

@property (nonatomic, copy) NSString *name;
//id ID
@property (nonatomic, assign) NSInteger ID;

@end

@interface CityShopModel : NSObject

@property (nonatomic, copy) NSString *sname;

@property (nonatomic, assign) NSInteger sid;

@end

