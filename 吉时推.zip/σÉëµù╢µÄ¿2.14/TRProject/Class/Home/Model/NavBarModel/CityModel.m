//
//  CityModel.m
//  TRProject
//
//  Created by liweidong on 16/12/21.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "CityModel.h"

@implementation CityModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [CurrentCityModel class],
             @"shop" : [CityShopModel class],
             @"city" : [CityDataModel class]};
}
@end
@implementation CurrentCityModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper
{
    return @{@"ID" : @"id"};
}
@end
@implementation CityDataModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper
{
    return @{@"ID" : @"id"};
}
@end


@implementation CityShopModel

@end



