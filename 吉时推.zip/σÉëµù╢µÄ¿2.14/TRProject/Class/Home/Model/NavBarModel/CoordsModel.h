//
//  CoordsModel.h
//  TRProject
//
//  Created by liweidong on 16/12/27.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class CoordsData;
@interface CoordsModel : NSObject

@property (nonatomic, strong) NSArray<CoordsData *> *data;

@end
@interface CoordsData : NSObject

@property (nonatomic, copy) NSString *sname;

@property (nonatomic, assign) NSInteger cid;


@property (nonatomic, copy) NSString *lat;

@property (nonatomic, copy) NSString *lng;
@end

