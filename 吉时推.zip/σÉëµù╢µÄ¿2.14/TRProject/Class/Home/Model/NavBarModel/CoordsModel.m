//
//  CoordsModel.m
//  TRProject
//
//  Created by liweidong on 16/12/27.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "CoordsModel.h"

@implementation CoordsModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [CoordsData class]};
}

@end
@implementation CoordsData

@end


