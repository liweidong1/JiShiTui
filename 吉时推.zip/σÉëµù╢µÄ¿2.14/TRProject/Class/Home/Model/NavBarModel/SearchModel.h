//
//  SearchModel.h
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class SearchCoordModel,SearchProductModel,SearchShopModel;
@interface SearchModel : NSObject

@property (nonatomic, assign) NSInteger status;

//@property (nonatomic, strong) Data *data;

//@end
//@interface Data : NSObject

@property (nonatomic, strong) NSArray<SearchCoordModel *> *coord;

@property (nonatomic, strong) NSArray<SearchProductModel *> *product;

@property (nonatomic, strong) NSArray<SearchShopModel *> *shop;

@end

@interface SearchCoordModel : NSObject

@property (nonatomic, copy) NSString *city;

@property (nonatomic, assign) NSInteger scope;

@property (nonatomic, copy) NSString *sname;

@property (nonatomic, assign) NSInteger flag;

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, copy) NSString *lng;

@property (nonatomic, copy) NSString *lat;

@property (nonatomic, assign) NSInteger cid;

@end
@interface SearchProductModel : NSObject

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, assign) NSInteger quantity;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger price;

@end
@interface SearchShopModel : NSObject

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, copy) NSString *addr;

@end

