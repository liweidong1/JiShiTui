//
//  SearchModel.m
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "SearchModel.h"

@implementation SearchModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"coord" : [SearchCoordModel class],
             @"shop" : [SearchShopModel class],
             @"product" : [SearchProductModel class]};
}
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper
{
    return @{@"coord" : @"data.coord.data",
             @"shop" : @"data.shop.data",
             @"product" : @"data.product.data"};
}
@end

@implementation SearchCoordModel

@end
@implementation SearchProductModel

@end

@implementation SearchShopModel

@end


