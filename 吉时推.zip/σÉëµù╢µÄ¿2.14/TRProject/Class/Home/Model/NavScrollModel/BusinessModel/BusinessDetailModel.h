//
//  BusinessDetailModel.h
//  TRProject
//
//  Created by liweidong on 16/12/30.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BusinessDetailBrepModel,BusinessDetailGrepModel,BusinessDetailAllrepModel,BusinessDetailDatasModel,BusinessDetailDataModel,BusinessImgModel;
@interface BusinessDetailModel : NSObject

@property (nonatomic, assign) NSInteger rep;
@property (nonatomic, strong) BusinessDetailGrepModel *grep;
@property (nonatomic, strong) BusinessDetailAllrepModel *allrep;
@property (nonatomic, strong) BusinessDetailBrepModel *brep;
@property (nonatomic, assign) NSInteger gcount;

@property (nonatomic, assign) NSInteger car;

@property (nonatomic, assign) NSInteger bcount;



@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<BusinessDetailDatasModel *> *datas;

@property (nonatomic, assign) CGFloat lv;



@end
@interface BusinessDetailBrepModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<BusinessDetailDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface BusinessDetailGrepModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<BusinessDetailDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface BusinessDetailAllrepModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<BusinessDetailDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end


@interface BusinessDetailDatasModel : NSObject

@property (nonatomic, assign) NSInteger delivery;

@property (nonatomic, assign) NSInteger viewnum;

@property (nonatomic, copy) NSString *hotphone;

@property (nonatomic, copy) NSString *juli;

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, copy) NSString *address;

@property (nonatomic, assign) NSInteger sell_number;

@property (nonatomic, copy) NSString *lat;

@property (nonatomic, copy) NSArray<NSString *> *images;
@property (nonatomic, copy) NSString *info;

@property (nonatomic, copy) NSString *lng;

@property (nonatomic, copy) NSString *sname;
@end
//好评   差评     所有评论
@interface BusinessDetailDataModel : NSObject

@property (nonatomic, assign) NSInteger pid;

@property (nonatomic, assign) NSInteger uid;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, assign) NSInteger comtype;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, assign) NSInteger sl;

@property (nonatomic, copy) NSString *comment_time;

@property (nonatomic, assign) NSInteger cid;

@end


