//
//  BusinessDetailModel.m
//  TRProject
//
//  Created by liweidong on 16/12/30.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BusinessDetailModel.h"

@implementation BusinessDetailModel


+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"grep" : [BusinessDetailGrepModel class],
             @"allrep" : [BusinessDetailAllrepModel class],
             @"brep" : [BusinessDetailBrepModel class],
             @"datas" : [BusinessDetailDatasModel class]};
}
@end
@implementation BusinessDetailGrepModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [BusinessDetailDataModel class]};
}
@end
@implementation BusinessDetailAllrepModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [BusinessDetailDataModel class]};
}
@end
@implementation BusinessDetailBrepModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [BusinessDetailDataModel class]};
}
@end
@implementation BusinessDetailDatasModel

@end

@implementation BusinessDetailDataModel

@end





