//
//  BusinessHomeModel.h
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BusinessHomeDataModel,BusinessHomeCollecdtionDataModel,BusinessHomeShopModel,BusinessHomeAdModel;
@interface BusinessHomeModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) BusinessHomeDataModel *data;

@property (nonatomic, strong) BusinessHomeShopModel *shop;

@property (nonatomic, strong) NSArray<BusinessHomeAdModel *> *ad;

@end
@interface BusinessHomeDataModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<BusinessHomeCollecdtionDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface BusinessHomeCollecdtionDataModel : NSObject

@property (nonatomic, assign) NSInteger pid;

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, assign) NSInteger sell_number;

@end

@interface BusinessHomeShopModel : NSObject

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, copy) NSString *shopname;
/**
 *  添加   flag商店的开启关闭状态     notice商店的公告
 */
@property (nonatomic, assign)NSInteger flag;
@property (nonatomic, copy)NSString *notice;

@end

@interface BusinessHomeAdModel : NSObject

@property (nonatomic, copy) NSString *photo;

@property (nonatomic, copy) NSString *end_time;

@property (nonatomic, copy) NSString *link_addr;

@end

