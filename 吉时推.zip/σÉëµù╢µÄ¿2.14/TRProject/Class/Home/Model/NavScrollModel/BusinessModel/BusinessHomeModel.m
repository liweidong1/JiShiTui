//
//  BusinessHomeModel.m
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BusinessHomeModel.h"

@implementation BusinessHomeModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [BusinessHomeDataModel class],
             @"shop" : [BusinessHomeShopModel class],
             @"ad" : [BusinessHomeAdModel class]};
}
@end
@implementation BusinessHomeCollecdtionDataModel

@end


@implementation BusinessHomeDataModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [BusinessHomeCollecdtionDataModel class]};
}
@end


@implementation BusinessHomeShopModel

@end


@implementation BusinessHomeAdModel

@end

//+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
//    return @{@"data": @"datas" };
//}
