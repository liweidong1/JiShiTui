//
//  BusinessPayAttentionInfoModel.h
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BusinessPayAttentionInfoModel : NSObject
@property (nonatomic, assign) NSInteger flag;

@property (nonatomic, assign) NSInteger count;
@end
