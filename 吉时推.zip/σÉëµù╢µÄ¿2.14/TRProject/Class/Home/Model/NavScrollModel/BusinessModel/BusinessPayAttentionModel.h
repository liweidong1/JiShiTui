//
//  BusinessPayAttentionModel.h
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BusinessPayAttentionModel : NSObject

@property (nonatomic, assign) NSInteger status;


@end
