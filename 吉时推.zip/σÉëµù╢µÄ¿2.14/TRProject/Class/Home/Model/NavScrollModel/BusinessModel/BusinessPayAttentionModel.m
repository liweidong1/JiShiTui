//
//  BusinessPayAttentionModel.m
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BusinessPayAttentionModel.h"

@implementation BusinessPayAttentionModel

@end
