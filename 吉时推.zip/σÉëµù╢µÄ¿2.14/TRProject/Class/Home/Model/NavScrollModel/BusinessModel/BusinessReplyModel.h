//
//  BusinessReplyModel.h
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class BusinessReplyDatasModel,BusinessReplyDataModel;
@interface BusinessReplyModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) BusinessReplyDatasModel *datas;


@end

@interface BusinessReplyDatasModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<BusinessReplyDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface BusinessReplyDataModel : NSObject

@property (nonatomic, copy) NSString *comment_time;

@property (nonatomic, copy) NSString *content;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *avatar;

@end

