//
//  BusinessReplyModel.m
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BusinessReplyModel.h"

@implementation BusinessReplyModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"datas" : [BusinessReplyDatasModel class]};
}
@end


@implementation BusinessReplyDatasModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
   return @{@"data" : [BusinessReplyDataModel class]};
}
@end


@implementation BusinessReplyDataModel

@end


