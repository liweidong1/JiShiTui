//
//  SendCommentModel.h
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SendCommentModel : NSObject

@property (nonatomic, assign) NSInteger status;

@end
