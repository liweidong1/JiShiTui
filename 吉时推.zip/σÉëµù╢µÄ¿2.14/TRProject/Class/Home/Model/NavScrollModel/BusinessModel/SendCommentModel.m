//
//  SendCommentModel.m
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "SendCommentModel.h"

@implementation SendCommentModel

@end
