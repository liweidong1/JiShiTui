//
//  ShopCarAddJianModel.h
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShopCarAddJianModel : NSObject

@property (nonatomic, assign) NSInteger status;

@end
