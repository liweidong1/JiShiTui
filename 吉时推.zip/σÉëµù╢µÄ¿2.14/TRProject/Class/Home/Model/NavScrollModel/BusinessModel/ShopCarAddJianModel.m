//
//  ShopCarAddJianModel.m
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ShopCarAddJianModel.h"

@implementation ShopCarAddJianModel

@end
