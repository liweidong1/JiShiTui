//
//  ShopCarAddModel.h
//  TRProject
//
//  Created by liweidong on 17/1/5.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ShopCarAddModel : NSObject
@property (nonatomic, assign) NSInteger status;
@end
