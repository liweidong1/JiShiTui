//
//  ShopCarModel.h
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ShopCarDatasModel,ShopCarProductModel;
@interface ShopCarModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<ShopCarDatasModel *> *datas;

@end
@interface ShopCarDatasModel : NSObject

@property (nonatomic, copy) NSString *sname;

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, strong) NSArray<ShopCarProductModel *> *product;

@end

@interface ShopCarProductModel : NSObject

@property (nonatomic, copy) NSString *img;
// id ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, assign) NSInteger disprice;
//商品是否被选中
@property (nonatomic, assign) BOOL      isSelect;
@end

