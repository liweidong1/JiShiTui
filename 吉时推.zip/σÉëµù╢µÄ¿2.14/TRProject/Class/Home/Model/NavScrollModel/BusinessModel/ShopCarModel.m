//
//  ShopCarModel.m
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ShopCarModel.h"

@implementation ShopCarModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"datas" : [ShopCarDatasModel class]};
}
@end
@implementation ShopCarDatasModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [ShopCarProductModel class]};
}
@end


@implementation ShopCarProductModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}
@end


