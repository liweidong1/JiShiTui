//
//  ShopOrderModel.h
//  TRProject
//
//  Created by liweidong on 17/1/5.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ShopOrderShopModel,ShopOrderProductModel,ShopOrderAddrModel;
@interface ShopOrderModel : NSObject

@property (nonatomic, strong) NSArray<ShopOrderShopModel *> *shop;

@property (nonatomic, strong) NSArray<ShopOrderAddrModel *> *addr;

@end
@interface ShopOrderShopModel : NSObject

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray<ShopOrderProductModel *> *product;

@end

@interface ShopOrderProductModel : NSObject

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, assign) NSInteger price;

@end

@interface ShopOrderAddrModel : NSObject

@property (nonatomic, assign) NSInteger uid;

@property (nonatomic, copy) NSString *phone;

@property (nonatomic, copy) NSString *sex;

@property (nonatomic, copy) NSString *province;

@property (nonatomic, assign) NSInteger addtime;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *addr;

@property (nonatomic, assign) NSInteger flag;

@property (nonatomic, assign) NSInteger addid;

@property (nonatomic, copy) NSString *city;

@property (nonatomic, copy) NSString *email;

@property (nonatomic, copy) NSString *name;

@end

