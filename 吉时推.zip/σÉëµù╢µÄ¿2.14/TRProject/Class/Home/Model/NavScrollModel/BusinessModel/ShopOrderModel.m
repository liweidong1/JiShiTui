//
//  ShopOrderModel.m
//  TRProject
//
//  Created by liweidong on 17/1/5.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ShopOrderModel.h"

@implementation ShopOrderModel


+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"shop" : [ShopOrderShopModel class],
             @"addr" : [ShopOrderAddrModel class]};
}
@end
@implementation ShopOrderShopModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [ShopOrderProductModel class]};
}

@end


@implementation ShopOrderProductModel

@end


@implementation ShopOrderAddrModel

@end


