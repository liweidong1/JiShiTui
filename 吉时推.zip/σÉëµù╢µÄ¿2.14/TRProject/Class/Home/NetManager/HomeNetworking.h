//
//  HomeNetworking.h
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseNetworking.h"

#import "AddressModel.h"
#import "CityModel.h"
#import "CoordsModel.h"
#import "SearchModel.h"
#import "HomeHeaderModel.h"
#import "WeatherModel.h"
#import "HomeOtherModel.h"
#import "NavScrollModel.h"
@interface HomeNetworking : BaseNetworking

/**
 *  城市
 */
+ (id)sendLngLat:(NSString *)LngAndLat lanAndLatCompletionHandler:(void(^)(AddressModel *model, NSError *error))completionHandler;
/**
 *  所有城市
 */
+ (id)getCitysWithcityID:(NSString *)cityID CompletionHandler:(void (^)(CityModel *model, NSError *error))completionHandler;
/**
 *  切换城市商圈界面刷新城市显示不同城市的商圈
 */
+ (id)getAllCitysSubTableViewWithcityID:(NSString *)cityID CompletionHandler:(void (^)(CoordsModel *model, NSError *error))completionHandler;
/**
 *  搜索
 */
+ (id)getSearchWithPage:(NSInteger)page WithSearchContent:(NSString *)searContent CompletionHandler:(void(^)(SearchModel *model, NSError *error))completionHandler;
/**
 *  Banner
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng  BannerCompletionHandler:(void(^)(HomeHeaderModel *model, NSError *error))completionHandler;
/**
 *  NavScroll
 */
+ (id)getNavScrollBannerCompletionHandler:(void(^)(NavScrollModel *model, NSError *error))completionHandler;
/**
 *  天气
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng WeatherCompletionHandler:(void(^)(WeatherModel *model, NSError *error))completionHandler;



/**
 *  为你优选
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng SelectFirst:(NSInteger)page  completionHandler:(void(^)(HomeOtherModel *model, NSError *error))completionHandler;

@end
