//
//  HomeNetworking.m
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeNetworking.h"

@implementation HomeNetworking
/**
 *  经纬度 定位地址
 */
+ (id)sendLngLat:(NSString *)LngAndLat lanAndLatCompletionHandler:(void (^)(AddressModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstAddressPath,LngAndLat];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([AddressModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
/**
 *  所有城市
 */
+ (id)getCitysWithcityID:(NSString *)cityID CompletionHandler:(void (^)(CityModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstCitysPath,cityID];
    NSLog(@"%@",cityID);
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([CityModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
/**
 *  点击某一个城市刷新对应的商圈
 */
+ (id)getAllCitysSubTableViewWithcityID:(NSString *)cityID CompletionHandler:(void (^)(CoordsModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstCitysSubTableViewPath,cityID];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([CoordsModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];

}
/**
 *  搜索
 */
+ (id)getSearchWithPage:(NSInteger)page WithSearchContent:(NSString *)searContent CompletionHandler:(void (^)(SearchModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstSearchPath,searContent,page];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([SearchModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
/**
 *  Banner
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng BannerCompletionHandler:(void (^)(HomeHeaderModel *, NSError *))completionHandler
{
    //NSString * urlPath = jstBanner;
     NSString * urlPath = [NSString stringWithFormat:jstBanner,Lat,Lng];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([HomeHeaderModel parse:repsonseObj], error);
    }];
}
/**
 *  NavScroll
 */
+ (id)getNavScrollBannerCompletionHandler:(void (^)(NavScrollModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstNavScrollBannerPath];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([NavScrollModel parse:repsonseObj], error);
    }];

}
/**
 *  天气
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng WeatherCompletionHandler:(void (^)(WeatherModel *, NSError *))completionHandler{
    NSString * urlPath = [NSString stringWithFormat:jstWeatherPathbase,Lat,Lng];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([WeatherModel parse:responseObj], error);
    }];
    
}
/**
 *  为你优选
 */
+ (id)getLat:(NSString *)Lat Lng:(NSString *)Lng SelectFirst:(NSInteger)page completionHandler:(void (^)(HomeOtherModel *, NSError *))completionHandler
{
    NSString *urlPath = [NSString stringWithFormat:jstSelectFirst,Lat,Lng,page];
    
    //NSString *urlPath = [NSString stringWithFormat:jstSelectFirst,page];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([HomeOtherModel parse:repsonseObj], error);
        NSLog(@"%@",repsonseObj);
    }];
}
@end
