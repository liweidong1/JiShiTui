//
//  NavScrollNetworking.h
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseNetworking.h"
#import "BusinessHomeModel.h"
#import "BusinessPayAttentionInfoModel.h"
#import "BusinessPayAttentionModel.h"
#import "BusinessDetailModel.h"
#import "BusinessReplyModel.h"
#import "SendCommentModel.h"
#import "ShopCarAddModel.h"//添加到购物车
#import "ShopCarModel.h"
#import "ShopCarAddJianModel.h"
#import "ShopCarDeleteModel.h"
#import "ShopOrderModel.h" //订单
@interface NavScrollNetworking : BaseNetworking
/**
 *  商家页底部商品
 */
+ (id)getBusinessWithPage:(NSInteger)page completionHandler:(void(^)(BusinessHomeModel *model, NSError *error))completionHandler;
/**
 *  商家页关注信息
 */
+ (id)getPayAttentionInfoCompletionHandler:(void(^)(BusinessPayAttentionInfoModel *model, NSError *error))completionHandler;
/**
 *  商家页关注
 */
+ (id)getPayAttentionCompletionHandler:(void(^)(BusinessPayAttentionModel *model, NSError *error))completionHandler;
/**
 *  商品详情
 */
+ (id)getGoodsDetailWithPid:(NSInteger)pid WithPage:(NSInteger)page CompletionHandler:(void(^)(BusinessDetailModel *model, NSError *error))completionHandler;
/**
 *  商品评论回复
 */
+ (id)getGoodsDetailWithCid:(NSInteger)cid WithPage:(NSInteger)page CompletionHandler:(void(^)(BusinessReplyModel *model, NSError *error))completionHandler;
/**
 *  商品评论回复用户
 */
+ (id)getGoodsDetailWithCid:(NSInteger)cid WithUid:(NSInteger)uid WithComment:(NSString *)comment CompletionHandler:(void(^)(SendCommentModel *model, NSError *error))completionHandler;
/**
 *  商品添加-->购物车
 */
+ (id)getGoodsDetailAddShopCarWithUid:(NSInteger)uid WithPid:(NSInteger)pid CompletionHandler:(void(^)(ShopCarAddModel *model, NSError *error))completionHandler;


/**
 *  商品购物车
 */
+ (id)getGoodsDetailWithUid:(NSInteger)uid CompletionHandler:(void(^)(ShopCarModel *model, NSError *error))completionHandler;
/**
 *  商品购物车增加减少
 */
+ (id)getGoodsDetailWithCarID:(NSInteger)carID WithCarCount:(NSInteger)carCount CompletionHandler:(void(^)(ShopCarAddJianModel *model, NSError *error))completionHandler;
/**
 *  商品购物车删除操作
 */
+ (id)getGoodsDetailWithCarID:(NSInteger)carID CompletionHandler:(void(^)(ShopCarDeleteModel *model, NSError *error))completionHandler;
/**
 *  订单页
 */
+ (id)getOrderWithUid:(NSInteger)uid WithPid:(NSInteger)pid WithCid:(NSString *)cid  CompletionHandler:(void(^)(ShopOrderModel *model, NSError *error))completionHandler;
@end
