//
//  NavScrollNetworking.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "NavScrollNetworking.h"
@implementation NavScrollNetworking

+ (id)getBusinessWithPage:(NSInteger)page completionHandler:(void (^)(BusinessHomeModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopPath,page];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([BusinessHomeModel parse:responseObj], error);
    }];
}
+ (id)getPayAttentionInfoCompletionHandler:(void (^)(BusinessPayAttentionInfoModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopayAttentionInfoPath];
    NSLog(@"%@",path);
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([BusinessPayAttentionInfoModel parse:responseObj], error);
    }];
}
+ (id)getPayAttentionCompletionHandler:(void (^)(BusinessPayAttentionModel *, NSError *))completionHandler

{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopayAttentionPath];
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([BusinessPayAttentionModel parse:responseObj], error);
    }];
}
+ (id)getGoodsDetailWithPid:(NSInteger)pid WithPage:(NSInteger)page CompletionHandler:(void (^)(BusinessDetailModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopDetailPath,pid,page];
    NSLog(@"%@",path);
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([BusinessDetailModel parse:responseObj], error);
    }];
}

+ (id)getGoodsDetailWithCid:(NSInteger)cid WithPage:(NSInteger)page CompletionHandler:(void (^)(BusinessReplyModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopDetailReplyPath,cid,page];
    NSLog(@"%@",path);
    return [self GET:path parameters:nil completionHandler:^(id responseObj, NSError *error) {
        !completionHandler ?: completionHandler([BusinessReplyModel parse:responseObj], error);
    }];
}
+ (id)getGoodsDetailWithCid:(NSInteger)cid WithUid:(NSInteger)uid WithComment:(NSString *)comment CompletionHandler:(void (^)(SendCommentModel *, NSError *))completionHandler
{
  
    NSString *path = [NSString stringWithFormat:jstNavScrollShopDetailSendReplyPath,cid,uid,comment];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([SendCommentModel parse:repsonseObj], error);
    }];
}
+ (id)getGoodsDetailAddShopCarWithUid:(NSInteger)uid WithPid:(NSInteger)pid CompletionHandler:(void (^)(ShopCarAddModel *, NSError *))completionHandler
{
    
    NSString *path = [NSString stringWithFormat:jstNavScrollShopCarAddPath,uid,pid];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopCarAddModel parse:repsonseObj], error);
    }];
}
+ (id)getGoodsDetailWithUid:(NSInteger)uid CompletionHandler:(void (^)(ShopCarModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopCarPath,uid];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopCarModel parse:repsonseObj], error);
    }];
}
+ (id)getGoodsDetailWithCarID:(NSInteger)carID WithCarCount:(NSInteger)carCount CompletionHandler:(void (^)(ShopCarAddJianModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopCarAddJianPath,carID,carCount];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopCarAddJianModel parse:repsonseObj], error);
    }];
}
+ (id)getGoodsDetailWithCarID:(NSInteger)carID CompletionHandler:(void (^)(ShopCarDeleteModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopDeletePath,carID];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopCarDeleteModel parse:repsonseObj], error);
    }];
}
+ (id)getOrderWithUid:(NSInteger)uid WithPid:(NSInteger)pid WithCid:(NSString *)cids CompletionHandler:(void (^)(ShopOrderModel *, NSError *))completionHandler
{
    NSString *path = [NSString stringWithFormat:jstNavScrollShopOrderPath,uid,pid,cids];
    NSLog(@"%@",path);
    return [self POST:path parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopOrderModel parse:repsonseObj], error);
    }];
}
@end
