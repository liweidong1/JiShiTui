//
//  JSCartCell.h
//  JSShopCartModule
//
//  Created by 乔同新 on 16/6/9.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ShopCarProductModel,JSNummberCount;

@interface JSCartCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIButton *selectShopGoodsButton;

@property (weak, nonatomic) IBOutlet JSNummberCount *nummberCount;

@property (nonatomic, strong) ShopCarProductModel *model;

+ (CGFloat)getCartCellHeight;

@end
