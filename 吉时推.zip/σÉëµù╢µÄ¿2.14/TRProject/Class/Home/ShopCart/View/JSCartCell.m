//
//  JSCartCell.m
//  JSShopCartModule
//
//  Created by 乔同新 on 16/6/9.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import "JSCartCell.h"
#import "JSNummberCount.h"
#import "ShopCarModel.h"

@interface JSCartCell ()

@property (weak, nonatomic) IBOutlet UILabel        *goodsNameLabel;
@property (weak, nonatomic) IBOutlet UILabel        *GoodsPricesLabel;
@property (weak, nonatomic) IBOutlet UIImageView    *goodsImageView;

@end

@implementation JSCartCell

- (void)awakeFromNib {
    [super awakeFromNib];
    
    self.selectionStyle = UITableViewCellSelectionStyleNone;

}

- (void)setModel:(ShopCarProductModel *)model{
     _model = model;
//    self.goodsNameLabel.text             = @"sdfdd";
    self.goodsNameLabel.text             = model.title;
    self.GoodsPricesLabel.text           = [NSString stringWithFormat:@"￥%.2ld",(long)model.price];
    self.nummberCount.totalNum           = @1;
    self.nummberCount.currentCountNumber = model.count;
    self.selectShopGoodsButton.selected  = model.isSelect;
}

+ (CGFloat)getCartCellHeight{
    
    return 100;
}

@end
