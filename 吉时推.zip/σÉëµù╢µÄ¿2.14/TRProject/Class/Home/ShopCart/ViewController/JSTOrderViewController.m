//
//  JSTOrderViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/6.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "JSTOrderViewController.h"
#import "jstPayStyleViewController.h"
@interface JSTOrderViewController ()

@end

@implementation JSTOrderViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title= @"订单";
    [self setBottomViews];
    
}
-(void)setBottomViews
{
    UIButton * btn = [[UIButton alloc]init];
    [self.view addSubview:btn];
    btn.backgroundColor = [UIColor redColor];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn setTitle:@"提交订单" forState:UIControlStateNormal];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.bottom.equalTo(0);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH/2, 60));
    }];
    [btn bk_addEventHandler:^(id sender) {
        jstPayStyleViewController * payVC = [[jstPayStyleViewController alloc]init];
        [self.navigationController pushViewController:payVC animated:YES];
    } forControlEvents:UIControlEventTouchUpInside];


}
@end
