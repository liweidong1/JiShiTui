//
//  JSCartViewModel.m
//  JSShopCartModule
//
//  Created by 乔同新 on 16/6/9.
//  Copyright © 2016年 乔同新. All rights reserved.
//

#import "JSCartViewModel.h"
#import "ShopCarModel.h"

#import "NavScrollNetworking.h"


@interface JSCartViewModel (){
    
    NSArray *_shopGoodsCount;//商品数量
    NSArray *_goodsPicArray;//商品图标
    NSArray *_goodsPriceArray;//商品价格
    NSArray *_goodsQuantityArray;//单个商品数量
    
}
//随机获取店铺下商品数
@property (nonatomic, assign) NSInteger random;
@end

@implementation JSCartViewModel
#pragma mark - make data
- (NSMutableArray<ShopCarDatasModel *> *)cartData {
    if(_cartData == nil) {
        _cartData = [[NSMutableArray<ShopCarDatasModel *>  alloc] init];
    }
    return _cartData;
}
- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    [NavScrollNetworking getGoodsDetailWithUid:1 CompletionHandler:^(ShopCarModel *model, NSError *error) {
        NSMutableArray *storeArray = [NSMutableArray array];
        //数据个数
        NSInteger allCount = model.datas.count;//分区数
        [self.cartData addObjectsFromArray:model.datas];
        NSInteger allGoodsCount = 0;//行数
        NSMutableArray *shopSelectAarry = [NSMutableArray arrayWithCapacity:allCount];
        //创造店铺数据
        for (int i = 0; i<allCount; i++) {
            //创造店铺下商品数据   -----------数据更改
            NSInteger goodsCount = model.datas[i].product.count;
            NSLog(@"%ld",goodsCount);
            NSMutableArray *goodsArray = [NSMutableArray arrayWithCapacity:goodsCount];
            for (int x = 0; x<goodsCount; x++) {
                
                [goodsArray addObject:model.datas[i].product];
                NSLog(@"%ld",goodsArray.count);
                allGoodsCount++;
            }
            NSLog(@"%ld",allGoodsCount);
            [storeArray addObject:goodsArray];
            [shopSelectAarry addObject:@(NO)];
        }
        //self.cartData = storeArray;
        self.shopSelectArray = shopSelectAarry;
        self.cartGoodsCount = allGoodsCount;
        !completionHandler ?: completionHandler(error);
    }];
}
- (NSInteger)shopCarSectionNumber
{
    NSLog(@"%ld",self.cartData.count);
    return self.cartData.count;
}
- (NSInteger)numberOfItemsInSection:(NSInteger)section
{
    NSLog(@"%ld",self.cartData[section].product.count);
    return self.cartData[section].product.count;
}

- (float)getAllPrices:(NSInteger)section{
    
    __block float allPrices   = 0;
    NSInteger shopCount       = self.cartData[section].product.count;
    NSInteger shopSelectCount = self.shopSelectArray.count;
    if (shopSelectCount == shopCount && shopCount!=0) {
        self.isSelectAll = YES;
    }
    NSArray *pricesArray = [[[self.cartData[section].product rac_sequence] map:^id(NSMutableArray *value) {
        return [[[value rac_sequence] filter:^BOOL(ShopCarProductModel *model) {
            if (!model.isSelect) {
                self.isSelectAll = NO;
            }
            return model.isSelect;
        }] map:^id(ShopCarProductModel *model) {
            return @(model.count*model.price);
        }];
    }] array];
    for (NSArray *priceA in pricesArray) {
        for (NSNumber *price in priceA) {
            allPrices += price.floatValue;
        }
    }
    
    return allPrices;
}

- (void)selectAll:(BOOL)isSelect{
    
     __block float allPrices = 0;
    
    self.shopSelectArray = [[[[self.shopSelectArray rac_sequence] map:^id(NSNumber *value) {
        return @(isSelect);
    }] array] mutableCopy];
    self.cartData = [[[[self.cartData rac_sequence] map:^id(NSMutableArray *value) {
        return  [[[[value rac_sequence] map:^id(ShopCarProductModel *model) {
                [model setValue:@(isSelect) forKey:@"isSelect"];
            if (model.isSelect) {
                allPrices += model.count*model.price;
            }
            return model;
        }] array] mutableCopy];
    }] array] mutableCopy];
    self.allPrices = allPrices;
    [self.cartTableView reloadData];

}

- (void)rowSelect:(BOOL)isSelect IndexPath:(NSIndexPath *)indexPath{
    
    NSInteger section          = indexPath.section;
    NSInteger row              = indexPath.row;

    NSMutableArray<ShopCarProductModel  *> *goodsArray = (NSMutableArray *)self.cartData[section].product;
    NSInteger shopCount        = goodsArray.count;
    ShopCarProductModel *model         = goodsArray[row];
    [model setValue:@(isSelect) forKey:@"isSelect"];
    //判断是都到达足够数量
    NSInteger isSelectShopCount = 0;
    for (ShopCarProductModel *model in goodsArray) {
        if (model.isSelect) {
            isSelectShopCount++;
        }
    }
    [self.shopSelectArray replaceObjectAtIndex:section withObject:@(isSelectShopCount==shopCount?YES:NO)];
    
    [self.cartTableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationNone];
    
    /*重新计算价格*/
    self.allPrices = [self getAllPrices:indexPath.section];
}

- (void)rowChangeQuantity:(NSInteger)quantity indexPath:(NSIndexPath *)indexPath{
    
    NSInteger section  = indexPath.section;
    NSInteger row      = indexPath.row;

    ShopCarProductModel *model = self.cartData[section].product[row];

    [model setValue:@(quantity) forKey:@"count"];
    
    [self.cartTableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationNone];
    
    /*重新计算价格*/
    self.allPrices = [self getAllPrices:indexPath.section];
}

//左滑删除商品
- (void)deleteGoodsBySingleSlide:(NSIndexPath *)path{
    
    NSInteger section = path.section;
    NSInteger row     = path.row;
    
    NSMutableArray<ShopCarProductModel *> *shopArray = (NSMutableArray *)self.cartData[section].product;
    [shopArray removeObjectAtIndex:row];
    if (shopArray.count == 0) {
        /*1 删除数据*/
        [self.cartData removeObjectAtIndex:section];
        /*2 删除 shopSelectArray*/
        [self.shopSelectArray removeObjectAtIndex:section];
        [self.cartTableView reloadData];
    } else {
        [self.cartTableView reloadSections:[NSIndexSet indexSetWithIndex:section] withRowAnimation:UITableViewRowAnimationNone];
    }
    self.cartGoodsCount-=1;
    /*重新计算价格*/
    self.allPrices = [self getAllPrices:section];
}

//选中删除
- (void)deleteGoodsBySelect{
    /*1 删除数据*/
    NSInteger index1 = -1;
    NSMutableIndexSet *shopSelectIndex = [NSMutableIndexSet indexSet];
    for (NSMutableArray *shopArray in self.cartData) {
        index1++;
        
        NSInteger index2 = -1;
        NSMutableIndexSet *selectIndexSet = [NSMutableIndexSet indexSet];
        for (ShopCarProductModel *model in shopArray) {
            index2++;
            if (model.isSelect) {
                [selectIndexSet addIndex:index2];
            }
        }
        NSInteger shopCount = shopArray.count;
        NSInteger selectCount = selectIndexSet.count;
        if (selectCount == shopCount) {
            [shopSelectIndex addIndex:index1];
            self.cartGoodsCount-=selectCount;
        }
        [shopArray removeObjectsAtIndexes:selectIndexSet];
    }
    
    [self.cartData removeObjectsAtIndexes:shopSelectIndex];
    /*2 删除 shopSelectArray*/
    [self.shopSelectArray removeObjectsAtIndexes:shopSelectIndex];
    [self.cartTableView reloadData];
    /*3 carbar 恢复默认*/
    self.allPrices = 0;
    /*重新计算价格*/
    self.allPrices = [self getAllPrices:1];
}

@end
