//
//  ChooseFirstCell.h
//  TRProject
//
//  Created by liweidong on 16/12/16.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseFirstCell : UITableViewCell
/**为您优选 */
@property (nonatomic, strong) UIView *viewLeft;
@property (nonatomic, strong) UILabel *lab;
@property (nonatomic, strong) UIView *viewRight;




@end
