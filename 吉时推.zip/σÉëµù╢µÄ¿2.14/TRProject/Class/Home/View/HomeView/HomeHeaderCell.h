//
//  HomeHeaderCell.h
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UIKit/UIKit.h>

@class HomeHeaderCell;
@protocol HomeHeaderCellDataSource <NSObject>

- (NSInteger)numberOfItemInCell:(HomeHeaderCell *)cell;
- (NSURL *)iconURLForItemInCell:(HomeHeaderCell *)cell atIndex:(NSInteger)index;
@end

@protocol HomeHeaderCellDelegate <NSObject>
@optional
- (void)homeHeaderCell:(HomeHeaderCell *)cell didSelectedIconAtIndex:(NSInteger)index;

@end

@interface HomeHeaderCell : UITableViewCell
@property (nonatomic) iCarousel *ic;
@property (nonatomic) UIPageControl *pc;
@property (nonatomic, weak) id<HomeHeaderCellDelegate> delegate;
@property (nonatomic, weak) id<HomeHeaderCellDataSource> dataSource;

- (void)reloaedData;
@property (nonatomic) NSTimer *timer;

@end
