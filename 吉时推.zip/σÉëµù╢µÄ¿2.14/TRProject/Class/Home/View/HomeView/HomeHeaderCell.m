//
//  HomeHeaderCell.m
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeHeaderCell.h"
@interface HomeHeaderCell () <iCarouselDelegate, iCarouselDataSource>
@end
@implementation HomeHeaderCell

#pragma mark - ic Delegate
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel {
    if ([_dataSource respondsToSelector:@selector(numberOfItemInCell:)]) {
        
        return [_dataSource numberOfItemInCell:self];
    }
    return 0;
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value {
    if (option == iCarouselOptionWrap) {
        value = YES;
        
    }
    return value;
}

- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view {
    if (!view) {
        view = [[UIImageView alloc] initWithFrame:carousel.bounds];
    }
    if ([_dataSource respondsToSelector:@selector(iconURLForItemInCell:atIndex:)]) {
        [((UIImageView *)view) setImageWithURL:[_dataSource iconURLForItemInCell:self atIndex:index] placeholder:[UIImage imageNamed:@"placeholder"]];
    }else {
        ((UIImageView *)view).image = [UIImage imageNamed:@"default_kitchenpic"];
    }
    return view;
}

- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel {
    _pc.currentPage = carousel.currentItemIndex;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index {
    if ([_delegate respondsToSelector:@selector(homeHeaderCell:didSelectedIconAtIndex:)]) {
        [_delegate homeHeaderCell:self didSelectedIconAtIndex:index];
    }
}

#pragma mark - Method 方法
- (void)reloaedData {
    if ([_dataSource respondsToSelector:@selector(numberOfItemInCell:)]) {
        _pc.numberOfPages = [_dataSource numberOfItemInCell:self];
    }
    [_ic reloadData];
    [_timer invalidate];
    _timer = nil;
    _timer = [NSTimer bk_scheduledTimerWithTimeInterval:3 block:^(NSTimer *timer) {
        [self.ic scrollToItemAtIndex:_ic.currentItemIndex + 1 animated:YES];
    } repeats:YES];
}

#pragma mark - LifeCycle 生命周期
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self ic];
    }
    return self;
}

#pragma mark - LazyLoad 懒加载
- (UIPageControl *)pc {
    if (!_pc) {
        _pc = [UIPageControl new];
        _pc.currentPageIndicatorTintColor = [UIColor whiteColor];
        _pc.pageIndicatorTintColor = jRGBA(255, 255, 255, 0.5);
        [self.ic addSubview:_pc];
        [_pc mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.bottom.equalTo(0);
        }];
    }
    return _pc;
}

- (iCarousel *)ic {
    if (!_ic) {
        _ic = [iCarousel new];
        [self.contentView addSubview:_ic];
        [_ic mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(0);
            
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, SCREEN_WIDTH * 615 / 1125));
        }];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.scrollSpeed = 0.3;
        [self pc];
    }
    return _ic;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}


@end
