//
//  HomeNavBar.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeNavBar.h"

@implementation HomeNavBar

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
       
    }
    return self;
}

@end
