//
//  NavScrollView.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "NavScrollView.h"
@interface NavScrollView ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView * sv;
@end
@implementation NavScrollView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //1滚动视图
        UIScrollView * sv =[[UIScrollView alloc]init];
        self.sv=sv;
        sv.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
        [self addSubview:sv];
        //姿势图
        for (int i = 0; i<3 ; i++) {
            UIView *view1 = [[UIView alloc]init];
            view1.frame = CGRectMake(i*sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height);
            view1.backgroundColor = [UIColor whiteColor];
            [sv addSubview:view1];
            sv.bounces =NO;
            sv.showsHorizontalScrollIndicator = YES;
            sv.scrollEnabled = YES;
            sv.pagingEnabled = YES;
            
            sv.contentSize = CGSizeMake(3*sv.bounds.size.width, sv.bounds.size.height);
            
            [self addSubview:sv];
            if(i==0){
                //添加第1个视图的8个按钮
                [self addFirstView:view1];
            } else if(i ==1){
                //添加第2个视图的8个按钮
                [self addSecondView:view1];
            }else {
                //添加第3个视图的8个按钮
                [self addThirdView:view1];
            }

        }
        
        //1创建pagecontroller的实例
        UIPageControl* pc=[[UIPageControl alloc]init];
        self.pc=pc;
        //2设置frame
        pc.frame=CGRectMake(0, self.maskView.bounds.size.height-30, self.maskView.bounds.size.width, 30);
        //颜色
        pc.backgroundColor=[UIColor yellowColor];
        //3添加控制器view
        [self.sv addSubview:pc];
        //4配置pagecontroller
        pc.numberOfPages=3;
        //5配置提示符颜色
        pc.pageIndicatorTintColor=[UIColor redColor];
        //6配置选中的提示符的颜色
        pc.currentPageIndicatorTintColor=[UIColor blackColor];
        //关闭原点与用户的交互
        pc.userInteractionEnabled=NO;
    }
    return self;
}
/**************************************************************navView页面1Start**********************/
-(void)addFirstView:(UIView *)view1{
    //循环8个盒子 u847   u851
    for (int i=0; i<8; i++) {
        UIView *boxView = [[UIView alloc]initWithFrame:CGRectMake(i*SCREEN_WIDTH/4, 0, SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45)];
        UIButton *navBtn = [[UIButton alloc]init];
        navBtn.layer.masksToBounds = YES;
        navBtn.layer.cornerRadius = SCREEN_HEIGHT*.25*.45*0.55/2;
        self.navBtn = navBtn;
        [boxView addSubview:navBtn];
        [navBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.25*.45*0.2);
            make.size.with.height.equalTo(SCREEN_HEIGHT*.25*.45*0.55);
        }];
        navBtn.backgroundColor = [UIColor clearColor];
        UILabel *navLable = [[UILabel alloc]init];
        navLable.textColor = bgColor(151, 151, 151);
        navLable.font = [UIFont systemFontOfSize:12];
        navLable.textAlignment = NSTextAlignmentCenter;
        [boxView addSubview:navLable];
        [navLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.bottom.left.right.equalTo(0);
        }];
        if (i>3) {
            boxView.frame = CGRectMake((i-4)*SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45, SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45);
        }
        if (i == 0) {
            _lab1 = navLable;

            _bt1 = navBtn;
//            [_bt1 setImage:[UIImage imageNamed:@"home_seller"] forState:UIControlStateNormal];
            [_bt1 addTarget:self action:@selector(clickjstBusiness) forControlEvents:UIControlEventTouchUpInside];
        } else if(i == 1) {
                        _lab2 = navLable;
//            _lab2.text = @"吉时商圈";
//            boxView.backgroundColor = [UIColor blueColor];
            _bt2 = navBtn;
//            [_bt2 setImage:[UIImage imageNamed:@"home_area"] forState:UIControlStateNormal];
            [_bt2 addTarget:self action:@selector(clickjstEducation) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 2) {
                        _lab3 = navLable;
//            _lab3.text = @"吉时便民";
//            boxView.backgroundColor = [UIColor grayColor];
                        _bt3 = navBtn;
//            [_bt3 setImage:[UIImage imageNamed:@"home_people"] forState:UIControlStateNormal];
            [_bt3 addTarget:self action:@selector(clickjstGarage) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 3) {
            _lab4 = navLable;
//            _lab4.text = @"教育培训";
//            boxView.backgroundColor = [UIColor yellowColor];
            _bt4 = navBtn;
//            [_bt4 setImage:[UIImage imageNamed:@"home_teach"] forState:UIControlStateNormal];
            [_bt4 addTarget:self action:@selector(clickjstCircle) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 4) {
            _lab5 = navLable;
//            _lab5.text = @"旅游助手";
//            boxView.backgroundColor = [UIColor blackColor];
            _bt5 = navBtn;
//            [_bt5 setImage:[UIImage imageNamed:@"home_tour"] forState:UIControlStateNormal];
            [_bt5 addTarget:self action:@selector(clickjstConvenient) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 5) {
            _lab6 = navLable;
//            _lab6.text = @"诚信金融";
//            boxView.backgroundColor = [UIColor purpleColor];
            _bt6 = navBtn;
//            [_bt6 setImage:[UIImage imageNamed:@"home_finance"] forState:UIControlStateNormal];
            [_bt6 addTarget:self action:@selector(clickjstTour) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 6) {
            _lab7 = navLable;
//            _lab7.text = @"薪酬服务";
//            boxView.backgroundColor = [UIColor redColor];
            _bt7 = navBtn;
//            [_bt7 setImage:[UIImage imageNamed:@"home_payment"] forState:UIControlStateNormal];
            [_bt7 addTarget:self action:@selector(clickjstHonestFinance) forControlEvents:UIControlEventTouchUpInside];
        }else {
            _lab8 = navLable;
//            _lab8.text = @"车房租售";
//            boxView.backgroundColor = [UIColor blackColor];
            _bt8 = navBtn;
//            [_bt8 setImage:[UIImage imageNamed:@"home_garage"] forState:UIControlStateNormal];
            [_bt8 addTarget:self action:@selector(clickjstPayment) forControlEvents:UIControlEventTouchUpInside];
        }
        [view1 addSubview:boxView];
    }
}
-(void)clickjstBusiness
{
     [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTBUSUNESS" object:nil];
}
-(void)clickjstCircle
{
    NSLog(@"点击了吉时商圈");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTCRICLE" object:nil];
}
-(void)clickjstConvenient
{
    NSLog(@"点击了吉时便民");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTCONVENIENT" object:nil];
}
-(void)clickjstEducation
{
    NSLog(@"点击了教育培训");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTEDUCATION" object:nil];
}
-(void)clickjstTour
{
    NSLog(@"点击了旅游助手");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTTOUR" object:nil];
}
-(void)clickjstHonestFinance
{
    NSLog(@"点击了诚信金融");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTHONEST" object:nil];
}
-(void)clickjstPayment
{
    NSLog(@"点击了薪酬服务");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTPAYMENT" object:nil];
}
-(void)clickjstGarage
{
    NSLog(@"点击了车房租售");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTGARAGE" object:nil];
}
/**************************************************************navView页面1End**********************/

-(void)addSecondView:(UIView *)view1{
    //循环8个盒子 u847   u851
    for (int i=0; i<8; i++) {
        UIView *boxView = [[UIView alloc]initWithFrame:CGRectMake(i*SCREEN_WIDTH/4, 0, SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45)];
        UIButton *navBtn = [[UIButton alloc]init];
        navBtn.layer.masksToBounds = YES;
        navBtn.layer.cornerRadius = 20;
        self.navBtn = navBtn;
        [boxView addSubview:navBtn];
        [navBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.25*.45*0.2);
            make.size.with.height.equalTo(SCREEN_HEIGHT*.25*.45*0.55);
        }];
        UILabel *navLable = [[UILabel alloc]init];
        navLable.textColor = bgColor(151, 151, 151);
        navLable.font = [UIFont systemFontOfSize:12];
        navLable.textAlignment = NSTextAlignmentCenter;
        [boxView addSubview:navLable];
        [navLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.bottom.left.right.equalTo(0);
        }];
        if (i>3) {
            boxView.frame = CGRectMake((i-4)*SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45, SCREEN_WIDTH/4, SCREEN_HEIGHT*.25*.45);
        }
        if (i == 0) {
            _lab9 = navLable;
            _bt9 = navBtn;
            [navBtn addTarget:self action:@selector(clickjstGame) forControlEvents:UIControlEventTouchUpInside];
        } else if(i == 1) {
        }else if(i == 2) {
 
        }else if(i == 3) {

        }else if(i == 4) {
          
        }else if(i == 5) {
           
        }else if(i == 6) {
          
        }else {
           
        }
        [view1 addSubview:boxView];
    }
}
-(void)clickjstGame
{
    NSLog(@"点击了游戏玩家");
    [[NSNotificationCenter defaultCenter] postNotificationName:@"JSTGAME" object:nil];
}
-(void)addThirdView:(UIView *)view1{
//    UIButton *btn1 = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 60, 40)];
//    btn1.backgroundColor = [UIColor redColor];
//       [btn1 setTitle:@"测试视图" forState:UIControlStateNormal];
//    [view1 addSubview:btn1];
}
@end
