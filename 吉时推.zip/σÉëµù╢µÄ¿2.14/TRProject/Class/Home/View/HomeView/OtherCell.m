//
//  OtherCell.m
//  TRProject
//
//  Created by liweidong on 16/12/13.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "OtherCell.h"

@implementation OtherCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        _iconIV.clipsToBounds = YES;
        _iconIV.layer.cornerRadius = 4;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(80, 60));
        }];
    }
    return _iconIV;
}
- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 40));
        }];
    }
    return _titleLb;
}
- (UILabel *)subtitleLb {
    if(_subtitleLb == nil) {
        _subtitleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_subtitleLb];
        _subtitleLb.numberOfLines = 0;
        _subtitleLb.font = [UIFont systemFontOfSize:11];
        [_subtitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLb.mas_right).equalTo(5);
            make.top.equalTo(self.iconIV);
            make.right.equalTo(-10);
            make.height.equalTo(40);
        }];

    }
    return _subtitleLb;
}
- (UILabel *)addrLb {
    if(_addrLb == nil) {
        _addrLb = [[UILabel alloc] init];
        [self.contentView addSubview:_addrLb];
        _addrLb.numberOfLines = 0;
        _addrLb.font = [UIFont systemFontOfSize:11];
        [_addrLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLb);
            make.bottom.equalTo(self.iconIV);
        }];

    }
    return _addrLb;
}
- (UILabel *)distanceLb {
    if(_distanceLb == nil) {
        _distanceLb = [[UILabel alloc] init];
        [self.contentView addSubview:_distanceLb];
        _distanceLb.numberOfLines = 0;
        _distanceLb.font = [UIFont systemFontOfSize:11];
        [_distanceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.subtitleLb);
            make.bottom.equalTo(self.iconIV);
        }];
    }
    return _distanceLb;
}


@end
