//
//  WeatherAndBusView.h
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeatherAndBusCell : UITableViewCell
/* 天气图标 */
@property(nonatomic,strong)UIView * imgMaskView;
@property(nonatomic,strong)UIImageView * weatherImg;
/* maskView */
@property(nonatomic,strong)UIView * weatherMaskView;

@property(nonatomic,strong)UILabel *currentLable;//当前温度
@property(nonatomic,strong)UIImageView *currentIcon;//当前温度图标
@property(nonatomic,strong)UILabel *descLable;//天气描述
@property(nonatomic,strong)UILabel *moistureLable;//相对湿度
@property(nonatomic,strong)UILabel *windLable;//风力
@property(nonatomic,strong)UILabel *qualityLable;//88良

@property(nonatomic,strong)UIView * busMaskView;
@property(nonatomic,strong)UIImageView * busImg;
@property(nonatomic,strong)UIImageView * todayImg;
@property(nonatomic,strong)UIImageView * tomottowImg;



@end
