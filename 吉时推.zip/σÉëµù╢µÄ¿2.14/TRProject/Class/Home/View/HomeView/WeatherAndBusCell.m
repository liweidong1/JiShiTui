//
//  WeatherAndBusView.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "WeatherAndBusCell.h"

@interface WeatherAndBusCell ()

@end
@implementation WeatherAndBusCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        [self imgMaskView];
        [self weatherImg];
        [self weatherMaskView];
        [self busMaskView];
    }
    return self;
}
- (UIView *)imgMaskView {
    if(_imgMaskView == nil) {
        _imgMaskView = [[UIView alloc] init];
        _imgMaskView = [[UIImageView alloc] init];
        [self addSubview:_imgMaskView];
        [_imgMaskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.bottom.equalTo(0);
            make.size.width.equalTo(SCREEN_WIDTH*.2);
        }];
        _weatherImg = [[UIImageView alloc] init];
        _weatherImg.image = [UIImage imageNamed:@"home_temter"];
        //_weatherImg.backgroundColor = [UIColor redColor];
        [self.imgMaskView addSubview:_weatherImg];
        [_weatherImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.2*0.5, SCREEN_HEIGHT*0.12*0.7));
        }];

    }
    return _imgMaskView;
}


- (UIView *)weatherMaskView {
    if(_weatherMaskView == nil) {
        _weatherMaskView = [[UIView alloc] init];
        //_weatherMaskView.backgroundColor = [UIColor redColor];
        [self addSubview:_weatherMaskView];
        [_weatherMaskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(0);
            make.left.equalTo(self.imgMaskView.mas_right).equalTo(0);
            make.size.width.equalTo(SCREEN_WIDTH*.5);
        }];
        // 当前温度   图标    晴间多云
        _currentLable = [[UILabel alloc]init];
       // _currentLable.backgroundColor = [UIColor grayColor];
        _currentLable.text = @"2℃";
        _currentLable.textColor = bgColor(74, 156, 171);
        _currentLable.font = [UIFont systemFontOfSize:20];
        [_weatherMaskView addSubview:_currentLable];
        [_currentLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(SCREEN_HEIGHT*.12*.1);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15, SCREEN_HEIGHT*.12*0.8/3));
        }];
        _currentIcon = [[UIImageView alloc]init];
        _currentIcon.image = [UIImage imageNamed:@"home_weather"];
        //_currentIcon.backgroundColor = [UIColor blueColor];
        [_weatherMaskView addSubview:_currentIcon];
        [_currentIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.12*.1);
            make.left.equalTo(self.currentLable.mas_right).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_HEIGHT*.12*0.8/3));
        }];
        _descLable = [[UILabel alloc]init];
        //_descLable.backgroundColor = [UIColor purpleColor];
        _descLable.font = [UIFont systemFontOfSize:12];
        _descLable.textColor = bgColor(112, 96, 77);
        _descLable.text = @"晴间多云";
        [_weatherMaskView addSubview:_descLable];
        [_descLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.12*.1);
            make.left.equalTo(self.currentIcon.mas_right).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3-SCREEN_HEIGHT*.12*.1, SCREEN_HEIGHT*.12*0.8/3));
        }];
       // 小图+相对温度：39% 小图+东北风1级
        UIImageView *moistureIcon = [[UIImageView alloc]init];
        //moistureIcon.backgroundColor = [UIColor blueColor];
        moistureIcon.image = [UIImage imageNamed:@"home_water"];
        [_weatherMaskView addSubview:moistureIcon];
        [moistureIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.currentLable.mas_bottom).equalTo(SCREEN_HEIGHT*.12*0.8/3*.2);
            make.left.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.04, SCREEN_HEIGHT*.12*0.8/3*.6));
        }];

        _moistureLable = [[UILabel alloc]init];
        _moistureLable.text  =@"相对温度:39%";
        //_moistureLable.backgroundColor = [UIColor grayColor];
        _moistureLable.textColor = bgColor(112, 96, 77);
        _moistureLable.font = [UIFont systemFontOfSize:12];
        [_weatherMaskView addSubview:_moistureLable];
        [_moistureLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(moistureIcon.mas_right).equalTo(0);
            make.top.equalTo(self.currentIcon.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.45, SCREEN_HEIGHT*.12*0.8/3));
        }];
        UIImageView *windIcon = [[UIImageView alloc]init];
        windIcon.image  =[UIImage imageNamed:@"home_wind"];
        //windIcon.backgroundColor = [UIColor blueColor];
        [_weatherMaskView addSubview:windIcon];
        [windIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.descLable.mas_bottom).equalTo(SCREEN_HEIGHT*.12*0.8/3*.2);
            make.left.equalTo(self.moistureLable.mas_right).equalTo(-2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.04, SCREEN_HEIGHT*.12*0.8/3*.6));
        }];
        _windLable = [[UILabel alloc]init];
        _windLable.text = @"东北风1级";
        //_windLable.backgroundColor = [UIColor greenColor];
        _windLable.textColor = bgColor(112, 96, 77);
        _windLable.font = [UIFont systemFontOfSize:12];
        [_weatherMaskView addSubview:_windLable];
        [_windLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(windIcon.mas_right).equalTo(0);
            make.top.equalTo(self.descLable.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.45, SCREEN_HEIGHT*.12*0.8/3));
        }];
        //小图88良
        UIImageView *qualityIcon = [[UIImageView alloc]init];
        qualityIcon.image = [UIImage imageNamed:@"home_leaf"];
        //qualityIcon.backgroundColor = [UIColor blueColor];
        [_weatherMaskView addSubview:qualityIcon];
        [qualityIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.moistureLable.mas_bottom).equalTo(SCREEN_HEIGHT*.12*0.8/3*.2);
            make.left.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.04, SCREEN_HEIGHT*.12*0.8/3*.6));
        }];
        _qualityLable = [[UILabel alloc]init];
        _qualityLable.font = [UIFont systemFontOfSize:12];
        _qualityLable.textColor = bgColor(74, 156, 171);
        _qualityLable.text = @"88良";
        [_weatherMaskView addSubview:_qualityLable];
        [_qualityLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(qualityIcon.mas_right).equalTo(0);
            make.top.equalTo(self.moistureLable.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5*.5, SCREEN_HEIGHT*.12*0.8/3));
        }];
    }
    return _weatherMaskView;
}

- (UIView *)busMaskView {
    if(_busMaskView == nil) {
        _busMaskView = [[UIView alloc] init];
        //_busMaskView.backgroundColor = [UIColor yellowColor];
        [self addSubview:_busMaskView];
        [_busMaskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.top.bottom.equalTo(0);
            make.size.width.equalTo(SCREEN_WIDTH*.3);
        }];
        //图片  3张
        _busImg = [[UIImageView alloc]init];
        _busImg.image = [UIImage imageNamed:@"home_car"];
        //_busImg.backgroundColor = [UIColor blueColor];
        [_busMaskView addSubview:_busImg];
        [_busImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(0);
            make.centerY.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.11);
            make.height.equalTo(SCREEN_HEIGHT*.12*.7);
        }];
        _todayImg = [[UIImageView alloc]init];
        _todayImg.image =  [UIImage imageNamed:@"bg_data"];
        [_busMaskView addSubview:_todayImg];
        [_todayImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.12*.15);
            make.left.equalTo(self.busImg.mas_right).equalTo(SCREEN_WIDTH*.02);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15, SCREEN_HEIGHT*.12*.35));
        }];
        UILabel * lab1 = [[UILabel alloc]init];
        lab1.textColor = bgColor(74, 156, 171);
        //lab1.backgroundColor = [UIColor redColor];
        lab1.text  = @"1";
        lab1.textAlignment =  NSTextAlignmentCenter;
        lab1.font  = [UIFont systemFontOfSize:20];
        [_busMaskView addSubview:lab1];
        [lab1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.12*.15);
            make.left.equalTo(self.busImg.mas_right).equalTo(SCREEN_WIDTH*.02);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15*.5, SCREEN_HEIGHT*.12*.35));
        }];
        UILabel * lab2 = [[UILabel alloc]init];
        lab2.textColor = bgColor(74, 156, 171);
        //lab2.backgroundColor = [UIColor grayColor];
        lab2.textAlignment =  NSTextAlignmentCenter;
        lab2.font  = [UIFont systemFontOfSize:20];
        lab2.text  = @"6";
        [_busMaskView addSubview:lab2];
        [lab2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.12*.15);
            make.left.equalTo(self.busImg.mas_right).equalTo(SCREEN_WIDTH*.02+SCREEN_WIDTH*.15*.5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15*.5, SCREEN_HEIGHT*.12*.35));
        }];
        _tomottowImg = [[UIImageView alloc]init];
        _tomottowImg.image =  [UIImage imageNamed:@"home_ming"];
        [_busMaskView addSubview:_tomottowImg];
        [_tomottowImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.todayImg.mas_bottom).equalTo(0);
            make.left.equalTo(self.busImg .mas_right).equalTo(SCREEN_WIDTH*.02);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.16, SCREEN_HEIGHT*.12*.35));
        }];
        UILabel * lab3 = [[UILabel alloc]init];
        lab3.textColor = bgColor(151, 151, 151);
        //lab3.backgroundColor = [UIColor grayColor];
        lab3.textAlignment =  NSTextAlignmentCenter;
        lab3.text  = @"2";
        [_busMaskView addSubview:lab3];
        [lab3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab1.mas_bottom).equalTo(0);
            make.left.equalTo(self.busImg.mas_right).equalTo(SCREEN_WIDTH*.02);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15*.5, SCREEN_HEIGHT*.12*.35));
        }];
        UILabel * lab4 = [[UILabel alloc]init];
        lab4.textColor = bgColor(151, 151, 151);
        //lab4.backgroundColor = [UIColor grayColor];
        lab4.textAlignment =  NSTextAlignmentCenter;
        lab4.text  = @"7";
        [_busMaskView addSubview:lab4];
        [lab4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(lab2.mas_bottom).equalTo(0);
            make.left.equalTo(self.busImg.mas_right).equalTo(SCREEN_WIDTH*.02+SCREEN_WIDTH*.15*.45);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15*.5, SCREEN_HEIGHT*.12*.35));
        }];
    }
    return _busMaskView;
}



@end
