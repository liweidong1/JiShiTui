//
//  SearchCell.h
//  TRProject
//
//  Created by liweidong on 16/12/22.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
/////////////////////=========== 商品
@interface ProductCell : UITableViewCell
@property (nonatomic) UIImageView *iconIV;
@property (nonatomic) UILabel *titleLb;//商品名
@property (nonatomic) UILabel *subtitleLb;//商品描述
@property (nonatomic) UILabel *discountLb;//折扣价
@property (nonatomic) UILabel *sourcesLb;//原价
@property (nonatomic) UILabel *quantityLb;//库存
@end
///////////////////////=========== 商家
@interface ShopCell : UITableViewCell
@property (nonatomic) UIImageView *iconIV;
@property (nonatomic) UILabel *titleLb;//商家名
@property (nonatomic) UILabel *subtitleLb;//商家描述
@property (nonatomic) UILabel *addressLb;//精确地址

@end
/////////////////////////=========== 商圈
@interface CoordCell : UITableViewCell
@property (nonatomic) UIImageView *iconIV;
@property (nonatomic) UILabel *titleLb;//商圈名

@end
