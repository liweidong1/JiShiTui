//
//  SearchCell.m
//  TRProject
//
//  Created by liweidong on 16/12/22.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "SearchCell.h"

@implementation ProductCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        _iconIV.clipsToBounds = YES;
        _iconIV.layer.cornerRadius = 4;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(80, 60));
        }];
    }
    return _iconIV;
}
- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.right.equalTo(-10);
            make.height.lessThanOrEqualTo(40);
        }];
    }
    return _titleLb;
}
- (UILabel *)subtitleLb {
    if(_subtitleLb == nil) {
        _subtitleLb = [[UILabel alloc] init];
        _subtitleLb.textColor = bgColor(173, 173, 173);
        [self.contentView addSubview:_subtitleLb];
        _subtitleLb.numberOfLines = 0;
        _subtitleLb.font = [UIFont systemFontOfSize:11];
        [_subtitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLb);
            make.bottom.equalTo(self.iconIV);
        }];
        
    }
    return _subtitleLb;
}
- (UILabel *)discountLb {
    if(_discountLb == nil) {
        _discountLb = [[UILabel alloc] init];
        [self.contentView addSubview:_discountLb];
        _discountLb.textColor = bgColor(0, 168, 194);
        _discountLb.font = [UIFont systemFontOfSize:16];
        [_discountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV);
            make.left.equalTo(SCREEN_WIDTH*0.6);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.3, 40));
        }];
    }
    return _discountLb;
}
- (UILabel *)sourcesLb {
    if( _sourcesLb == nil) {
        _sourcesLb = [[UILabel alloc] init];
        [self.contentView addSubview:_sourcesLb];
        _sourcesLb.textColor = bgColor(173, 173, 173);
        _sourcesLb.font = [UIFont systemFontOfSize:12];
        [_sourcesLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.iconIV);
            make.left.equalTo(SCREEN_WIDTH*0.6);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.3, 40));
        }];
    }
    return _sourcesLb;
}
- (UILabel *)quantityLb {
    if(_quantityLb == nil) {
        _quantityLb = [[UILabel alloc] init];
        [self.contentView addSubview:_quantityLb];
        _quantityLb.numberOfLines = 0;
        _quantityLb.font = [UIFont systemFontOfSize:11];
        [_quantityLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.titleLb);
            make.bottom.equalTo(self.iconIV);
        }];
    }
    return _quantityLb;
}

@end


@implementation ShopCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        _iconIV.clipsToBounds = YES;
        _iconIV.layer.cornerRadius = 4;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(80, 60));
        }];
    }
    return _iconIV;
}
- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.right.equalTo(-10);
            make.height.lessThanOrEqualTo(40);
        }];
    }
    return _titleLb;
}
- (UILabel *)subtitleLb {
    if(_subtitleLb == nil) {
        _subtitleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_subtitleLb];
        _subtitleLb.textColor = bgColor(173, 173, 173);
        _subtitleLb.numberOfLines = 0;
        _subtitleLb.font = [UIFont systemFontOfSize:11];
        [_subtitleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.titleLb);
            make.bottom.equalTo(self.iconIV);
        }];
        
    }
    return _subtitleLb;
}

- (UILabel *)addressLb {
    if(_addressLb == nil) {
        _addressLb = [[UILabel alloc] init];
        [self.contentView addSubview:_addressLb];
        _addressLb.numberOfLines = 0;
        _addressLb.font = [UIFont systemFontOfSize:11];
        [_addressLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.titleLb);
            make.bottom.equalTo(self.iconIV);
        }];
    }
    return _addressLb;
}
@end


@implementation CoordCell
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
//        _iconIV.clipsToBounds = YES;
//        _iconIV.layer.cornerRadius = 30;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(80, 60));
        }];
    }
    return _iconIV;
}
- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.textColor = bgColor(0, 175, 196);
        _titleLb.textAlignment = NSTextAlignmentCenter;
        _titleLb.numberOfLines = 0;
        _titleLb.font = [UIFont systemFontOfSize:15];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.right.equalTo(-SCREEN_WIDTH*0.05);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.6, 40));
        }];
    }
    return _titleLb;
}

@end
