//
//  BaseTableHeaderView.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseTableHeaderView.h"
#import "HomeHeaderCell.h"
#import "DiscountCell.h"
#import "BusinessViewModel.h"
@interface BaseTableHeaderView()<UITableViewDataSource, UITableViewDelegate,HomeHeaderCellDelegate, HomeHeaderCellDataSource>
@property (strong, nonatomic) NSMutableArray *mutableArray;
@property (strong, nonatomic) BusinessViewModel *businessVM;

@property (assign, nonatomic) NSInteger adRows;
@property (strong, nonatomic) NSURL *adUrl;
@end
static NSString * const reuseIdentifier = @"cellsss";
static NSString * const reuseIdentifier1 = @"cellsss1";
@implementation BaseTableHeaderView
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        //tableView创建
        //self.backgroundColor = [UIColor clearColor];
        self.delegate =self;
        self.dataSource = self;
        //设定tableView分割线的颜色
        self.separatorColor = [UIColor colorWithWhite:1 alpha:0.2];
        self.scrollEnabled = NO;
        
        //定义3个属性，来改变广告栏中的值
        JSTWeakSelf
        [weakSelf.businessVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf reloadData];
            [weakSelf endHeaderRefresh];
        }];


    }
    return self;
}
#pragma mark - HomeHeaderCellDelegate
- (NSInteger)numberOfItemInCell:(HomeHeaderCell *)cell {
    NSLog(@"%ld",self.businessVM.indexNum);
    return  self.businessVM.indexNum;
}

- (NSURL *)iconURLForItemInCell:(HomeHeaderCell *)cell atIndex:(NSInteger)index {
    return [self.businessVM indexIconURLForRow:index];
}

- (void)homeHeaderCell:(HomeHeaderCell *)cell didSelectedIconAtIndex:(NSInteger)index {
    //跳转到对应的界面
    NSLog(@"%ld",index);
    NSString * bannerRowStr = [NSString stringWithFormat:@"%ld",index];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"BannerHTML" object:self userInfo:@{@"SelectedBannerRow" : bannerRowStr}];
}

//#pragma mark --- UITableViewDataSourceDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}
//#pragma mark tableViewDelegate
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
    
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        //滚动视图
        HomeHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier forIndexPath:indexPath];
        cell.dataSource = self;
        cell.delegate = self;
        [cell reloaedData];
        //自定义maskView
        UIView * maskView = [[UIView alloc]initWithFrame:CGRectMake(0, SCREEN_WIDTH * 615 / 1125 *.88, SCREEN_WIDTH, SCREEN_WIDTH * 615 / 1125*.12)];
        maskView.backgroundColor = [UIColor blackColor];
        maskView.userInteractionEnabled = NO;
        maskView.alpha = .5;
        //图片   关注人数560
        UILabel * lab = [[UILabel alloc]init];
        _personCountLab = lab;
        [NavScrollNetworking getPayAttentionInfoCompletionHandler:^(BusinessPayAttentionInfoModel *model, NSError *error) {
        NSLog(@"%ld",model.count);
            _personCountLab = lab;
        lab.text = [NSString stringWithFormat:@"关注人数%ld",model.count];
        }];
        
        lab.font = [UIFont systemFontOfSize:12];
        lab.textColor = [UIColor whiteColor];
        [maskView addSubview:lab];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.top.bottom.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH *.2);
        }];
        UIImageView * iv = [[UIImageView alloc]init];
        iv.image = [UIImage imageNamed:@"store_m"];
        [maskView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.right.equalTo(lab.mas_left).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH * 615 / 1125*.08, SCREEN_WIDTH * 615 / 1125*.08));
        }];
        [cell.contentView addSubview:maskView];
        return cell;
    } else {
                //优惠商品
        DiscountCell * cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier1 forIndexPath:indexPath];
        return cell;
    }
    return [UITableViewCell new];
}
//自动设置高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return SCREEN_WIDTH * 615 / 1125;
    } else {
        return 44;
    }
}

- (BusinessViewModel *)businessVM {
	if(_businessVM == nil) {
		_businessVM = [[BusinessViewModel alloc] init];
	}
	return _businessVM;
}

@end
