//
//  BusicessCollectionViewCell.h
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BusicessCollectionViewCell : UICollectionViewCell
@property (nonatomic) UIImageView *iconIV;
@property (nonatomic) UILabel *titleLb;  //商品名
@property (nonatomic) UILabel *soldLb; //已售
@property (nonatomic) UILabel *discountLb;//折扣价
@property (nonatomic) UILabel *sourcesLb;//原价
@end
