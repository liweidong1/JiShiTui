//
//  BusicessCollectionViewCell.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BusicessCollectionViewCell.h"

@implementation BusicessCollectionViewCell
//因为三个控件一定会被调用赋值, 所以就不必须重写init方法进行调用了.
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        //切掉超出的部分
        _iconIV.clipsToBounds = YES;
        _iconIV.image = [UIImage imageNamed:@"header1"];
        [self.contentView addSubview:_iconIV];
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.equalTo(0);

        }];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        
    }
    return _iconIV;
}
- (UILabel *)soldLb {
    if(_soldLb == nil) {
        _soldLb = [[UILabel alloc] init];
        [self.contentView addSubview:_soldLb];
        _soldLb.font = [UIFont systemFontOfSize:11.0];
        
        _soldLb.layer.borderColor = [[UIColor grayColor]CGColor];
        
        _soldLb.layer.borderWidth = 0.5f;
        
        _soldLb.layer.masksToBounds = YES;

        [_soldLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(0);
            make.centerY.equalTo(self.titleLb);
            make.width.equalTo(50);
            //左边距离titleLb的右边,大于等于8像素
            make.left.greaterThanOrEqualTo(self.titleLb.mas_right).offset(8);
        }];
        _soldLb.textColor = [UIColor darkGrayColor];
        _soldLb.textAlignment = NSTextAlignmentRight;
    }
    return _soldLb;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        _titleLb.font = [UIFont systemFontOfSize:13];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(5);
            make.height.equalTo(30).priorityHigh();
            make.bottom.equalTo(self.discountLb.mas_top).equalTo(0);
            make.top.equalTo(self.iconIV.mas_bottom);
        }];
    }
    return _titleLb;
}
- (UILabel *)discountLb {
    if(_discountLb == nil) {
        _discountLb = [[UILabel alloc] init];
        [self.contentView addSubview:_discountLb];
        _discountLb.textColor = bgColor(0, 168, 194);
        _discountLb.font = [UIFont systemFontOfSize:16];
        [_discountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(5);
            make.height.equalTo(30).priorityHigh();
            make.bottom.equalTo(0);
            make.top.equalTo(self.titleLb.mas_bottom).equalTo(4);

        }];
    }
    return _discountLb;
}
- (UILabel *)sourcesLb {
    if( _sourcesLb == nil) {
        _sourcesLb = [[UILabel alloc] init];
        [self.contentView addSubview:_sourcesLb];
        _sourcesLb.textColor = bgColor(173, 173, 173);
        _sourcesLb.font = [UIFont systemFontOfSize:9.0];
        [_sourcesLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-5);
            make.centerY.equalTo(self.discountLb);
            make.width.equalTo(60);
            //左边距离titleLb的右边,大于等于8像素
            make.left.greaterThanOrEqualTo(self.discountLb.mas_right).offset(8);
        }];
    }
    return _sourcesLb;
}
@end
