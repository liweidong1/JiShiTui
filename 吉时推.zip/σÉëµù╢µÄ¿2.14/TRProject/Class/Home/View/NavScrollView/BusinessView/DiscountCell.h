//
//  DiscountCell.h
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DiscountCell : UITableViewCell
/**白色视图 */
@property (nonatomic, strong) UIView *whiteView;
@property (nonatomic, strong) UIView *viewLeft;
@property (nonatomic, strong) UILabel *lab;
@property (nonatomic, strong) UIView *viewRight;
@end
