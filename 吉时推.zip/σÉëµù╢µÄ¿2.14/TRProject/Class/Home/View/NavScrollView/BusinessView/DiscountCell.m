//
//  DiscountCell.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "DiscountCell.h"

@implementation DiscountCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = bgColor(241, 241, 241);
        [self viewLeft];
        [self viewRight];
        [self lab];
        [self whiteView];
    }
    return self;
}
- (UIView *)whiteView {
    if(_whiteView == nil) {
        _whiteView = [[UIView alloc] init];
        _whiteView.backgroundColor =  [UIColor whiteColor];
        [self.contentView addSubview:_whiteView];
        [_whiteView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.75, 30));
        }];
    }
    return _whiteView;
}
- (UIView *)viewLeft {
    if(_viewLeft == nil) {
        _viewLeft = [[UIView alloc]init];
        _viewLeft.backgroundColor = [UIColor lightGrayColor];
        [self.whiteView addSubview:_viewLeft];
        [_viewLeft mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(SCREEN_WIDTH*.15);
            make.width.equalTo(SCREEN_WIDTH*.1);
            make.height.equalTo(1);
        }];
        
    }
    return _viewLeft;
}

- (UILabel *)lab {
    if(_lab == nil) {
        _lab = [[UILabel alloc] init];
        _lab = [[UILabel alloc]init];
        _lab.textColor = [UIColor lightGrayColor];
        _lab.text = @"特惠商品";
        _lab.textAlignment = NSTextAlignmentCenter;
        [self.whiteView addSubview:_lab];
        [_lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.4, 40));
        }];
    }
    return _lab;
}

- (UIView *)viewRight {
    if(_viewRight == nil) {
        _viewRight = [[UIView alloc]init];
        _viewRight.backgroundColor = [UIColor lightGrayColor];
        [self.whiteView addSubview:_viewRight];
        [_viewRight mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.right.equalTo(-SCREEN_WIDTH*.15);
            make.width.equalTo(SCREEN_WIDTH*.1);
            make.height.equalTo(1);
        }];
    }
    return _viewRight;
}



@end
