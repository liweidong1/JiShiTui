//
//  GoodsDetailCell.h
//  TRProject
//
//  Created by liweidong on 16/12/26.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

/////////////////////=========== 商品
@interface GoodsHeaderCell : UITableViewCell
@property (nonatomic) UIImageView *iconIV;
@property(nonatomic,strong)UIView * maskDeView;
@property(nonatomic,strong)UIImageView *countImg;
@property(nonatomic,strong)UILabel *countLab;

@property(nonatomic,strong)UILabel *soldLab;//已售
@property (nonatomic) UILabel *discountLb;//折扣价
@property (nonatomic) UILabel *sourcesLb;//原价
@property (nonatomic) UILabel *offlineLab;//线下自取
@end
/////////////////////=========== 地址
@interface GoodsAdressCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLab;//标题
@property(nonatomic,strong)UIImageView *adressImg;
@property(nonatomic,strong)UILabel *adressLab;//地点
@property(nonatomic,strong)UILabel *distanceLab;//距离
@property(nonatomic,strong)UIButton *phoneBtn;//电话

@end
/////////////////////=========== 商品详情
@interface GoodsDetailsCell : UITableViewCell
@property(nonatomic,strong)UIButton *goodsDetailBtn;//商品详情
@end
/////////////////////=========== 评价
@interface GoodsComentCell : UITableViewCell
@property(nonatomic,strong)UILabel *userCommentLab;//用户评价数
@property(nonatomic,strong)UILabel *priceLab;//全部
@property(nonatomic,strong)UILabel *environmentLab;//好评
@property(nonatomic,strong)UILabel *serviceLab;//差评
@property(nonatomic,strong)UILabel *ratioLab;//折算率
//@property(nonatomic,strong)UIImageView *commentImg;//评价头像
//@property(nonatomic,strong)UILabel *commentCount;//评价头像
@end
/////////////////////=========== 评价cell
@interface GoodsCommentDetailCell : UITableViewCell
@property(nonatomic,strong)UIImageView *userImg;//用户头像
@property(nonatomic,strong)UILabel *userPhoneLab;//用户手机号
@property(nonatomic,strong)UILabel *userCommentTimeLab;//用户评价时间
@property(nonatomic,strong)UILabel *userdetailLab;//用户评价详情
@property(nonatomic,strong)UILabel *ratioLab;//好评 差评
@property(nonatomic,strong)UIImageView *commentImg;//评价头像
@property(nonatomic,strong)UILabel *commentCount;//评价数量

//此属性表示cell拥有一个向外部通知按钮被点击的能力.
//至于上级用不用, 是上级的事情
@property (nonatomic, copy) void(^commentBtnClicked)(GoodsCommentDetailCell *cell);

@end
