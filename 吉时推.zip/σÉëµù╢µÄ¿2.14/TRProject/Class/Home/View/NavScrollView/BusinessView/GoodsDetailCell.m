//
//  GoodsDetailCell.m
//  TRProject
//
//  Created by liweidong on 16/12/26.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "GoodsDetailCell.h"
/////////////////////=========== 商品
@implementation GoodsHeaderCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
        [self maskDeView];
        [self countImg];
        [self countLab];
        [self soldLab];
        
    }
    return self;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        _iconIV.userInteractionEnabled = YES;
        [self.contentView addSubview:_iconIV];
        _iconIV.contentMode = UIViewContentModeScaleAspectFill;
        _iconIV.clipsToBounds = YES;
        _iconIV.layer.cornerRadius = 4;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.height.equalTo(SCREEN_HEIGHT*.3);
        }];
    }
    return _iconIV;
}
- (UIView *) maskDeView {
    if(_maskDeView == nil) {
        _maskDeView = [[UIView alloc] init];
        [self.iconIV addSubview:_maskDeView];
        _maskDeView.backgroundColor = [UIColor blackColor];
        _maskDeView.alpha = .5;
        [_maskDeView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.equalTo(0);
            make.height.equalTo(SCREEN_HEIGHT*.04);
        }];
    }
    return _maskDeView;
}


- (UIImageView *)countImg {
    if(_countImg == nil) {
        _countImg = [[UIImageView alloc] init];
        _countImg.image = [UIImage imageNamed:@"store_glance"];
        [self.maskDeView addSubview:_countImg];
        [_countImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(SCREEN_HEIGHT*.012);
            make.left.equalTo(SCREEN_HEIGHT*.01);
            make.bottom.equalTo(-SCREEN_HEIGHT*.012);
            make.width.equalTo(SCREEN_HEIGHT*.03);
        }];
    }
    return _countImg;
}

- (UILabel *)countLab {
    if(_countLab == nil) {
        _countLab = [[UILabel alloc] init];
        _countLab.text = @"浏览次数 50";
        _countLab.textColor = bgColor(243, 239, 231);
        _countLab.font = [UIFont systemFontOfSize:12];
        [self.maskDeView addSubview:_countLab];
        [_countLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.countImg.mas_right).equalTo(0);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3, SCREEN_HEIGHT*.03));
        }];

    }
    return _countLab;
}

- (UILabel *)soldLab {
    if(_soldLab == nil) {
        _soldLab = [[UILabel alloc] init];
        _soldLab.backgroundColor = bgColor(0, 177, 200);
        _soldLab.text = @"已售500";
        _soldLab.textAlignment = NSTextAlignmentCenter;
        _soldLab.textColor = [UIColor whiteColor];
        [self.iconIV addSubview:_soldLab];
        [_soldLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.28, SCREEN_HEIGHT*.06));
        }];
    }
    return _soldLab;
}

- (UILabel *)discountLb {
    if(_discountLb == nil) {
        _discountLb = [[UILabel alloc] init];
        [self.contentView addSubview:_discountLb];
        _discountLb.textColor = bgColor(0, 168, 194);
        _discountLb.font = [UIFont systemFontOfSize:30];
        [_discountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(0);
            make.left.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.3, SCREEN_HEIGHT*.08));
        }];
    }
    return _discountLb;
}

- (UILabel *)sourcesLb {
    if( _sourcesLb == nil) {
        _sourcesLb = [[UILabel alloc] init];
        [self.contentView addSubview:_sourcesLb];
        _sourcesLb.textColor = bgColor(173, 173, 173);
        _sourcesLb.font = [UIFont systemFontOfSize:14];
        [_sourcesLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV.mas_bottom).equalTo(SCREEN_HEIGHT*.023);
            make.left.equalTo(self.discountLb.mas_right).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3, SCREEN_HEIGHT*.04));
        }];
    }
    return _sourcesLb;
}
- (UILabel *)offlineLab {
    if(_offlineLab == nil) {
        _offlineLab = [[UILabel alloc] init];
        [self.contentView addSubview:_offlineLab];
        _offlineLab.textColor = [UIColor redColor];
        _offlineLab.font = [UIFont systemFontOfSize:14];
        _offlineLab.textAlignment = NSTextAlignmentRight;
        _offlineLab.text = @"此商品需线下自取";
        [_offlineLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.discountLb.mas_bottom).equalTo(2);
            make.right.equalTo(-5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, SCREEN_HEIGHT*.06));
        }];
    }
    return _offlineLab;
}
@end
/////////////////////=========== 地址
@implementation GoodsAdressCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)titleLab {
    if( _titleLab == nil) {
        _titleLab = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLab];
        _titleLab.font = [UIFont systemFontOfSize:20];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(5);
            make.top.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3, SCREEN_HEIGHT*.05));
        }];
    }
    return _titleLab;
}
- (UIImageView *)adressImg {
    if(_adressImg == nil) {
        _adressImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_adressImg];
        _adressImg.image = [UIImage imageNamed:@"store_fixed"];
        [_adressImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(5);
            make.top.equalTo(self.titleLab.mas_bottom).equalTo( SCREEN_HEIGHT*.015);
            make.size.equalTo(CGSizeMake(SCREEN_HEIGHT*.015, SCREEN_HEIGHT*.02));
        }];
    }
    return _adressImg;
}

- (UILabel *)adressLab {
    if( _adressLab == nil) {
        _adressLab = [[UILabel alloc] init];
        [self.contentView addSubview:_adressLab];
        _adressLab.font = [UIFont systemFontOfSize:12];
        [_adressLab mas_makeConstraints:^(MASConstraintMaker *make) {
         make.left.equalTo(self.adressImg.mas_right).equalTo(2);
            make.top.equalTo(self.titleLab.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT*.05));
        }];
    }
    return _adressLab;
}
- (UILabel *)distanceLab {
    if( _distanceLab == nil) {
        _distanceLab = [[UILabel alloc] init];
        [self.contentView addSubview:_distanceLab];
        _distanceLab.textAlignment = NSTextAlignmentRight;
        _distanceLab.textColor = bgColor(173, 173, 173);
        _distanceLab.font = [UIFont systemFontOfSize:12];
        [_distanceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(0);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.05));
        }];
    }
    return _distanceLab;
}
- (UIButton *)phoneBtn {
    if( _phoneBtn == nil) {
        _phoneBtn = [[UIButton alloc] init];
        [self.contentView addSubview:_phoneBtn];
        [_phoneBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
        [_phoneBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(-10);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(SCREEN_HEIGHT*.03, SCREEN_HEIGHT*.03));
        }];
    }
    return _phoneBtn;
}

@end

/////////////////////=========== 商品详情
@implementation GoodsDetailsCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIButton *)goodsDetailBtn {
    if(_goodsDetailBtn == nil) {
        _goodsDetailBtn = [[UIButton alloc] init];
        [_goodsDetailBtn setTitle:@"[商品详情]" forState:UIControlStateNormal];
        [self.contentView addSubview:_goodsDetailBtn];
        [_goodsDetailBtn addTarget:self action:@selector(clickDetails) forControlEvents:UIControlEventTouchUpInside];
        
        [_goodsDetailBtn setTitleColor:bgColor(0, 168, 194) forState:UIControlStateNormal];
        [_goodsDetailBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.25, 25));
        }];
    }
    return _goodsDetailBtn;
}
-(void)clickDetails
{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"GOODSDETAILBTN" object:nil];
}

@end
/////////////////////=========== 评价
@implementation GoodsComentCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)userCommentLab {
    if( _userCommentLab == nil) {
        _userCommentLab = [[UILabel alloc] init];
        [self.contentView addSubview:_userCommentLab];
        _userCommentLab.textColor = bgColor(0, 168, 194);
        _userCommentLab.font = [UIFont systemFontOfSize:20];
        [_userCommentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, SCREEN_HEIGHT*0.07));
        }];
    }
    return _userCommentLab;
}
- (UILabel *)ratioLab {
    if(_ratioLab == nil) {
        _ratioLab = [[UILabel alloc] init];
        _ratioLab.textAlignment = NSTextAlignmentRight;
        _ratioLab.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_ratioLab];
        [_ratioLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.userCommentLab.mas_top).equalTo(0);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3, 20));
        }];
    }
    return _ratioLab;
}
- (UILabel *)priceLab {
    if( _priceLab == nil) {
        _priceLab = [[UILabel alloc] init];
        [self.contentView addSubview:_priceLab];
        //_priceLab.textColor = bgColor(83, 203, 217);
        _priceLab.textColor = [UIColor whiteColor];
        _priceLab.font = [UIFont systemFontOfSize:12];
        _priceLab.backgroundColor = bgColor(0, 175, 203);
        _priceLab.layer.borderColor = [bgColor(83, 203, 217)CGColor];
        
        _priceLab.layer.borderWidth = 0.5f;
        
        _priceLab.layer.masksToBounds = YES;
        _priceLab.textAlignment = NSTextAlignmentCenter;
        [_priceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(self.userCommentLab.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15, 20));
        }];
        _priceLab.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(allComment:)];
        tapGR.numberOfTapsRequired=1;
        [self.priceLab addGestureRecognizer:tapGR];
    }
    return _priceLab;
}
- (UILabel *)environmentLab {
    if( _environmentLab == nil) {
        _environmentLab = [[UILabel alloc] init];
        [self.contentView addSubview:_environmentLab];
        _environmentLab.textColor = bgColor(83, 203, 217);
        _environmentLab.font = [UIFont systemFontOfSize:12];
        _environmentLab.layer.borderColor = [bgColor(83, 203, 217)CGColor];
        
        _environmentLab.layer.borderWidth = 0.5f;
        
        _environmentLab.layer.masksToBounds = YES;
         _environmentLab.textAlignment = NSTextAlignmentCenter;
        [_environmentLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.priceLab.mas_right).equalTo(10);
            make.top.equalTo(self.userCommentLab.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.20, 20));
        }];
        _environmentLab.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(goodComment:)];
        tapGR.numberOfTapsRequired=1;
        [self.environmentLab addGestureRecognizer:tapGR];
    }
    return _environmentLab;
}
- (UILabel *)serviceLab {
    if( _serviceLab == nil) {
        _serviceLab = [[UILabel alloc] init];
        [self.contentView addSubview:_serviceLab];
        _serviceLab.textColor = bgColor(83, 203, 217);
        _serviceLab.font = [UIFont systemFontOfSize:12];
        _serviceLab.layer.borderColor = [bgColor(83, 203, 217)CGColor];
        
        _serviceLab.layer.borderWidth = 0.5f;
        
        _serviceLab.layer.masksToBounds = YES;
        _serviceLab.textAlignment = NSTextAlignmentCenter;
        [_serviceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.environmentLab.mas_right).equalTo(10);
            make.top.equalTo(self.userCommentLab.mas_bottom).equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.20, 20));
        }];
        _serviceLab.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(bedComment:)];
        tapGR.numberOfTapsRequired=1;
        [self.serviceLab addGestureRecognizer:tapGR];
    }
    return _serviceLab;
}
//- (UIImageView *)commentImg {
//    if( _commentImg == nil) {
//        _commentImg = [[UIImageView alloc] init];
//        _commentImg.userInteractionEnabled = YES;
//        [self.contentView addSubview:_commentImg];
//        _commentImg.image = [UIImage imageNamed: @"store_comments"];
//        [_commentImg mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(-SCREEN_WIDTH*.05);
//            make.bottom.equalTo(-5);
//            make.size.equalTo(CGSizeMake(60, 20));
//        }];
//        _commentImg.userInteractionEnabled = YES;
//    }
//    return _commentImg;
//}
//- (UILabel *)commentCount {
//    if( _commentCount == nil) {
//        _commentCount = [[UILabel alloc] init];
//        [self.commentImg addSubview:_commentCount];
//        _commentCount.text = @"评论";
//        _commentCount.textColor = bgColor(173, 173, 173);
//        _commentCount.textAlignment = NSTextAlignmentCenter;
//        _commentCount.font = [UIFont systemFontOfSize:12];
//        [_commentCount mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.right.equalTo(self.commentImg.mas_right).equalTo(2);
//            make.centerY.equalTo(0);
//            make.size.equalTo(CGSizeMake(40, 20));
//        }];
//    }
//    return _commentCount;
//}
-(void)allComment:(UIPanGestureRecognizer*)gr
{
    //发送通知，用户评论
    NSLog(@"----");
    //发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ALLCOMMENT" object:nil];
}
-(void)goodComment:(UIPanGestureRecognizer*)gr
{
    //发送通知，用户评论
    NSLog(@"----");
    //发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"GOODCOMMENT" object:nil];
}
-(void)bedComment:(UIPanGestureRecognizer*)gr
{
    //发送通知，用户评论
    NSLog(@"----");
    //发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BEDCOMMENT" object:nil];
}
@end
/////////////////////=========== 评价cell
@implementation GoodsCommentDetailCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)userImg {
    if( _userImg == nil) {
        _userImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_userImg];
        _userImg.layer.masksToBounds = YES;
        _userImg.layer.cornerRadius = 30 ;
        _userImg.image = [UIImage imageNamed:@"header1"];
        [_userImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.equalTo(20);
            make.size.equalTo(CGSizeMake(60, 60));
        }];
    }
    return _userImg;
}
- (UILabel *)userPhoneLab {
    if( _userPhoneLab == nil) {
        _userPhoneLab = [[UILabel alloc] init];
        [self.contentView addSubview:_userPhoneLab];
        _userPhoneLab.font = [UIFont systemFontOfSize:12];
        [_userPhoneLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(20);
            make.left.equalTo(self.userImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _userPhoneLab;
}
- (UILabel *)userCommentTimeLab {
    if( _userCommentTimeLab == nil) {
        _userCommentTimeLab = [[UILabel alloc] init];
        [self.contentView addSubview:_userCommentTimeLab];
        _userCommentTimeLab.textColor = bgColor(173, 173, 173);
        _userCommentTimeLab.font = [UIFont systemFontOfSize:12];
        [_userCommentTimeLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.userPhoneLab.mas_bottom).equalTo(0);
            make.left.equalTo(self.userImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
    }
    return _userCommentTimeLab;
}
- (UILabel *)userdetailLab {
    if( _userdetailLab == nil) {
        _userdetailLab = [[UILabel alloc] init];
        [self.contentView addSubview:_userdetailLab];
        _userdetailLab.textColor = bgColor(173, 173, 173);
        _userdetailLab.font = [UIFont systemFontOfSize:12];
        [_userdetailLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(self.userImg.mas_bottom).equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 30));
        }];
    }
    return _userdetailLab;
}

- (UIImageView *)commentImg {
    if( _commentImg == nil) {
        _commentImg = [[UIImageView alloc] init];
        _commentImg.userInteractionEnabled = YES;
        [self.contentView addSubview:_commentImg];
        _commentImg.image = [UIImage imageNamed: @"header1"];
        _commentImg.userInteractionEnabled = YES;
        
        [_commentImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-SCREEN_WIDTH*.05);
            make.bottom.equalTo(-5);
            make.size.equalTo(CGSizeMake(60, 20));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(comment:)];
        tapGR.numberOfTapsRequired=1;
        [self.commentImg addGestureRecognizer:tapGR];
    }
    return _commentImg;
}
- (UILabel *)commentCount {
    if( _commentCount == nil) {
        _commentCount = [[UILabel alloc] init];
        [self.commentImg addSubview:_commentCount];
        _commentCount.textAlignment = NSTextAlignmentCenter;
        _commentCount.textColor = bgColor(173, 173, 173);
        _commentCount.font = [UIFont systemFontOfSize:12];
        [_commentCount mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.commentImg.mas_right).equalTo(2);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(40, 20));
        }];
    }
    return _commentCount;
}
- (UILabel *)ratioLab {
    if(_ratioLab == nil) {
        _ratioLab = [[UILabel alloc] init];
        _ratioLab.textAlignment = NSTextAlignmentCenter;
        _ratioLab.layer.borderColor = [[UIColor grayColor]CGColor];
        
        _ratioLab.layer.borderWidth = 0.5f;
        
        _ratioLab.layer.masksToBounds = YES;
        _ratioLab.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_ratioLab];
        [_ratioLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.userPhoneLab.mas_top).equalTo(0);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(40, 20));
        }];
        
    }
    return _ratioLab;
}

//点击事件
-(void)comment:(UIPanGestureRecognizer*)gr
{
   //跳转到评论页，，，显示所有评论数据，并且可回复当前用户评论的内容
    NSLog(@"----");
    !_commentBtnClicked ?: _commentBtnClicked(self);
}
@end
