//
//  HeaderMaskView.m
//  TRProject
//
//  Created by liweidong on 16/12/26.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HeaderMaskView.h"

@implementation HeaderMaskView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //
    }
    return self;
}

@end
