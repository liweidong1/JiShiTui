//
//  SectionHeaderView.h
//  TRProject
//
//  Created by liweidong on 17/1/9.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SectionHeaderView : UIView
@property(nonatomic,strong)UIButton * chooseBtn;//选择按钮
@property (nonatomic) UILabel *titleLab;//标题
@property (nonatomic) UIImageView *rightIV;

@property (nonatomic, strong) void(^sectionHeaderHandler)();

@end
