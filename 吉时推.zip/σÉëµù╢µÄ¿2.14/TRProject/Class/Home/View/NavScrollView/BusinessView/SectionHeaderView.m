//
//  SectionHeaderView.m
//  TRProject
//
//  Created by liweidong on 17/1/9.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "SectionHeaderView.h"

@implementation SectionHeaderView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //
        [self chooseBtn];
        [self titleLab];
        [self rightIV];
    }
    return self;
}
- (UIButton *) chooseBtn {
    if(_chooseBtn == nil) {
        _chooseBtn = [[UIButton alloc] init];
        [self addSubview:_chooseBtn];
        [_chooseBtn bk_addEventHandler:^(id sender) {
            !self.sectionHeaderHandler ?: self.sectionHeaderHandler();
        } forControlEvents:UIControlEventTouchUpInside];

        [_chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(5);
            make.size.equalTo(CGSizeMake(15, 15));
        }];
    }
    return _chooseBtn;
}

- (UILabel *)titleLab {
    if(_titleLab == nil) {
        _titleLab = [[UILabel alloc] init];
        _titleLab.font = [UIFont systemFontOfSize:15];
        [self addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.chooseBtn.mas_right).equalTo(SCREEN_WIDTH*.06);
            make.size.equalTo(CGSizeMake(60, 20));
        }];
    }
    return _titleLab;
}


- (UIImageView *)rightIV {
    if(_rightIV == nil) {
        _rightIV = [[UIImageView alloc] init];
        [self addSubview:_rightIV];
        _rightIV.image = [UIImage imageNamed:@"odetials_xrig"];
        _rightIV.contentMode = UIViewContentModeScaleAspectFill;
        [_rightIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.titleLab.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(8, 17));
        }];

    }
    return _rightIV;
}
@end
