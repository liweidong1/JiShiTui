//
//  ShopBottomView.h
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopBottomView : UIView
/* 全选 */
@property(nonatomic,strong)UIView * lineTopView;
@property(nonatomic,strong)UIButton * chooseBtn;//选择按钮
@property(nonatomic,strong)UILabel * allChoose;//全选
@property(nonatomic,strong)UILabel * totalPrice;//合计价格
@property(nonatomic,strong)UIButton * payBtn;//结算



@end
