//
//  ShopBottomView.m
//  TRProject
//
//  Created by liweidong on 17/1/4.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ShopBottomView.h"

@implementation ShopBottomView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self lineTopView];
        [self chooseBtn];
        [self allChoose];
        [self totalPrice];
        [self payBtn];
    }
    return self;
}
- (UIView *) lineTopView {
    if(_lineTopView == nil) {
        _lineTopView = [[UIView alloc] init];
        [self addSubview:_lineTopView];
        _lineTopView.backgroundColor = [UIColor grayColor];
        [_lineTopView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.height.equalTo(1);
        }];
    }
    return _lineTopView;
}

- (UIButton *) chooseBtn {
    if(_chooseBtn == nil) {
        _chooseBtn = [[UIButton alloc] init];
        [self addSubview:_chooseBtn];
        [_chooseBtn setImage:[UIImage imageNamed:@"odetials_checked"] forState:UIControlStateNormal];
        [_chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(5);
            make.size.equalTo(CGSizeMake(15, 15));
        }];
    }
    return _chooseBtn;
}
- (UILabel *) allChoose {
    if(_allChoose == nil) {
        _allChoose = [[UILabel alloc] init];
        _allChoose.font = [UIFont systemFontOfSize:15];
        _allChoose.text = @"全选";
        [self addSubview:_allChoose];
        [_allChoose mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.chooseBtn.mas_right).equalTo(SCREEN_WIDTH*.05);
            make.size.equalTo(CGSizeMake(60, 20));
        }];

    }
    return _allChoose;
}

- (UILabel *) totalPrice {
    if(_totalPrice == nil) {
        _totalPrice = [[UILabel alloc] init];
        _totalPrice.textColor = bgColor(0, 169, 196);
        _totalPrice.hidden = YES;
        _totalPrice.font = [UIFont systemFontOfSize:11];
        [self addSubview:_totalPrice];
        [_totalPrice mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(SCREEN_WIDTH*.25);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, 20));
        }];
    }
    return _totalPrice;
}

- (UIButton *) payBtn {
    if(_payBtn == nil) {
        _payBtn = [[UIButton alloc] init];
        _payBtn.backgroundColor = bgColor(0, 177, 200);
        [_payBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self addSubview:_payBtn];
        [_payBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.top.bottom.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.25);
        }];
    }
    return _payBtn;
}
@end
