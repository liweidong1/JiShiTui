//
//  CarNormalCell.h
//  TRProject
//
//  Created by liweidong on 17/1/15.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarNormalCell : UITableViewCell
/**李伟东 */
@property (nonatomic, strong) UIImageView *iv;
@property (nonatomic, strong) UILabel *titleLb;
@property (nonatomic, strong) UILabel *descLb;
@property (nonatomic, strong) UILabel *priceLb;
@property (nonatomic, strong) UILabel *adressLb;
@property (nonatomic, strong) UIView *line;


@end
