//
//  CarNormalCell.m
//  TRProject
//
//  Created by liweidong on 17/1/15.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "CarNormalCell.h"

@implementation CarNormalCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}


- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(10);
            make.left.equalTo(8);
            make.size.equalTo(CGSizeMake(90, 60));
        }];
    }
    return _iv;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iv.mas_top).equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 18));
        }];
    }
    return _titleLb;
}

- (UILabel *)descLb {
    if(_descLb == nil) {
        _descLb = [[UILabel alloc] init];
        _descLb.font = [UIFont systemFontOfSize:11];
        _descLb.textColor = [UIColor grayColor];
        [self.contentView addSubview:_descLb];
        [_descLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLb.mas_bottom).equalTo(5);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 18));
        }];
    }
    return _descLb;
}

- (UILabel *)priceLb {
    if(_priceLb == nil) {
        _priceLb = [[UILabel alloc] init];
        _priceLb.font = [UIFont systemFontOfSize:14];
        _priceLb.textColor = bgColor(0, 174, 199);
        [self.contentView addSubview:_priceLb];
        [_priceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.descLb.mas_bottom).equalTo(5);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 18));
        }];
    }
    return _priceLb;
}

- (UILabel *)adressLb {
    if(_adressLb == nil) {
        _adressLb = [[UILabel alloc] init];
        _adressLb.font = [UIFont systemFontOfSize:11];
        [self.contentView addSubview:_adressLb];
        [_adressLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.priceLb.mas_bottom).equalTo(5);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 18));
        }];
    }
    return _adressLb;
}

- (UIView *)line {
    if(_line == nil) {
        _line = [[UIView alloc] init];
        _line.alpha = .5;
        [self.contentView addSubview:_line];
        [_line mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.left.right.equalTo(0);
            make.height.equalTo(1);
        }];
        
    }
    return _line;
}


@end
