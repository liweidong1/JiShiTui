//
//  NavScrollView.h
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CarScrollView : UIView
@property(nonatomic,strong)UIPageControl * pc;
@property(nonatomic,assign)NSInteger page;

@property(nonatomic,assign)UIButton *navBtn;


@property(nonatomic,strong)UIButton *bt1;
@property(nonatomic,strong)UILabel *lab1;

@property(nonatomic,strong)UIButton *bt2;
@property(nonatomic,strong)UILabel *lab2;

@property(nonatomic,strong)UIButton *bt3;
@property(nonatomic,strong)UILabel *lab3;

@property(nonatomic,strong)UIButton *bt4;
@property(nonatomic,strong)UILabel *lab4;

@property(nonatomic,strong)UIButton *bt5;
@property(nonatomic,strong)UILabel *lab5;

@property(nonatomic,strong)UIButton *bt6;
@property(nonatomic,strong)UILabel *lab6;

@end
