//
//  BannerViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BannerViewController : UIViewController
-(instancetype)initWithURL:(NSURL *)url;
@property(nonatomic,readonly) NSURL *url;
@end
