//
//  HomeViewController.h
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface HomeViewController : UITableViewController

@property(nonatomic,strong)NSString *info;

//为了接收city，就公开一个属性
@property (nonatomic,strong)NSString* backValue;
@property(nonatomic,strong)UILabel *adressLable;

@end
