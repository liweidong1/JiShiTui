//
//  HomeViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "HomeViewController.h"

#import "BaseMaskView.h"

#import "HomeViewModel.h"
#import "HomeNetworking.h"
/*导航栏头文件*/
#import "PageViewController.h"
#import "jstInfoViewController.h"
#import "jstAddressViewController.h"
#import "jstErweimaViewController.h"

/*分区1头文件*/
#import "HomeHeaderCell.h"
#import "BannerViewController.h"
/*分区2头文件*/
#import "NavCell.h"
#import "NavScrollView.h"
#import "jstBusinessViewController.h"
#import "jstCircleViewController.h"
#import "jstConvenientController.h"
#import "jstEducationViewController.h"
#import "jstTourViewController.h"
#import "jstHonestViewController.h"
#import "jstPaymentViewController.h"
#import "jstGarageViewController.h"
#import "jstGameViewController.h"
/*分区3头文件*/
#import "WeatherAndBusCell.h"
/*分区4头文件*/
#import"ChooseFirstCell.h"
/*分区5头文件*/
#import"OtherCell.h"

/*定位*/
#import <CoreLocation/CoreLocation.h>

@interface HomeViewController ()<HomeHeaderCellDelegate, HomeHeaderCellDataSource,UISearchBarDelegate,UISearchBarDelegate,CLLocationManagerDelegate>
@property (nonatomic) BaseMaskView *maskView;
@property (nonatomic,strong)UISearchController *searchController;
@property (nonatomic) HomeViewModel *homeVM;
@property(nonatomic,strong)NavScrollView * scrollView;
@property(nonatomic,strong)UISearchBar * searchBar;
/** 回到顶部 */
@property (nonatomic, strong) UIControl *upToTop;
//定位
@property(nonatomic,strong)CLLocationManager *manager;
@property(nonatomic,strong)CLLocation * userLocation;
//反地理编码
@property(nonatomic,strong)CLGeocoder * geocoder;
@property(nonatomic,strong)WeatherAndBusCell * cell;
@property(nonatomic,strong)NavCell * scrollCell;


@property(nonatomic,strong)NSString *cityID;
//公开经纬度属性，切换城市所在商圈，改变了经纬度，刷新home的数据
@property(nonatomic,strong)NSString *lat;
@property(nonatomic,strong)NSString *lng;

@end

@implementation HomeViewController
#pragma - 定位
- (CLLocationManager *)manager
{
    if (!_manager) {
        _manager = [[CLLocationManager alloc]init];
    }
    return _manager;
}


#pragma mark - HomeHeaderCellDelegate
- (NSInteger)numberOfItemInCell:(HomeHeaderCell *)cell {
    return self.homeVM.indexNum;
}

- (NSURL *)iconURLForItemInCell:(HomeHeaderCell *)cell atIndex:(NSInteger)index {
    return [self.homeVM indexIconURLForRow:index];
}

- (void)homeHeaderCell:(HomeHeaderCell *)cell didSelectedIconAtIndex:(NSInteger)index {
    //跳转到对应的界面
    NSLog(@"%@",[self.homeVM uidInAdForRow:index]);
    BannerViewController * bannerVC = [[BannerViewController alloc]initWithURL:[NSURL URLWithString:[self.homeVM uidInAdForRow:index]]];
    [self.navigationController pushViewController:bannerVC animated:YES];
}



#pragma mark - LifeCycle 生命周期
- (void)viewDidLoad{
    [super viewDidLoad];
    
    [self setTableView];
    
       //开始定位
    [self startUpdatingLocation];
    //创建左边的item
    [self setupLeftItems];
    [self setNavBar];
    //创建右边两个item
    [self setupRightItems];
    //通知类
    [self setNotifacations];
}
-(void)setTableView
{
    self.tableView.tableFooterView = [UIView new];
    //去掉cell之间的分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    [self.tableView registerClass:[HomeHeaderCell class] forCellReuseIdentifier:@"jstHomeHeaderCell"];
    [self.tableView registerClass:[NavCell class] forCellReuseIdentifier:@"jstNavCell"];
    [self.tableView registerClass:[WeatherAndBusCell class] forCellReuseIdentifier:@"jstWeatherAndBusCell"];
    [self.tableView registerClass:[ChooseFirstCell class] forCellReuseIdentifier:@"jstChooseCell"];
    [self.tableView registerClass:[OtherCell class] forCellReuseIdentifier:@"jstOtherCell"];
    //定位成功后在加载数据
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
    self.navigationController.navigationBar.barTintColor = jRGBA(0, 177, 200, 1);
//        [BaseNetworking GET:@"http://www.zhdp.com/Shop?id=1&page=1" parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
//    
//        }];
//        //先判断是否有网络，接收网络请求的通知
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(noNetWorkView:) name:@"NONETWORK" object:nil];
//        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(NetWorkView:) name:@"NETWORKING" object:nil];
}
//-(void)NetWorkView:(NSNotification *)notification
//{
//    NSString * orNet = notification.userInfo[@"SelectedView"];
//    if ([orNet isEqualToString:@"2"]) {
//         [_maskView removeFromSuperview];
//    }
//}
//-(void)noNetWorkView:(NSNotification *)notification
//{
//    //获取通知的参数
//    NSString * orNet = notification.userInfo[@"SelectedView"];
//    if ([orNet isEqualToString:@"1"]) {
//        BaseMaskView *maskView = [[BaseMaskView alloc]initWithFrame:self.view.frame];
//        _maskView = maskView;
//        maskView.backgroundColor = [UIColor whiteColor];
//        maskView.wifiImg.image = [UIImage imageNamed:@"baseNetwork"];
//        maskView.networkLab.text = @"网络请求失败";
//        maskView.infoLab.text = @"请检查您的网络";
//        [maskView.bufferBtn setTitle:@"重新加载" forState:UIControlStateNormal];
//        JSTWeakSelf
//        maskView.bufferHandler = ^(){
//            [weakSelf clickBufferBtn];
//        };
//        [self.tableView addSubview:maskView];
//    }
//}
//-(void)clickBufferBtn
//{
//    [BaseNetworking GET:@"http://www.zhdp.com/Shop?id=1&page=1" parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
//    }];
//
//    [self.tableView reloadData];
//
//    [self loadDatas];
//}
-(void)setNotifacations
{
    /*NavScrollView第一个界面通知*/
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickBusiness:) name:@"JSTBUSUNESS" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickCirlle:) name:@"JSTCRICLE" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickConvient:) name:@"JSTCONVENIENT" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickDducation:) name:@"JSTEDUCATION" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickTour:) name:@"JSTTOUR" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickHonest:) name:@"JSTHONEST" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickPayment:) name:@"JSTPAYMENT" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickGarage:) name:@"JSTGARAGE" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickGame:) name:@"JSTGAME" object:nil];
    //城市
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cityDidChange:) name:@"CityChange" object:nil];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.homeVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];
    [self.tableView addFooterRefresh:^{
        //获取VM数据
        [weakSelf.homeVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];

}
-(void)cityDidChange:(NSNotification *)notification
{
    //获取通知的参数
    NSString * cityName = notification.userInfo[@"SelectedCityName"];
    NSString * latName = notification.userInfo[@"SelectedLatName"];
    NSString * lngName = notification.userInfo[@"SelectedLngName"];
    self.adressLable.text = cityName;
    if (self.adressLable.text.length>3) {
         self.adressLable.font = [UIFont systemFontOfSize:13];
        NSString *cityStr = cityName;
        NSString *str= [cityStr substringWithRange:NSMakeRange(0,3)];
        NSLog(@"a:%@  \n",str);
    self.adressLable.text = [NSString stringWithFormat:@"%@..",str];
    }
    //发送请求    Banner     为您优选   天气
    _lat = latName;
    _lng = lngName;
    //113.30529   23.102763
     NSLog(@"经度和纬度:%@ %@",latName,lngName);
    if (_homeVM) {
        _homeVM = [[HomeViewModel alloc]initWithlngLat:_lat AndLng:_lng];
        NSLog(@"经度和纬度:%@ %@",_lat,_lng);
    }
    [self loadDatas];
    //发送请求*天气 
    //[self getJSONFromServer];
}
-(void)clickBusiness:(NSNotification *)notification
{
    NSLog(@"跳转商家");
    /*-------------------------
     此处需要传入商家登录时的userID
      -------------------------
     -------------------------
     -------------------------
     -------------------------
     -------------------------
     */
    [self.navigationController pushViewController:[jstBusinessViewController new] animated:YES];
    //此处需要传值

}
-(void)clickCirlle:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstCircleViewController new] animated:YES];
    
}
-(void)clickConvient:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstConvenientController new] animated:YES];
    
}
-(void)clickDducation:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstEducationViewController new] animated:YES];
    
}
-(void)clickTour:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstTourViewController new] animated:YES];
    
}
-(void)clickHonest:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstHonestViewController new] animated:YES];
    
}
-(void)clickPayment:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstPaymentViewController new] animated:YES];
    
}
-(void)clickGarage:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstGarageViewController new] animated:YES];
    
}
-(void)clickGame:(NSNotification *)notification
{
    [self.navigationController pushViewController:[jstGameViewController new] animated:YES];
    
}
-(void)startUpdatingLocation
{
    //设置代理
    self.manager.delegate=self;
    //征求用户同意
    [self.manager requestWhenInUseAuthorization];
}
#pragma  mark --CLLocationManager协议
-(void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    switch (status) {
            //用户允许在使用期间定位(前台)
        case kCLAuthorizationStatusAuthorizedWhenInUse:
            //设定定位精确度
            self.manager.desiredAccuracy = kCLLocationAccuracyBest;
            //开始定位操作
            [self.manager startUpdatingLocation];
            break;
            //用户不允许定位(第二种方案)
        case kCLAuthorizationStatusDenied:
            NSLog(@"用户不允许");
            //发送请求(简单的推送一个默认的城市)
            //[self getJSONFromServer];
            break;
        default:
            break;
    }
}
-(void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray<CLLocation *> *)locations
{
    self.userLocation = [locations lastObject];
    NSLog(@"latitude:%f; longitude:%f", _userLocation.coordinate.latitude, _userLocation.coordinate.longitude);
    //停止定位
    [self.manager stopUpdatingLocation];
    _lat = [NSString stringWithFormat:@"%f",_userLocation.coordinate.latitude];
    _lng = [NSString stringWithFormat:@"%f",_userLocation.coordinate.longitude];
    if (_homeVM) {
        _homeVM = [[HomeViewModel alloc]initWithlngLat:_lat AndLng:_lng];
        NSLog(@"经度和纬度:%@ %@",_lat,_lng);
    }

    /*定位完成，无需定位，结束*/
    
    NSString *lngs = [NSString stringWithFormat:@"lng=%f,%f",_userLocation.coordinate.latitude,_userLocation.coordinate.longitude];
    NSLog(@"%@",_lng);
    [HomeNetworking sendLngLat:lngs lanAndLatCompletionHandler:^(AddressModel *model, NSError *error) {
        NSLog(@"**");
        if (model.status == 1) {
            NSMutableString *str = (NSMutableString *)model.data[0];
            NSMutableString *str1 = (NSMutableString *)model.data[1];
            [WSProgressHUD showSuccessWithStatus:@"定位成功，您位于回龙观商圈"];
            _adressLable.text = [NSString stringWithFormat:@"%@市",str];
            if (self.adressLable.text.length>3) {
                NSString *cityStr = self.adressLable.text;
                self.adressLable.font = [UIFont systemFontOfSize:13];
                NSString *str= [cityStr substringWithRange:NSMakeRange(0,3)];
                NSLog(@"a:%@  \n",str);
                self.adressLable.text = [NSString stringWithFormat:@"%@..",str];
            }
            _cityID = str1;
            [self loadDatas];
            //获取scrollBanner数据
            [self getScrollBanner];
            //发送请求*天气
            [self getJSONFromServer];
            }else{
            [WSProgressHUD showErrorWithStatus:@"定位失败"];
        }
    }];
    
    
    //发送通知
    [[NSNotificationCenter defaultCenter] postNotificationName:@"EnterMeView" object:self userInfo:@{@"Latitude" : _lat,@"Lngutude" : _lng}];
}
-(void)getScrollBanner
{
    NavScrollView *scrollView = [[NavScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.25)];
    self.scrollView = scrollView;
    [HomeNetworking getNavScrollBannerCompletionHandler:^(NavScrollModel *model, NSError *error) {
        NSLog(@"%@",model);
        //获取网络数据
        NSURL *URL1 = [NSURL URLWithString:model.nav[0].blogo];
        NSURL *URL2 = [NSURL URLWithString:model.nav[1].blogo];
        NSURL *URL3 = [NSURL URLWithString:model.nav[2].blogo];
        NSURL *URL4 = [NSURL URLWithString:model.nav[3].blogo];
        NSURL *URL5 = [NSURL URLWithString:model.nav[4].blogo];
        NSURL *URL6 = [NSURL URLWithString:model.nav[5].blogo];
        NSURL *URL7 = [NSURL URLWithString:model.nav[6].blogo];
        NSURL *URL8 = [NSURL URLWithString:model.nav[7].blogo];
        NSURL *URL9 = [NSURL URLWithString:model.nav[8].blogo];
        UIImage *img1 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL1]];
        UIImage *img2 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL2]];
        UIImage *img3 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL3]];
        UIImage *img4 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL4]];
        UIImage *img5 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL5]];
        UIImage *img6 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL6]];
        UIImage *img7 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL7]];
        UIImage *img8 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL8]];
        UIImage *img9 = [UIImage imageWithData:[NSData dataWithContentsOfURL:URL9]];
        dispatch_async(dispatch_get_main_queue(), ^{
            scrollView.lab1.text = model.nav[0].bname;
            scrollView.lab2.text = model.nav[1].bname;
            scrollView.lab3.text = model.nav[2].bname;
            scrollView.lab4.text = model.nav[3].bname;
            scrollView.lab5.text = model.nav[4].bname;
            scrollView.lab6.text = model.nav[5].bname;
            scrollView.lab7.text = model.nav[6].bname;
            scrollView.lab8.text = model.nav[7].bname;
            scrollView.lab9.text = model.nav[8].bname;
            [scrollView.bt1 setImage:img1 forState:UIControlStateNormal];
            [scrollView.bt2 setImage:img2 forState:UIControlStateNormal];
            [scrollView.bt3 setImage:img3 forState:UIControlStateNormal];
            [scrollView.bt4 setImage:img4 forState:UIControlStateNormal];
            [scrollView.bt5 setImage:img5 forState:UIControlStateNormal];
            [scrollView.bt6 setImage:img6 forState:UIControlStateNormal];
            [scrollView.bt7 setImage:img7 forState:UIControlStateNormal];
            [scrollView.bt8 setImage:img8 forState:UIControlStateNormal];
            [scrollView.bt9 setImage:img9 forState:UIControlStateNormal];
        });
    }];
    [_scrollCell.contentView addSubview:self.scrollView];
    scrollView.navBtn.layer.masksToBounds = YES;
    scrollView.navBtn.layer.cornerRadius = 20;

}
#pragma mark --- 获取JSON数据
- (void)getJSONFromServer {
      if (self.userLocation) {
        NSString *urlStr = [NSString stringWithFormat:@"http://api.worldweatheronline.com/free/v2/weather.ashx?q=%f,%f&num_of_days=5&format=json&tp=6&key=24e50e714f4fccf1911a8b2d23637", self.userLocation.coordinate.latitude, self.userLocation.coordinate.longitude];
//          _lat = [NSString stringWithFormat:@"%f",self.userLocation.coordinate.latitude];
//          _lng = [NSString stringWithFormat:@"%f",self.userLocation.coordinate.longitude];
          NSLog(@"===%@===",urlStr);
          [HomeNetworking getLat:_lat Lng:_lng WeatherCompletionHandler:^(WeatherModel *model, NSError *error) {
              _cell.currentLable.text = [NSString stringWithFormat:@"%@℃",model.current_condition[0].temp_C];
              NSLog(@"%@",_cell.currentLable.text);
              [_cell.currentIcon setImageWithURL:[NSURL URLWithString:model.current_condition[0].weatherIconUrl[0].value] placeholder:[UIImage imageNamed:@""]];
              //            cell.descLable.text = model.current_condition[0].weatherDesc[0].value;
              //            cell.moistureLable.text = [NSString stringWithFormat:@"相对湿度:%@",model.current_condition[0].humidity];
              //            cell.windLable.text = model.current_condition[0].winddir16Point;
              NSLog(@"");
          }];
    } else {
        
           }
}

#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 4) {
        //return 4;
        return self.homeVM.rowNumber;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        HomeHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstHomeHeaderCell" forIndexPath:indexPath];
        //一个section刷新
        cell.dataSource = self;
        cell.delegate = self;
        [cell reloaedData];
        return cell;
    }
    if (indexPath.section == 1) {
        NavCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstNavCell"];
        _scrollCell = cell;
        return cell;
    }
    if (indexPath.section == 2) {
        WeatherAndBusCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstWeatherAndBusCell"];
        _cell = cell;
        return cell;
    }
    if (indexPath.section == 3) {
        ChooseFirstCell * cell = [tableView dequeueReusableCellWithIdentifier:@"jstChooseCell" forIndexPath:indexPath];
        
        return cell;
    }
    if (indexPath.section == 4) {
         OtherCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstOtherCell"];
        [cell.iconIV setImageWithURL:[self.homeVM iconURL:indexPath.row] placeholder:[UIImage imageNamed:@"home_temter"]];
        cell.titleLb.text = [self.homeVM title:indexPath.row];
        cell.subtitleLb.text = [NSString stringWithFormat:@"(%@)",[self.homeVM subtitle:indexPath.row]];
        cell.addrLb.text = [self.homeVM addr:indexPath.row];
        cell.distanceLb.text = [self.homeVM distance:indexPath.row];
        return cell;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    //参数id
    if (indexPath.section == 4) {
        jstBusinessViewController * jstBVC = [[jstBusinessViewController alloc]init];
        [self.navigationController pushViewController:jstBVC animated:YES];
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return SCREEN_WIDTH * 615 / 1125;
    }if (indexPath.section == 1) {
        return SCREEN_HEIGHT*.25;
    }else if(indexPath.section == 2) {
        return SCREEN_HEIGHT*.12;
    }else if(indexPath.section == 3) {
        return 30;
    }
    return 100;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0;
    }else if(section == 1 ){
        return 0;
    }else if(section == 2 ){
        return 3;
    }else {
            return 3;
    }
}

- (HomeViewModel *)homeVM {
	if(_homeVM == nil) {
		_homeVM = [[HomeViewModel alloc] init];
	}
	return _homeVM;
}


#pragma mark- navBar
- (void)setupLeftItems {
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.2, 35)];
    UILabel *adressLable = [[UILabel alloc]init];
    self.adressLable = adressLable;
    self.adressLable.font = [UIFont systemFontOfSize:16];
    [leftView addSubview:adressLable];
    NSString * strs = self.backValue;
    adressLable.text = strs;
    adressLable.textColor = [UIColor whiteColor];
    [adressLable mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.left.bottom.equalTo(0);
    }];
    UIImageView *iv = [[UIImageView alloc]init];
    [leftView addSubview:iv];
    iv.image = [UIImage imageNamed:@"home_horn"];
    [iv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(0);
        make.left.equalTo(adressLable.mas_right).equalTo(5);
        make.size.equalTo(CGSizeMake(20, 10));
    }];
    UIButton *navLeftBtn = [[UIButton alloc]initWithFrame:leftView.frame];
    [leftView addSubview: navLeftBtn];
    [navLeftBtn bk_addEventHandler:^(id sender) {
        
        //传入参数值
        jstAddressViewController * jstVC = [[jstAddressViewController alloc]initWithCityID:_cityID];
        NSLog(@"%@",_cityID);
        UINavigationController *navi = [[UINavigationController alloc]initWithRootViewController:jstVC];
        [self.navigationController presentViewController:navi animated:YES completion:nil];
    } forControlEvents:UIControlEventTouchUpInside];
 
    
    
    UIBarButtonItem *leftBarButtomItem = [[UIBarButtonItem alloc]initWithCustomView:leftView];
    self.navigationItem.leftBarButtonItem = leftBarButtomItem;
}

-(void)setNavBar
{
    UIView *titleView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH*.55, 35)];
    //添加searchBar
    UISearchBar * searchBar = [UISearchBar new];
    _searchBar = searchBar;
    searchBar.placeholder = @"搜索商家，品类，商圈";
    searchBar.delegate = self;
    searchBar.frame = titleView.frame;
    searchBar.layer.cornerRadius = 17.5;
    searchBar.layer.masksToBounds = YES;
    [titleView addSubview:searchBar];
    self.navigationItem.titleView = searchBar;
}
#pragma  mark ---SearchBarDelegate
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    //发送请求
    //键盘收回去
    [searchBar resignFirstResponder];
    NSLog(@"%@",searchBar.text);
    PageViewController * searchVC = [[PageViewController alloc]initWithStr:searchBar.text];
    [self.navigationController pushViewController:searchVC animated:YES];
}
- (void)setupRightItems {
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.2, 35)];
    UIImageView *iv = [[UIImageView alloc]init];
    [rightView addSubview:iv];
    iv.image = [UIImage imageNamed:@"home_warn"];
    iv.userInteractionEnabled = YES;
    [iv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(0);
        make.top.equalTo(5);
        make.bottom.equalTo(-5);
        make.width.equalTo(SCREEN_WIDTH*.07);
    }];
    UIImageView *iv0 = [[UIImageView alloc]init];
    [rightView addSubview:iv0];
    iv0.image = [UIImage imageNamed:@"home_erwei"];
    iv0.userInteractionEnabled = YES;
    UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
    tapGR.numberOfTapsRequired=1;
    [iv0 addGestureRecognizer:tapGR];
    [iv0 mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(10);
        make.top.equalTo(7);
        make.bottom.equalTo(-7);
        make.width.equalTo(SCREEN_WIDTH*.07);
    }];
    UIButton * btn = [[UIButton alloc]init];
    [rightView addSubview:btn];
    //默认消息数为隐藏
    btn.hidden = YES;
    //消息值需改变   如果有消息推送，则显示，否则隐藏
    btn.layer.masksToBounds = YES;
    btn.layer.cornerRadius = 10;
    btn.backgroundColor = [UIColor redColor];
    [btn setTitle:@"1" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(-5);
        make.right.equalTo(10);
        make.size.equalTo(CGSizeMake(20, 20));
    }];
    UITapGestureRecognizer* rightTapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(enterInfo:)];
    rightTapGR.numberOfTapsRequired=1;
    [iv addGestureRecognizer:rightTapGR];
    //[btn addGestureRecognizer:rightTapGR];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}
-(void)enterInfo:(UIPanGestureRecognizer*)gr
{
    [self.navigationController pushViewController:[jstInfoViewController new] animated:YES];
    
}
-(void)start:(UIPanGestureRecognizer*)gr
{
    [self.navigationController pushViewController:[jstErweimaViewController new] animated:YES];

}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_searchBar resignFirstResponder];
}
@end
