//
//  PageViewController.h
//  TRProject
//
//  Created by tarena on 16/7/18.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <WMPageController/WMPageController.h>

@interface PageViewController : WMPageController
-(instancetype)initWithStr:(NSString *)searchStr;
@property(nonatomic,readonly) NSString *searchStr;
@end








