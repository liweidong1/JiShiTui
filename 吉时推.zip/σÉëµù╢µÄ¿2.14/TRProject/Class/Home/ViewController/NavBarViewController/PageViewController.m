//
//  PageViewController.m
//  TRProject
//
//  Created by tarena on 16/7/18.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "PageViewController.h"
#import "jstSearchViewController.h"

@interface PageViewController ()<UISearchBarDelegate>
@property(nonatomic,strong)UISearchBar * searchBar;
@end
@implementation PageViewController
- (instancetype)initWithStr:(NSString *)searchStr
{
    if (self = [super init]) {
        _searchStr = searchStr;
    }
    return self;
}
- (NSArray<NSString *> *)titles{
    return @[@"商品", @"商家", @"商圈"];
}
- (NSInteger)numbersOfChildControllersInPageController:(WMPageController *)pageController{
    return self.titles.count;
}
- (__kindof UIViewController *)pageController:(WMPageController *)pageController viewControllerAtIndex:(NSInteger)index{
    
    jstSearchViewController *vc = [[jstSearchViewController alloc] init];
    vc.childVC = index;
    vc.searchContent = _searchStr;
    NSLog(@"%@",vc.searchContent);
    return vc;
}






- (void)viewDidLoad {
    [super viewDidLoad];
    UISearchBar *bar = [[UISearchBar alloc] init];
    _searchBar = bar;
    bar.delegate = self;
    bar.placeholder = @"请输入搜索内容";
    self.navigationItem.titleView = bar;
    
    [self.navigationItem setHidesBackButton:YES];
    //创建右边item
    [self setupRightItems];
    
    self.navigationItem.leftBarButtonItem = nil;
    
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hiddenKeyBoard:) name:@"JJJJJJJJJ" object:nil];
}
-(void)hiddenKeyBoard:(UIPanGestureRecognizer*)gr
{
   [_searchBar resignFirstResponder];
    
}

- (void)setupRightItems {
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.2, 35)];
    UIButton * btn = [[UIButton alloc]init];
    [rightView addSubview:btn];
    //取消
    [btn setTitle:@"取 消" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(0);
        make.top.equalTo(5);
        make.bottom.equalTo(-5);
        make.width.equalTo(60);
    }];
    [btn bk_addEventHandler:^(id sender) {
        [self.navigationController popViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    
    //[btn addGestureRecognizer:rightTapGR];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
}
- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar{
    [searchBar endEditing:YES];
    if (searchBar.text.length > 0) {
       //发送搜索请求   此处需传值
        [[NSNotificationCenter defaultCenter] postNotificationName:@"SEARCHCONTENT" object:nil];
        //发送通知
        [[NSNotificationCenter defaultCenter] postNotificationName:@"SEARCHCONTENT" object:self userInfo:@{@"SearchContent" : searchBar.text}];
    }else{
        [WSProgressHUD showErrorWithStatus:@"请输入搜索内容"];
    }
}


@end
