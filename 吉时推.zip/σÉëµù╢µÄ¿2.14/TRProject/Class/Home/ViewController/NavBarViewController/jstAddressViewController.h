//
//  jstAddressViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CityModel.h"
#import "HomeViewController.h"

@interface jstAddressViewController : UIViewController

-(instancetype)initWithCityID:(NSString *)cityId;
@property(nonatomic,readonly) NSString *cityId;

-(instancetype)initWithAllCityID:(NSString *)subId;
@property(nonatomic,readonly) NSString *subId;

@property (weak, nonatomic) IBOutlet UITableView *mainTableView;
@property (weak, nonatomic) IBOutlet UITableView *subTableView;


@property (nonatomic) NSMutableArray<CityShopModel *> *subList;
@end
