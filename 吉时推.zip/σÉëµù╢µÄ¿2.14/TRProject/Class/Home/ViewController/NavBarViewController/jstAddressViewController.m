//
//  jstAddressViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstAddressViewController.h"
#import "HomeNetworking.h"
#import "CityViewModel.h"
#import "SubTableViewCityModel.h"
@interface jstAddressViewController ()<UITableViewDataSource, UITableViewDelegate>

@property(nonatomic,strong)CityViewModel *cityVM;
@property(nonatomic,strong)SubTableViewCityModel *subVM;
@property(nonatomic,assign)NSInteger count;
/**记录主视图的点击cell的下标*/
@property(nonatomic,assign)NSInteger mainCellSellectRow;
@property(nonatomic,strong)UITableViewCell *mainCell;
/** 是否选中 */
@property (nonatomic, assign)NSInteger selectedCount;
@end

@implementation jstAddressViewController
- (instancetype)initWithCityID:(NSString *)cityId
{
    if (self = [super init]) {
        _cityId = cityId;
    }
    return self;
}

- (instancetype)initWithAllCityID:(NSString *)subId
{
    if (self = [super init]) {
        _subId = subId;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",_cityId);
    self.view.backgroundColor = [UIColor redColor];
    self.navigationItem.title = @"切换城市商圈";
    [self customBackBtn];
    
    [self.cityVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
          //直接显示不刷新
        [self.mainTableView reloadData];
    }];
    [self.cityVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
         //直接显示不刷新
        [self.subTableView reloadData];
    }];
    self.mainTableView.delegate = self;
    self.mainTableView.dataSource = self;
    self.subTableView.delegate = self;
    self.subTableView.dataSource  = self;
    [self.mainTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"mainCELL"];
    [self.subTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"subCELL"];
    self.mainTableView.separatorStyle = NO;
    self.subTableView.separatorStyle = NO;
}
-(void)customBackBtn{
    UIButton *navLeftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 60, 40)];
    [navLeftBtn setTitle:@"取消" forState:UIControlStateNormal];
    [navLeftBtn bk_addEventHandler:^(id sender) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *leftBarButtomItem = [[UIBarButtonItem alloc]initWithCustomView:navLeftBtn];
    self.navigationItem.leftBarButtonItem = leftBarButtomItem;
}
#pragma  mark --<UITableViewDataSource, UITableViewDelegate>
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.mainTableView) {
        //左边
        NSLog(@"**%ld",[self.cityVM mainRowNumber]);
        NSLog(@"***%ld",[self.cityVM allCityRowNumber]);
        return [self.cityVM mainRowNumber] + [self.cityVM allCityRowNumber];
    }else {
        if (_selectedCount == 0) {
            return 0;
        }
        NSLog(@"%ld",_count);
        if (_count == 0) {
            NSLog(@"%ld",_count);
            return [self.cityVM subRowNumber];
        }else {
            NSLog(@"%ld",[self.subVM subRowNumber]);
            return [self.subVM subRowNumber];
        }
        
    }
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.mainTableView) {
        //类方法调用类
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"mainCELL"];
        _mainCell = cell;
        if (indexPath.row == 0) {
            cell.textLabel.text = [_cityVM maintableViewText:indexPath.row];
        }else {
            cell.textLabel.text = [_cityVM allCitytableViewText:indexPath.row-1];
        }

        return cell;
    }else {
        if (_selectedCount == 0) {
            return [UITableViewCell new];
        }else {
            NSLog(@"%ld",_selectedCount);
            //   判断cell以哪个模型层显示
            UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"subCELL"];
            cell.backgroundColor = [UIColor clearColor];
            self.subTableView.backgroundColor = bgColor(214, 214, 214);
            if (_count == 0) {
                cell.textLabel.text = [_cityVM subtableViewText:indexPath.row];
            }else {
                NSLog(@"%@",[_subVM subtableViewText:indexPath.row]);
                cell.textLabel.text = [_subVM subtableViewText:indexPath.row];
            }
            return cell;
        }
        
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _selectedCount++;//判断右侧的数据是否隐藏
    
    _count++;
    NSLog(@"%ld",_count);
    
    if (tableView == self.mainTableView) {
        _mainCellSellectRow = indexPath.row;
        NSLog(@"---%ld",_mainCellSellectRow);
        //   传ID 发送请求  刷新子视图数据
        if (indexPath.row == 0) {
            _subId = [self.cityVM maintableViewID:indexPath.row];
            NSLog(@"%@",_subId);
            _subVM = [[SubTableViewCityModel alloc] initWithCityID:_subId];
        }else {
                _subId = [self.cityVM allCitytableViewID:indexPath.row-1];
                NSLog(@"%@",_subId);
                _subVM = [[SubTableViewCityModel alloc] initWithCityID:_subId];
        }
        
        [self.subVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [self.subTableView reloadData];
        }];
    }else {
        //传入主视图的indexPath.row
        NSString *cityName = nil;
        //传入右侧视图的经纬度
        NSString *latName = nil;
        NSString *lngName = nil;
        if (_mainCellSellectRow == 0) {
            NSLog(@"%ld",(long)_mainCellSellectRow);
            cityName = [self.cityVM maintableViewText:_mainCellSellectRow];
            latName = [self.subVM subtableViewlat:indexPath.row];
            lngName = [self.subVM subtableViewlng:indexPath.row];
            NSLog(@"%@%@",latName,lngName);
        }else {
            NSLog(@"%ld",(long)_mainCellSellectRow);
            cityName = [self.cityVM allCitytableViewText:_mainCellSellectRow-1];
            latName = [self.subVM subtableViewlat:indexPath.row];
            lngName = [self.subVM subtableViewlng:indexPath.row];
            NSLog(@"%@%@",latName,lngName);
        }

        //发送通知
        [[NSNotificationCenter defaultCenter] postNotificationName:@"CityChange" object:self userInfo:@{@"SelectedCityName" : cityName,@"SelectedLatName" : latName,@"SelectedLngName" : lngName}];
        [self dismissViewControllerAnimated:YES completion:nil];
    }
    
}
//- (void)selectRowAtIndexPath:(nullable NSIndexPath *)indexPath animated:(BOOL)animated scrollPosition:(UITableViewScrollPosition)scrollPosition
//{
//    NSInteger selectedIndex = 0;
//    NSIndexPath *selectedIndexPath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
//    [self.mainTableView selectRowAtIndexPath:selectedIndexPath animated:NO scrollPosition:UITableViewScrollPositionNone];
//    UITableViewCell *cell = [self.mainTableView cellForRowAtIndexPath:indexPath];
//    [cell setSelected:YES animated:YES];  // 使cell 的 状态设置为选中状态
//}

- (CityViewModel *)cityVM {
	if(_cityVM == nil) {
		_cityVM = [[CityViewModel alloc] initWithCityID:_cityId];
        NSLog(@"%@",_cityId);
	}
	return _cityVM;
}
- (NSMutableArray<CityShopModel *> *)subList {
    if(_subList == nil) {
        _subList = [[NSMutableArray<CityShopModel *> alloc] init];
    }
    return _subList;
}

//- (SubTableViewCityModel *)subVM {
//	if(_subVM == nil) {
//		_subVM = [[SubTableViewCityModel alloc] initWithCityID:_subId];
//	}
//	return _subVM;
//}

@end
