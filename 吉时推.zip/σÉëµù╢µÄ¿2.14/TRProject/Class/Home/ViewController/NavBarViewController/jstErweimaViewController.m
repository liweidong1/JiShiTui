//
//  jstErweimaViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/16.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstErweimaViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
@interface jstErweimaViewController ()<AVCaptureMetadataOutputObjectsDelegate>
//扫描二维码
@property (strong,nonatomic)AVCaptureDevice * device;
@property (strong,nonatomic)AVCaptureDeviceInput * input;
@property (strong,nonatomic)AVCaptureMetadataOutput * output;
@property (strong,nonatomic)AVCaptureSession * session;
@property (strong,nonatomic)AVCaptureVideoPreviewLayer * preview;
@property (strong,nonatomic)UIImageView * scrollImgView;
@property (strong,nonatomic)NSTimer * timer;
@end

@implementation jstErweimaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tabBarController.tabBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"二维码/条形码";
    /**
     *  导航栏的透明与不透明
     */
    self.navigationController.navigationBar.translucent = YES;
//    [self setCustomBack];
    //二维码
    [self setErweima];
    
    [self scanView];
}
-(void)scanView
{
    //添加扫描框View
    UIImage *scanViewBgImg = [UIImage imageNamed:@"register_scanQRCodeBG"];
    UIEdgeInsets capInsets = UIEdgeInsetsMake(199, 199, 200, 200);
    [scanViewBgImg resizableImageWithCapInsets:capInsets resizingMode:UIImageResizingModeStretch];
    
    UIImageView *scanImgView = [[UIImageView alloc] initWithImage:scanViewBgImg];
    
    scanImgView.frame = CGRectMake(0, 0, 800, 800);
    scanImgView.center = self.view.center;
    
    [self.view addSubview:scanImgView];
    
    //滚动条
    _scrollImgView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"register_scanQRCodeScroll"]];
    _scrollImgView.frame = CGRectMake(SCREEN_WIDTH/2 - 100, SCREEN_HEIGHT/2 -1, 200, 4);
    [self.view addSubview:_scrollImgView];
    //定时器刷新UI
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.01 target:self selector:@selector(scrollTheSlip) userInfo:nil repeats:YES];
    //启动定时器
    _timer.fireDate = [NSDate distantPast];
}
- (void)scrollTheSlip{
    CGRect frame = _scrollImgView.frame;
    if (frame.origin.y < kScreenHeight/2 + 100) {
        frame.origin.y ++;
    }else{
        frame.origin.y = kScreenHeight/2 - 100;
    }
    
    _scrollImgView.frame = frame;
}
//销毁定时器
- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    //停止定时器
    _timer.fireDate = [NSDate distantFuture];
    //销毁
    if (_timer.isValid) {
        [_timer invalidate];
    }
    _timer = nil;
}
-(void)setCustomBack
{
    UIView *leftView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH*.4, 30)];
    UIImageView *iv = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH*.1, 30)];
    iv.image = [UIImage imageNamed:@"gg_back"];
    [leftView addSubview:iv];
    UILabel *ewmLable = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.07, 0, SCREEN_WIDTH*.3, 30)];
    ewmLable.textAlignment = NSTextAlignmentRight;
    ewmLable.text = @"二维码/条码";
    ewmLable.textColor = [UIColor whiteColor];
    [leftView addSubview:ewmLable];
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH*.4, 30)];
    btn.backgroundColor = [UIColor clearColor];
    [btn bk_addEventHandler:^(id sender) {
        [self.navigationController popViewControllerAnimated:YES];
    } forControlEvents:UIControlEventTouchUpInside];
    [leftView addSubview:btn];
    UIBarButtonItem *leftBarButtomItem = [[UIBarButtonItem alloc]initWithCustomView:leftView];
    self.navigationItem.leftBarButtonItem = leftBarButtomItem;
}
-(void)setErweima
{
    if (![self cameraPemission]){
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"没有摄像机权限" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *aciton = [UIAlertAction actionWithTitle:@"知道了" style:UIAlertActionStyleDefault handler:nil];
        [alertController addAction:aciton];
        [self.navigationController pushViewController:alertController animated:YES];
        return;
    }
    
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        NSLog(@"没有相机");
        return;
    }
    
    // 添加输入设备(数据从摄像头输入
    _device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    // 输入
    _input = [AVCaptureDeviceInput deviceInputWithDevice:self.device error:nil];
    
    // 输出
    _output = [[AVCaptureMetadataOutput alloc]init];
    [_output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    // Session
    _session = [[AVCaptureSession alloc]init];
    [_session setSessionPreset:AVCaptureSessionPresetHigh];
    
    // 条码类型 AVMetadataObjectTypeQRCode
    
    if ([_session canAddInput:self.input])
    {
        [_session addInput:self.input];
    }
    
    if ([_session canAddOutput:self.output])
    {
        [_session addOutput:self.output];
    }
    [_output setMetadataObjectTypes:@[AVMetadataObjectTypeQRCode]];
    
    [_output setRectOfInterest:CGRectMake(0.35,0.3, 0.65, 0.7)];
    
    // Preview
    _preview =[AVCaptureVideoPreviewLayer layerWithSession:_session];
    _preview.videoGravity =AVLayerVideoGravityResizeAspectFill;
    _preview.frame =self.view.layer.bounds;
    [self.view.layer insertSublayer:_preview atIndex:0];
    
    [_session startRunning];
}
- (BOOL)cameraPemission{
    
    BOOL isHavePemission = NO;
    if ([AVCaptureDevice respondsToSelector:@selector(authorizationStatusForMediaType:)])
    {
        AVAuthorizationStatus permission =
        [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
        
        switch (permission) {
            case AVAuthorizationStatusAuthorized:
                isHavePemission = YES;
                break;
            case AVAuthorizationStatusDenied:
            case AVAuthorizationStatusRestricted:
                break;
            case AVAuthorizationStatusNotDetermined:
                isHavePemission = YES;
                break;
        }
    }
    return isHavePemission;
}
#pragma mark AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    NSString *stringValue;
    if ([metadataObjects count] >0)
    {
        //停止扫描
        [_session stopRunning];
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex:0];
        stringValue = metadataObject.stringValue;
        //（此处可用block块回传扫描信息）
        //回传值
//        if (self.blockWithQRCode) {
//            self.blockWithQRCode(stringValue);
//        }
        //播放音效提醒扫描成功,也可自定义音效播放
        //播放声音记得导入#import <AudioToolbox/AudioToolbox.h>
        AudioServicesPlaySystemSound(1317);
        
        [WSProgressHUD showSuccessWithStatus:@"扫描成功，跳转到扫描URL界面，待完善"];
        [self.navigationController popViewControllerAnimated:NO];
    } 
}

@end
