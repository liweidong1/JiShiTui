//
//  jstInfoViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstInfoViewController.h"

@interface jstInfoViewController ()

@end

@implementation jstInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"消息";
}

@end
