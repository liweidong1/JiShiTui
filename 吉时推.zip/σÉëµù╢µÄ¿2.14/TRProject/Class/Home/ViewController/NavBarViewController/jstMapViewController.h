//
//  jstMapViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/22.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstMapViewController : UIViewController
//获取上一界面穿入的经纬度 和覆盖物半径
-(instancetype)initWithScope:(NSString *)scope With:(NSString *)lat And:(NSString *)lng;
@property(nonatomic,readonly) NSString *scope;
@property(nonatomic,readonly) NSString *lat;
@property(nonatomic,readonly) NSString *lng;
@end
