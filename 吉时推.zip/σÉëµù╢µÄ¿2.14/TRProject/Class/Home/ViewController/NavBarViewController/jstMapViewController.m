//
//  jstMapViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/22.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstMapViewController.h"

#import <BaiduMapAPI_Map/BMKMapView.h>
#import <BaiduMapAPI_Map/BMKAnnotationView.h>
#import <BaiduMapAPI_Location/BMKLocationService.h>
#import <BaiduMapAPI_Utils/BMKGeometry.h>
#import <BaiduMapAPI_Search/BMKGeocodeSearch.h>

#import "YMPoi.h"
#import "YMPointAnnotation.h"
#import "YMAnnotationView.h"
#import "YMPaopaoView.h"
#import "SVProgressHUD.h"

#import "jstShopViewController.h"
#import "jstRouteAnnotationViewController.h"



@interface jstMapViewController ()<BMKLocationServiceDelegate, BMKMapViewDelegate, BMKGeoCodeSearchDelegate, YMPaopaoViewDelagate>{
    BMKMapView *_mapView;
    BMKLocationService *_locService;
    BMKGeoCodeSearch *_geoSearch;
}
/** 用户当前位置*/
@property(nonatomic , strong) BMKUserLocation *userLocation;
/** 当前城市*/
@property (nonatomic, copy) NSString *city;
@end

@implementation jstMapViewController
- (instancetype)initWithScope:(NSString *)scope With:(NSString *)lat And:(NSString *)lng
{
    if (self = [super init]) {
        _scope = scope;
        _lat = lat;
        _lng = lng;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // 设置百度地图
    [self setupMapViewWithParam];
    // 加载美图数据，加载数据可以根据自己的需求
    [self loadMeituanData];
}
#pragma mark - 加载美图数据
-(void)loadMeituanData {
    NSString *urlString = jstCoordMapPath;
    AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc] initWithBaseURL:jstURL.yx_URL];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"text/html", @"application/json", @"text/json", @"text/javascript", @"text/plain", nil];
    // 加载进度
    [SVProgressHUD setDefaultStyle:SVProgressHUDStyleCustom];
    [SVProgressHUD setBackgroundColor:[UIColor colorWithRed:0 green:0 blue:0 alpha:0.5]];
    [SVProgressHUD setForegroundColor:[UIColor whiteColor]];
    [SVProgressHUD showWithStatus:@"正在加载..."];
    [manager GET:urlString parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        [SVProgressHUD dismiss];
        NSArray *data = responseObject[@"datas"];
        for (NSDictionary *dict in data) {
//            NSDictionary *poiDict = dict[@"poi"];
            YMPoi *poi = [YMPoi mj_objectWithKeyValues:dict];
            YMPointAnnotation *annotation = [[YMPointAnnotation alloc] init];
            CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake([poi.lat doubleValue], [poi.lng doubleValue]);
            annotation.coordinate = coordinate;
            annotation.poi = poi;
            [_mapView addAnnotation:annotation];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
        [SVProgressHUD showErrorWithStatus:@"加载失败"];
    }];
}

#pragma mark - 设置百度地图
-(void)setupMapViewWithParam {
    self.userLocation = [[BMKUserLocation alloc] init];
    _geoSearch = [[BMKGeoCodeSearch alloc] init];
    _locService = [[BMKLocationService alloc] init];
    _locService.distanceFilter = 200;//设定定位的最小更新距离，这里设置 200m 定位一次，频繁定位会增加耗电量
    _locService.desiredAccuracy = kCLLocationAccuracyHundredMeters;//设定定位精度
    //开启定位服务
    [_locService startUserLocationService];
    
    //初始化BMKMapView
    _mapView = [[BMKMapView alloc] initWithFrame:CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - 64)];
    _mapView.buildingsEnabled = YES;//设定地图是否现显示3D楼块效果
    _mapView.overlookEnabled = YES; //设定地图View能否支持俯仰角
    _mapView.showMapScaleBar = YES; // 设定是否显式比例尺
    //    _mapView.overlooking = -45;     // 地图俯视角度，在手机上当前可使用的范围为－45～0度
    
    _mapView.zoomLevel = 14;//设置放大级别
    [self.view addSubview:_mapView];
    _mapView.userTrackingMode = BMKUserTrackingModeNone;//设置定位的状态
    _mapView.showsUserLocation = YES;//显示定位图层
    BMKLocationViewDisplayParam *userlocationStyle = [[BMKLocationViewDisplayParam alloc] init];
    userlocationStyle.isRotateAngleValid = YES;
    userlocationStyle.isAccuracyCircleShow = NO;
    
    //设置地图的中心点位置
    _mapView.centerCoordinate =  CLLocationCoordinate2DMake([_lat doubleValue], [_lng doubleValue]);

    
    [self setCircle];
}
-(void)setCircle
{
    NSLog(@"%@%@%@",_scope,_lng,_lat);
    // 添加圆形覆盖物
    CLLocationCoordinate2D coor;
//    coor.latitude = 39.915;
//    coor.longitude = 116.404;
    coor.latitude = [_lat doubleValue];
    coor.longitude = [_lng doubleValue];
    BMKCircle* circle = [BMKCircle circleWithCenterCoordinate:coor radius:[_scope doubleValue]];
    
    [_mapView addOverlay:circle];
}
- (BMKOverlayView *)mapView:(BMKMapView *)mapView viewForOverlay:(id <BMKOverlay>)overlay{
    if ([overlay isKindOfClass:[BMKCircle class]]){
        BMKCircleView* circleView = [[BMKCircleView alloc] initWithOverlay:overlay];
        circleView.fillColor = [[UIColor cyanColor] colorWithAlphaComponent:0.5];
        circleView.strokeColor = [[UIColor blueColor] colorWithAlphaComponent:0.5];
        circleView.lineWidth = 2.0;
        
        return circleView;
    }
    return nil;
}

#pragma mark - BMKLocationServiceDelegate 用户位置更新后，会调用此函数
- (void)didUpdateBMKUserLocation:(BMKUserLocation *)userLocation {
    [_mapView updateLocationData:userLocation];// 动态更新我的位置数据
    self.userLocation = userLocation;
    [_mapView setCenterCoordinate:userLocation.location.coordinate];// 当前地图的中心点
    /// geo检索信息类,获取当前城市数据
    BMKReverseGeoCodeOption *reverseGeoCodeOption = [[BMKReverseGeoCodeOption alloc] init];
    reverseGeoCodeOption.reverseGeoPoint = userLocation.location.coordinate;
    [_geoSearch reverseGeoCode:reverseGeoCodeOption];
}

#pragma mark 根据坐标返回反地理编码搜索结果
-(void)onGetReverseGeoCodeResult:(BMKGeoCodeSearch *)searcher result:(BMKReverseGeoCodeResult *)result errorCode:(BMKSearchErrorCode)error {
    BMKAddressComponent *addressComponent = result.addressDetail;
    self.city = addressComponent.city;
    NSString *title = [NSString stringWithFormat:@"%@%@%@%@", addressComponent.city, addressComponent.district, addressComponent.streetName, addressComponent.streetNumber];
    NSLog(@"%s -- %@", __func__, title);
}

#pragma mark -BMKMapViewDelegate
- (BMKAnnotationView *)mapView:(BMKMapView *)mapView viewForAnnotation:(id <BMKAnnotation>)annotation {
    // 创建大头针
    YMAnnotationView *annotationView = [YMAnnotationView annotationViewWithMap:mapView withAnnotation:annotation];
    YMPaopaoView *paopaoView = [[[NSBundle mainBundle] loadNibNamed:NSStringFromClass([YMPaopaoView class]) owner:nil options:nil] lastObject];
    paopaoView.delegate = self;
    YMPointAnnotation *anno = (YMPointAnnotation *)annotationView.annotation;
    paopaoView.poi = anno.poi;
    annotationView.paopaoView = [[BMKActionPaopaoView alloc] initWithCustomView:paopaoView];
    return annotationView;
//    static NSString *inden = @"datouzhen";
//    BMKAnnotationView *pin = [mapView dequeueReusableAnnotationViewWithIdentifier:inden];
//    if (pin == nil) {
//        pin = [[BMKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:inden];
//    }
//    
//    pin.annotation = annotation;
//    
//    // 设置是否弹出标注
//    pin.canShowCallout = YES;
//    pin.image = [UIImage imageNamed:@"icon_green"];
//    
//    
//    // 设置大头针图片(系统大头针无效)
//    //    pin.image = [UIImage imageNamed:@"category_5"];
//    
//    
//    pin.draggable = YES;
//    
//    //    pin.calloutOffset = CGPointMake(5, 8);
//    UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
//    iv.image = [UIImage imageNamed:@"icon_green"];
//    pin.leftCalloutAccessoryView = iv;
//    
//    UIImageView *ivR = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
//    ivR.image = [UIImage imageNamed:@"icon_green"];
//    pin.rightCalloutAccessoryView = ivR;
//
//    
//    return pin;

}

#pragma mark YMPaopaoViewDelagate
-(void)paopaoView:(YMPaopaoView *)paopapView coverButtonClickWithPoi:(YMPoi *)poi {
    jstRouteAnnotationViewController *routationVC = [[jstRouteAnnotationViewController alloc] init];
    routationVC.poi = poi;
    routationVC.city = self.city;
    routationVC.userLocation = self.userLocation;
    [self presentViewController:routationVC animated:YES completion:nil];

}

-(void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [_mapView viewWillDisappear];
    _mapView.delegate = nil; // 不用时，置nil
    _locService.delegate = nil;
    _geoSearch.delegate = nil;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [_mapView viewWillAppear];
    _mapView.delegate = self; // 此处记得不用的时候需要置nil，否则影响内存的释放
    _locService.delegate = self;
    _geoSearch.delegate = self;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

