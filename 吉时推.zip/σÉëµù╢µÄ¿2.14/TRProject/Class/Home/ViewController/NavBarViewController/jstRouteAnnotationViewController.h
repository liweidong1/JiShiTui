//
//  jstRouteAnnotationViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/15.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Base/BMKUserLocation.h>
@class YMPoi;

@interface jstRouteAnnotationViewController : UIViewController
/** poi*/
@property (nonatomic, strong) YMPoi *poi;
/** 用户当前位置*/
@property(nonatomic , strong) BMKUserLocation *userLocation;
/** 当前城市*/
@property (nonatomic, copy) NSString *city;

@end
