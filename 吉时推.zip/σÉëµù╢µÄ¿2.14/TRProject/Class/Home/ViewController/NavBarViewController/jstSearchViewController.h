//
//  jstSearchViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstSearchViewController : UITableViewController
- (instancetype)initWithMsgType:(NSInteger)childVC;
@property (nonatomic, assign) NSInteger childVC;


- (instancetype)initWithSearchContent:(NSString *)searchContent;
@property(nonatomic,strong)NSString *searchContent;
@end
