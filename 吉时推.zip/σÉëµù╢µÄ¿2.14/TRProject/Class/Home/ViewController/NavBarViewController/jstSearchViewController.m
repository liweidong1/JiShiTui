//
//  jstSearchViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/20.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstSearchViewController.h"
#import "HomeNetworking.h"
#import "SearchCell.h"
#import "SearchViewModel.h"
#import "jstMapViewController.h"
@interface jstSearchViewController ()
@property(nonatomic,strong)UILabel *testLable;
@property(nonatomic,strong)SearchViewModel *searchVM;
@property(nonatomic,strong)CoordCell *coordCell;
@end

@implementation jstSearchViewController
- (instancetype)initWithMsgType:(NSInteger)childVC{
    if (self = [super init]) {
        _childVC = childVC;
    }
    return self;
}
- (instancetype)initWithSearchContent:(NSString *)searchContent
{
    if (self = [super init]) {
        _searchContent = searchContent;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%@",_searchContent);
    //去掉多余的cell
    self.tableView.tableFooterView = [UIView new];
    //去掉cell之间的分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    [self.tableView registerClass:[ProductCell class] forCellReuseIdentifier:@"jstProductCell"];
    [self.tableView registerClass:[ShopCell class] forCellReuseIdentifier:@"jstShopCell"];
    [self.tableView registerClass:[CoordCell class] forCellReuseIdentifier:@"jstCoordCell"];
    [self loadDatas];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(searchChange:) name:@"SEARCHCONTENT" object:nil];
}
-(void)searchChange:(NSNotification *)notification
{
    //获取通知的参数
    NSString * searchContentCurrent = notification.userInfo[@"SearchContent"];
    if (_searchVM) {
        _searchVM = [[SearchViewModel alloc]initWithSearchContent:searchContentCurrent];
    }
    [self loadDatas];
}

-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        [weakSelf.searchVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView reloadData];
            [weakSelf.tableView endHeaderRefresh];
        }];
    }];
    [self.tableView beginHeaderRefresh];
    [self.tableView addFooterRefresh:^{
        [weakSelf.searchVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.tableView reloadData];
            [weakSelf.tableView endFooterRefresh];
        }];
    }];

}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (_childVC == 0) {
        return [self.searchVM ProductRowNumber];
    } else if(_childVC == 1 ) {
        return [self.searchVM ShopRowNumber];
    }else {
        return [self.searchVM CoordRowNumber];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_childVC == 0) {
        ProductCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstProductCell"];
        [cell.iconIV setImageWithURL:[self.searchVM ProductIcon:indexPath.row] placeholder:[UIImage imageNamed:@"store_commodity"]];
        cell.titleLb.text = [self.searchVM ProductTitle:indexPath.row];
        cell.subtitleLb.text = [self.searchVM ProductDesc:indexPath.row];
        cell.discountLb.text  = [NSString stringWithFormat:@"￥%@",[self.searchVM ProductDiscount:indexPath.row]];
        cell.sourcesLb.text  =[NSString stringWithFormat:@"门市价:￥%@",[self.searchVM ProductSource:indexPath.row]];
        NSMutableAttributedString * priceAttrString =[[NSMutableAttributedString alloc]initWithString:cell.sourcesLb.text];
        /**
         *  @author 李伟东
         *  添加样式
         *  @param NSUnderlineStyleSingle 单线
         *
         *  @param range  需要划线的字符索引
         */
        [priceAttrString addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(0, priceAttrString.length)];
        cell.sourcesLb.attributedText = priceAttrString;
        cell.quantityLb.text = @"库存";
        return cell;
    } else if(_childVC == 1) {
        ShopCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstShopCell"];
        [cell.iconIV setImageWithURL:[self.searchVM ShopIcon:indexPath.row] placeholder:[UIImage imageNamed:@"store_commodity"]];
        cell.titleLb.text = [self.searchVM ShopTitle:indexPath.row];
        cell.subtitleLb.text = [self.searchVM ShopDesc:indexPath.row];
        cell.addressLb.text  = [self.searchVM ShopAddress:indexPath.row];
        return cell;
    }else {
        CoordCell *cell = [tableView dequeueReusableCellWithIdentifier:@"jstCoordCell"];
        _coordCell = cell;
        cell.iconIV.image = [UIImage imageNamed:@"store_commodity"];
        cell.titleLb.text = [self.searchVM CoordSname:indexPath.row];
        return cell;
    }
    return [UITableViewCell new];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 100;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (_childVC == 2) {
        //传入经纬度跳转到地图页面，显示商圈信息
        NSString * scope = [self.searchVM CoordScope:indexPath.row];
        NSString * lat = [self.searchVM CoordLat:indexPath.row];
        NSString * lng = [self.searchVM CoordLng:indexPath.row];
        jstMapViewController * jstMapVC = [[jstMapViewController alloc]initWithScope:scope With:lat And:lng];
        [self.navigationController pushViewController:jstMapVC animated:YES];
    }
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
   [[NSNotificationCenter defaultCenter] postNotificationName:@"JJJJJJJJJ" object:nil];
}
- (SearchViewModel *)searchVM {
	if(_searchVM == nil) {
		_searchVM = [[SearchViewModel alloc] initWithSearchContent:_searchContent];
	}
	return _searchVM;
}

@end
