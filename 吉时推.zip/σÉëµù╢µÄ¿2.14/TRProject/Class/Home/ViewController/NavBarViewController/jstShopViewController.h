//
//  jstShopViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/23.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <BaiduMapAPI_Base/BMKUserLocation.h>
@class YMPoi;
@interface jstShopViewController : UIViewController
/** poi*/
@property (nonatomic, strong) YMPoi *poi;
/** 当前城市*/
@property (nonatomic, copy) NSString *city;
/** 用户当前位置*/
@property (nonatomic, strong) BMKUserLocation *userLocation;
@end
