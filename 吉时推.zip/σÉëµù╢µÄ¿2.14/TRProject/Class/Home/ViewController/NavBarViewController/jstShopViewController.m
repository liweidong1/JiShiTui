//
//  jstShopViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/23.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstShopViewController.h"
#import "YMPoi.h"
@interface jstShopViewController ()

@end

@implementation jstShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"店铺详情";
    UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 100, SCREEN_WIDTH-20, 40)];
    nameLabel.numberOfLines = 0;
    nameLabel.backgroundColor = [UIColor redColor];
    nameLabel.text = self.poi.title;
    [self.view addSubview:nameLabel];
    UILabel *areaNameLabel = [[UILabel alloc]initWithFrame:CGRectMake(20, 200, 100, 60)];
    areaNameLabel.backgroundColor = [UIColor blueColor];
    areaNameLabel.numberOfLines = 0;
    areaNameLabel.text = self.poi.hotphone;
    [self.view addSubview:areaNameLabel];
}

@end
