//
//  jstBusinessViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstBusinessViewController.h"
#import "BaseTableHeaderView.h"
#import "HomeHeaderCell.h"
#import "DiscountCell.h"
#import "BusicessCollectionViewCell.h"
#import "BusinessViewModel.h"
#import "NavScrollNetworking.h"
#import "jstGoodsViewController.h"
#import "BannerViewController.h"

@interface jstBusinessViewController ()<UICollectionViewDelegate,UICollectionViewDataSource>
@property (weak, nonatomic) IBOutlet UICollectionView *businessCollectionView;
@property(nonatomic,assign)NSInteger count;
@property(nonatomic,strong)BaseTableHeaderView *tableHeaderViews;
@property (nonatomic) BusinessViewModel *businessVM;

@property(nonatomic,assign)NSInteger collectionRow;

@property(nonatomic,assign)UIButton *loveBtn;

@end

@implementation jstBusinessViewController
static NSString * const reuseIdentifier = @"cellsss";
static NSString * const reuseIdentifier1 = @"cellsss1";
static NSString * const reuseIdentifier2 = @"cellsss2";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"xx店铺";
    [NavScrollNetworking getBusinessWithPage:1 completionHandler:^(BusinessHomeModel *model, NSError *error) {
        self.navigationItem.title = model.shop.shopname;
    }];
    [NavScrollNetworking getPayAttentionInfoCompletionHandler:^(BusinessPayAttentionInfoModel *model, NSError *error) {
        NSLog(@"%ld",model.flag);
        if (model.flag == 1) {  //关注
            [_loveBtn setImage:[UIImage imageNamed:@"store_laud1"] forState:UIControlStateNormal];
    
        }else {
            [_loveBtn setImage:[UIImage imageNamed:@"store_laud"] forState:UIControlStateNormal];
        }
    }];
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
    
    
    self.tabBarController.tabBar.backgroundColor = [UIColor clearColor];
    //创建右边两个item
    [self setupRightItems];

    [self.businessCollectionView registerClass:[BusicessCollectionViewCell class] forCellWithReuseIdentifier:reuseIdentifier2];
    [self setHeaderView];
    [self.tableHeaderViews registerClass:[HomeHeaderCell class] forCellReuseIdentifier:reuseIdentifier];
    [self.tableHeaderViews registerClass:[DiscountCell class] forCellReuseIdentifier:reuseIdentifier1];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(cliBanner:) name:@"BannerHTML" object:nil];
}

-(void)cliBanner:(NSNotification *)notification
{
    NSInteger bannerRowIndex = [notification.userInfo[@"SelectedBannerRow"] intValue];
    BannerViewController * bannerVC = [[BannerViewController alloc]initWithURL:[NSURL URLWithString:[self.businessVM uidInAdForRow:bannerRowIndex]]];
    [self.navigationController pushViewController:bannerVC animated:YES];
    
}
-(void)setCollectionView
{
    [self.businessCollectionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.equalTo(0);
        make.bottom.equalTo(60);
        make.height.equalTo(SCREEN_HEIGHT- SCREEN_WIDTH * 615 / 1125-44+60);
    }];
    UICollectionViewFlowLayout *layout = [UICollectionViewFlowLayout new];
    layout.sectionInset = UIEdgeInsetsZero;
    layout.minimumLineSpacing = 10;
    layout.minimumInteritemSpacing = 4;
    layout.sectionInset=UIEdgeInsetsMake(4, 4, 4, 4);
    CGFloat width = (long)(([UIScreen mainScreen].bounds.size.width - 16) / 3);
    //图片的宽高比
    CGFloat height = width*83/116 + 30;
    layout.itemSize = CGSizeMake(width, height);
    self.businessCollectionView.collectionViewLayout = layout;
    self.businessCollectionView.delegate =self;
    self.businessCollectionView.dataSource = self;
    
    JSTWeakSelf
    [self.businessCollectionView addHeaderRefresh:^{
        [weakSelf.businessVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.businessCollectionView reloadData];
            [weakSelf.businessCollectionView endHeaderRefresh];
        }];
    }];
    [self.businessCollectionView beginHeaderRefresh];
    [self.businessCollectionView addFooterRefresh:^{
        [weakSelf.businessVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.businessCollectionView reloadData];
            [weakSelf.businessCollectionView endFooterRefresh];
        }];
    }];
}
-(void)setHeaderView
{
    //CGRect bounds = [UIScreen mainScreen].bounds;
    CGRect bounds = CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_WIDTH * 615 / 1125+44);
    self.tableHeaderViews =[[BaseTableHeaderView alloc]initWithFrame:bounds];
    [self.view addSubview:self.tableHeaderViews];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setCollectionView];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
}

- (void)setupRightItems {
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.20, 35)];
    UIImageView *iv = [[UIImageView alloc]init];
    [rightView addSubview:iv];
    iv.image = [UIImage imageNamed:@"store_share"];
    iv.userInteractionEnabled = YES;
    [iv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(0);
        make.top.equalTo(5);
        make.bottom.equalTo(-5);
        make.width.equalTo(25);
    }];
    UITapGestureRecognizer* rightTapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(enterInfo)];
    rightTapGR.numberOfTapsRequired=1;
    [iv addGestureRecognizer:rightTapGR];
    UIButton * btn = [[UIButton alloc]init];
    [btn addTarget:self action:@selector(clickLoveBtn) forControlEvents:UIControlEventTouchUpInside];
    _loveBtn = btn;
    [btn setImage:[UIImage imageNamed:@"store_laud"] forState:UIControlStateNormal];

    [rightView addSubview:btn];

    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(10);
        make.top.equalTo(8);
        make.bottom.equalTo(-5);
        make.width.equalTo(25);
    }];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}
-(void)enterInfo
{
    //分享
    //1、创建分享参数
    NSArray* imageArray = @[[UIImage imageNamed:@"header1"]];
    //（注意：图片必须要在Xcode左边目录里面，名称必须要传正确，如果要分享网络图片，可以这样传iamge参数 images:@[@"http://mob.com/Assets/images/logo.png?v=20150320"]）
    if (imageArray) {
        
        NSMutableDictionary *shareParams = [NSMutableDictionary dictionary];
        [shareParams SSDKSetupShareParamsByText:@"回龙观商圈"
                                         images:[UIImage imageNamed:@"header1"]
                                            url:[NSURL URLWithString:@"www.baidu.com"]
                                          title:@"商城"
                                           type:SSDKContentTypeAuto];
        /*特别的分享到微信朋友圈
         [shareParams SSDKSetupWeChatParamsByText:[self.videoVM titleForRow:row] title:[self.videoVM topicNameForRow:row] url:[self.videoVM videoURLForRow:row] thumbImage:[self.videoVM coverUrlForRow:row] image:[self.videoVM topicImgURLForRow:row] musicFileURL:nil extInfo:[self.videoVM topicDescForRow:row] fileData:[self.videoVM mp4_urlForRow:row] emoticonData:nil sourceFileExtension:[self.videoVM videosourceForRow:row] sourceFileData:nil type:SSDKContentTypeAuto forPlatformSubType:SSDKPlatformSubTypeWechatTimeline];
         */
        //2、分享（可以弹出我们的分享菜单和编辑界面）
        [ShareSDK showShareActionSheet:nil //要显示菜单的视图, iPad版中此参数作为弹出菜单的参照视图，只有传这个才可以弹出我们的分享菜单，可以传分享的按钮对象或者自己创建小的view 对象，iPhone可以传nil不会影响
                                 items:nil
                           shareParams:shareParams
                   onShareStateChanged:^(SSDKResponseState state, SSDKPlatformType platformType, NSDictionary *userData, SSDKContentEntity *contentEntity, NSError *error, BOOL end) {
                       
                       switch (state) {
                           case SSDKResponseStateSuccess:
                           {
                               UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"分享成功"
                                                                                   message:nil
                                                                                  delegate:nil
                                                                         cancelButtonTitle:@"确定"
                                                                         otherButtonTitles:nil];
                               [alertView show];
                               break;
                           }
                           case SSDKResponseStateFail:
                           {
                               UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"分享失败"
                                                                               message:[NSString stringWithFormat:@"%@",error]
                                                                              delegate:nil
                                                                     cancelButtonTitle:@"OK"
                                                                     otherButtonTitles:nil, nil];
                               [alert show];
                               break;
                           }
                           default:
                               break;
                       }
                   }
         ];}
    
    
}
#pragma -mark   集合视图
- (BusinessViewModel *)businessVM{
    if (!_businessVM) {
        _businessVM = [BusinessViewModel new];
    }
    return _businessVM;
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    //行数对于写VC的来说, 不需要思考的, 直接从VM拿就可以了.
    //因为具体的思考逻辑, 被封装到了VM层
//    NSLog(@"%ld",self.businessVM.rowNumber);
   return self.businessVM.goodsRowNumber;
    //return 10;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    BusicessCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:reuseIdentifier2 forIndexPath:indexPath];
    //cell.titleLb.text = [self.businessVM titleForRow:indexPath.row];
    //cell.usersLb.text = [self.businessVM usersForRow:indexPath.row];
    //YYWebImage提供的网络图片获取方法
    //参数2:网络图片没有下载完毕之前的默认图.
    [cell.iconIV setImageWithURL:[self.businessVM goodsIcon:indexPath.row] placeholder:[UIImage imageNamed:@"store_commodity"]];
    cell.titleLb.text = [self.businessVM goodsTitle:indexPath.row];
    cell.soldLb.text = [NSString stringWithFormat:@"已售%@",[self.businessVM goodsSold:indexPath.row]];
    cell.discountLb.text = [NSString stringWithFormat:@"￥%@",[self.businessVM goodsDiscount:indexPath.row]];
    cell.sourcesLb.text = [NSString stringWithFormat:@"门市价:￥%@",[self.businessVM goodsSources:indexPath.row]];
    
    NSMutableAttributedString * priceAttrString =[[NSMutableAttributedString alloc]initWithString:cell.sourcesLb.text];
    /**
     *  @author 李伟东
     *  添加样式
     *  @param NSUnderlineStyleSingle 单线
     *
     *  @param range  需要划线的字符索引
     */
    [priceAttrString addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(0, priceAttrString.length)];
    cell.sourcesLb.attributedText = priceAttrString;

    
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    //跳转到商品名称页面
    NSInteger pid = [self.businessVM goodsPid:indexPath.row];
    jstGoodsViewController *jstVC = [[jstGoodsViewController alloc]initWithPid:pid];
    jstVC.titless = [self.businessVM goodsTitle:indexPath.row];
    [self.navigationController pushViewController:jstVC animated:YES];
}
-(void)clickLoveBtn
{
    NSLog(@"测试");
    [NavScrollNetworking getPayAttentionInfoCompletionHandler:^(BusinessPayAttentionInfoModel *model, NSError *error) {
        NSLog(@"%ld",model.flag);
        if (model.flag == 1) {  //关注
            [NavScrollNetworking getPayAttentionCompletionHandler:^(BusinessPayAttentionModel *model, NSError *error) {
                //取消关注    关注人数-1
                if (model.status == 1) {
                    [NavScrollNetworking getPayAttentionInfoCompletionHandler:^(BusinessPayAttentionInfoModel *model, NSError *error) {
                        self.tableHeaderViews.personCountLab.text = [NSString stringWithFormat:@"关注人数%ld", model.count];
                    }];
                    [WSProgressHUD showSuccessWithStatus:@"取关成功"];
                    [_loveBtn setImage:[UIImage imageNamed:@"store_laud"] forState:UIControlStateNormal];
                }else {
                    [WSProgressHUD showErrorWithStatus:@"取关失败"];
                }
                
            }];
        }else {
            [NavScrollNetworking getPayAttentionCompletionHandler:^(BusinessPayAttentionModel *model, NSError *error) {
                //关注    关注人数+1
                if (model.status == 1) {
                    [NavScrollNetworking getPayAttentionInfoCompletionHandler:^(BusinessPayAttentionInfoModel *model, NSError *error) {
                        self.tableHeaderViews.personCountLab.text = [NSString stringWithFormat:@"关注人数%ld", model.count];
                    }];
                    [WSProgressHUD showSuccessWithStatus:@"关注成功"];
                    [_loveBtn setImage:[UIImage imageNamed:@"store_laud1"] forState:UIControlStateNormal];
                }else {
                    [WSProgressHUD showErrorWithStatus:@"关注失败"];
                }
            }];
        }
        
    }];

}
@end
