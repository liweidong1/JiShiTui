//
//  jstGoodsViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/26.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstGoodsViewController : UIViewController
-(instancetype)initWithPid:(NSInteger )pid;
@property(nonatomic,readonly) NSInteger pid;


@property(nonatomic,strong) NSString *titless;


/**
 *  商品详情显示数据
 */
@property (nonatomic, strong) UIImageView *img;
@property(nonatomic,strong)UILabel  *lab;


@end
