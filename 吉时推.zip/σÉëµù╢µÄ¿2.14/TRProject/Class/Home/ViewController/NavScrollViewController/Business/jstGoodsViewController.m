//
//  jstGoodsViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/26.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstGoodsViewController.h"
#import "GoodsDetailCell.h"
#import "NavScrollNetworking.h"
#import "GoodsDetailViewModel.h"
#import "jstReplyViewController.h"

#import "JSCartViewController.h"
#import "jstPayStyleViewController.h"


@interface jstGoodsViewController ()<UITableViewDelegate,UITableViewDataSource,CAAnimationDelegate,UIScrollViewDelegate>


@property(nonatomic,strong)UIScrollView * sv;



@property(nonatomic,strong)UITableView * tableView;

@property(nonatomic,strong)UIView * cover;

@property(nonatomic,strong)GoodsDetailViewModel * goodsdetailVM;

@property(nonatomic,strong)GoodsHeaderCell * offlineCell;

@property(nonatomic,strong)GoodsComentCell * commentCell;

@property (nonatomic,strong) UIBezierPath *path;
@property(nonatomic,strong)UIButton *changeBtn;//购物车动画参数


@property(nonatomic,strong)UIButton *btnInfo;//记录购物车数量改变
@property(nonatomic,assign)NSInteger carCount;//购物车动画参数
@end

static NSString *idens = @"cell";

@implementation jstGoodsViewController{
    UITableView     *_tableView;
    CALayer         *_layer;
    UIButton        *_shopCartbtn;
    NSInteger       _cnt;      // 记录个数
    NSMutableArray *_dataSource;
    BOOL            _animType; // 动画类型
}



- (instancetype)initWithPid:(NSInteger)pid
{
    if (self = [super init]) {
        _pid = pid;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%ld",_pid);
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
    //创建右边两个item
    [self setupRightItems];
    [self setTableView];
    [self setBottomViews];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clicKGoodsDetail:) name:@"GOODSDETAILBTN" object:nil];
    //全部评论 好评 差评ALLCOMMENT
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickAllComment:) name:@"ALLCOMMENT" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickGoodComment:) name:@"GOODCOMMENT" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(clickBedComment:) name:@"BEDCOMMENT" object:nil];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

-(void)clicKGoodsDetail:(NSNotification *)notification
{
    UIView *cover = [[UIView alloc]initWithFrame:self.view.frame];
    _cover =cover;
    //1滚动视图
    UIScrollView * sv =[[UIScrollView alloc]init];
    self.sv=sv;
    sv.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [cover addSubview:sv];
    [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
        NSLog(@"%ld",_pid);
        for (int i = 0; i<model.datas[0].images.count; i++) {
            NSLog(@"%ld",model.datas[0].images.count);
            _img = [[UIImageView alloc]init];
            _img.frame = CGRectMake(i*sv.bounds.size.width, SCREEN_HEIGHT*.3, sv.bounds.size.width, SCREEN_HEIGHT*.3);
            [sv addSubview:_img];
            _lab = [[UILabel  alloc] init];
            _lab.frame = CGRectMake(i*sv.bounds.size.width, SCREEN_HEIGHT*.6, sv.bounds.size.width, SCREEN_HEIGHT*.3);

            _lab.numberOfLines = 0;
            _lab.textColor = [UIColor whiteColor];
            _lab.textAlignment = NSTextAlignmentCenter;
            _lab.font = [UIFont systemFontOfSize:13];
            [sv addSubview:_lab];

            sv.bounces =NO;
            sv.showsHorizontalScrollIndicator = NO;
            sv.scrollEnabled = YES;
            sv.pagingEnabled = YES;
            sv.contentSize = CGSizeMake((i+1)*sv.bounds.size.width, sv.bounds.size.height);
            
            
            [_img setImageWithURL:[NSURL URLWithString:model.datas[0].images[i]] placeholder:[UIImage imageNamed:@""]];
            NSLog(@"-%d--%@-----",i,model.datas[0].images[i]);
            _lab.text = model.datas[0].info;
            NSLog(@"%@%@",model.datas[0].images[0],model.datas[0].info);
        }

    }];

    [UIView animateWithDuration:1.0f animations:^{
        cover.tag = 199999;
        cover.backgroundColor = [UIColor blackColor];
        cover.alpha = .9;
        
    } completion:^(BOOL finished) {
       [self.view addSubview:cover];
    }];
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tapGR.numberOfTapsRequired=1;
    [cover addGestureRecognizer:tapGR];
}
-(void)tap:(UITapGestureRecognizer *)gr
{
        //移除模糊图片
        UIView *cover = (UIView*)[self.view viewWithTag:199999];
        [UIView animateWithDuration:1.f animations:^{
            cover.alpha = 0.f;
        } completion:^(BOOL finished) {
            [cover removeFromSuperview];
        }];
}
-(void)clickBedComment:(NSNotification *)notification
{
    
    NSLog(@"差评");
    _commentCell.serviceLab.textColor = [UIColor whiteColor];
    _commentCell.serviceLab.backgroundColor = bgColor(0, 175, 203);
    _commentCell.priceLab.textColor = bgColor(83, 203, 217);
    _commentCell.priceLab.backgroundColor = [UIColor whiteColor];
    _commentCell.environmentLab.textColor = bgColor(83, 203, 217);
    _commentCell.environmentLab.backgroundColor = [UIColor whiteColor];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BEDCOMMENTVM" object:nil];
    [self loadClickData];
}

-(void)clickGoodComment:(NSNotification *)notification
{
    
    NSLog(@"好评");
    _commentCell.environmentLab.textColor = [UIColor whiteColor];
    _commentCell.environmentLab.backgroundColor = bgColor(0, 175, 203);
    _commentCell.priceLab.textColor = bgColor(83, 203, 217);
    _commentCell.priceLab.backgroundColor = [UIColor whiteColor];
    _commentCell.serviceLab.textColor = bgColor(83, 203, 217);
    _commentCell.serviceLab.backgroundColor = [UIColor whiteColor];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"GOODCOMMENTVM" object:nil];
    [self loadClickData];
}

-(void)clickAllComment:(NSNotification *)notification
{
    NSLog(@"所有评论");
    _commentCell.priceLab.textColor = [UIColor whiteColor];
    _commentCell.priceLab.backgroundColor = bgColor(0, 175, 203);
    _commentCell.environmentLab.textColor = bgColor(83, 203, 217);
    _commentCell.environmentLab.backgroundColor = [UIColor whiteColor];
    _commentCell.serviceLab.textColor = bgColor(83, 203, 217);
    _commentCell.serviceLab.backgroundColor = [UIColor whiteColor];
    //1发通知到模型层    2  请求数据   刷新表视图
    [[NSNotificationCenter defaultCenter] postNotificationName:@"AllCOMMENTVM" object:nil];
    [self loadClickData];
}
-(void)loadClickData
{
    JSTWeakSelf
//    [self.tableView beginFooterRefresh];
//    [self.tableView addFooterRefresh:^{
        //获取VM数据
        [weakSelf.goodsdetailVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView reloadData];
        }];
//    }];

}
-(void)setBottomViews
{
    UIButton * leftBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-50, SCREEN_WIDTH/2-2, 50)];
    leftBtn.backgroundColor = bgColor(255, 180, 0);
    [leftBtn setTitle:@"加入购物车" forState:UIControlStateNormal];
    [leftBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    UIButton * rightBtn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH/2+2 , SCREEN_HEIGHT-50, SCREEN_WIDTH/2-2, 50)];
    [rightBtn setTitle:@"立即购买" forState:UIControlStateNormal];
    rightBtn.backgroundColor = bgColor(0, 177, 200);
    [rightBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];

    [self.view addSubview:leftBtn];
    [self.view addSubview:rightBtn];
    
//    UIImageView * iv = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
//    iv.image = [UIImage imageNamed:@"header1"];
//    //iv.hidden = YES;
//    [leftBtn addSubview:iv];

    [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
        self.navigationItem.title = self.titless;
        if (model.datas[0].delivery == 0) {
            _offlineCell.offlineLab.hidden = YES;
            [leftBtn bk_addEventHandler:^(id sender) {
                //pod 动画，本地推送，购物侧数量+1
//                CGRect rect = iv.frame;
//                CGPoint changeRect = _changeBtn.frame.origin;
//                [self startAnimationandView:iv andRect:rect andFinisnRect:changeRect];
            [NavScrollNetworking getGoodsDetailAddShopCarWithUid:1 WithPid:_pid CompletionHandler:^(ShopCarAddModel *model, NSError *error) {
                if (model.status == 1) {
                    _carCount++;
                    if (_carCount > 99) {
                        _btnInfo.hidden = NO;
                        _btnInfo.font = [UIFont systemFontOfSize:8];
                    [_btnInfo setTitle:@"99+" forState:UIControlStateNormal];
                    }else {
                        _btnInfo.hidden = NO;
                        [_btnInfo setTitle:[NSString stringWithFormat:@"%ld",_carCount] forState:UIControlStateNormal];
                        [WSProgressHUD showSuccessWithStatus:@"加入购物车成功"];
                    }
                }else {
                    [WSProgressHUD showSuccessWithStatus:@"加入购物车失败"];
                }
            }];
            } forControlEvents:UIControlEventTouchUpInside];

            [rightBtn bk_addEventHandler:^(id sender) {
                jstPayStyleViewController *payVC = [[jstPayStyleViewController alloc]init];
                [self.navigationController pushViewController:payVC animated:YES];
            } forControlEvents:UIControlEventTouchUpInside];
        }else {
            _offlineCell.offlineLab.hidden = NO;
            [leftBtn setTitle:@"联系商家" forState:UIControlStateNormal];
            [leftBtn bk_addEventHandler:^(id sender) {
                [self phoneCall];
            } forControlEvents:UIControlEventTouchUpInside];
            [rightBtn setTitle:@"在线咨询" forState:UIControlStateNormal];
            [rightBtn bk_addEventHandler:^(id sender) {
               //在线预约接口还没做
                [WSProgressHUD showErrorWithStatus:@"在线预约接口还没做"];
            } forControlEvents:UIControlEventTouchUpInside];
        }
    }];
}
//加入购物车动画效果
//-(void)startAnimationandView:(UIImageView *)iv andRect:(CGRect)rect andFinisnRect:(CGPoint)finishPoint
//{
//    //图层
//    _layer = [CALayer layer];
//    _layer.contents = iv.layer.contents;//
//    _layer.contentsGravity = kCAGravityResizeAspect;
//    
//    // 改变做动画图片的大小
//    rect.size.width = 50;
//    rect.size.height = 100;   //重置图层尺寸
//    _layer.bounds = rect;
//    [_changeBtn.layer addSublayer:_layer];
//    
//    //_layer.position = CGPointMake(rect.origin.x+iv.frame.size.width/2, CGRectGetMidY(rect)); //a 点
//    _layer.position = CGPointMake(25, SCREEN_HEIGHT-64-50);
//
//    // 路径
//    UIBezierPath *path = [UIBezierPath bezierPath];
//    [path moveToPoint:_layer.position];
//    
//    //确定抛物线的最高点位置  controlPoint
//    [path addQuadCurveToPoint:finishPoint controlPoint:CGPointMake(SCREEN_WIDTH/2 , _changeBtn.origin.y+200)];
//    //关键帧动画
//    CAKeyframeAnimation *pathAnimation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
//    pathAnimation.path = path.CGPath;
//    // pathAnimation.delegate = self;
//    
//    //往上抛时旋转小动画
//    CABasicAnimation *rotateAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
//    rotateAnimation.removedOnCompletion = YES;
//    rotateAnimation.fromValue = [NSNumber numberWithFloat:0];
//    rotateAnimation.toValue = [NSNumber numberWithFloat:12];
//    
//    /**
//     *   kCAMediaTimingFunctionLinear   动画从头到尾的速度是相同的
//     kCAMediaTimingFunctionEaseIn   动画以低速开始。
//     kCAMediaTimingFunctionEaseOut  动画以低速结束。
//     kCAMediaTimingFunctionEaseInEaseOut   动画以低速开始和结束。
//     kCAMediaTimingFunctionDefault
//     */
//    
//    rotateAnimation.timingFunction=[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
//    CAAnimationGroup *groups = [CAAnimationGroup animation];
//    groups.animations = @[pathAnimation,rotateAnimation];
//    groups.duration = 1.2f;
//    
//    //设置之后做动画的layer不会回到一开始的位置
//    groups.removedOnCompletion=NO;
//    groups.fillMode=kCAFillModeForwards;
//    
//    //让工具类成为组动画的代理
//    groups.delegate = self;
//    [_layer addAnimation:groups forKey:@"group"];
//}
//-(void)animationDidStop:(CAAnimation *)anim finished:(BOOL)flag
//{
//    if (anim == [_layer animationForKey:@"group"]) {
//        _tableView.userInteractionEnabled = YES;
//        [_layer removeFromSuperlayer];
//        _layer = nil;
//        _cnt++;
//        
//        
//    }
//}


-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-50+44) style:UITableViewStyleGrouped];
   // self.tableView.backgroundColor = [UIColor redColor];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:idens];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[GoodsHeaderCell class] forCellReuseIdentifier:@"GoodsHeaderCELL"];
    [self.tableView registerClass:[GoodsAdressCell class] forCellReuseIdentifier:@"GoodsAdressCELL"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerClass:[GoodsComentCell class] forCellReuseIdentifier:@"GoodsComentCELL"];
    [self.tableView registerClass:[GoodsCommentDetailCell class] forCellReuseIdentifier:@"GoodsCommentDetailCELL"];
    [self.tableView registerClass:[GoodsDetailsCell class] forCellReuseIdentifier:@"GoodsDetailsCELL"];
    [self loadDatas];                 
}
-(void)loadDatas
{
    JSTWeakSelf
    //    NSMutableArray *headerImages = [NSMutableArray array];
    //    for (int i = 1; i <= 3; i++) {
    //        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"refresh-%d",i]];
    //        [headerImages addObject:image];
    //    }
    //    //----------------------------------------------------
    //    MJRefreshGifHeader *gifHeader = [MJRefreshGifHeader headerWithRefreshingBlock:^{
    //        //下拉刷新要做的操作.
    //        //获取VM数据
    //        [weakSelf.homeVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
    //            [weakSelf.tableView endHeaderRefresh];
    //            [weakSelf.tableView reloadData];
    //        }];
    //    }];
    //    gifHeader.stateLabel.hidden = YES;
    //    gifHeader.lastUpdatedTimeLabel.hidden = YES;
    //
    //    [gifHeader setImages:@[headerImages[0]] forState:MJRefreshStateIdle];
    //    [gifHeader setImages:headerImages forState:MJRefreshStateRefreshing];
    //    self.tableView.mj_header = gifHeader;
    //----------------------------------------------------------
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.goodsdetailVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];
    [self.tableView addFooterRefresh:^{
        //获取VM数据
        [weakSelf.goodsdetailVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
}
- (void)setupRightItems {
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.20, 35)];
    UIImageView *iv = [[UIImageView alloc]init];
    [rightView addSubview:iv];
    iv.image = [UIImage imageNamed:@"store_share"];
    iv.userInteractionEnabled = YES;
    [iv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(0);
        make.top.equalTo(5);
        make.bottom.equalTo(-5);
        make.width.equalTo(25);
    }];
    UITapGestureRecognizer* rightTapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(enterInfo)];
    rightTapGR.numberOfTapsRequired=1;
    [iv addGestureRecognizer:rightTapGR];
    UIButton * btn = [[UIButton alloc]init];
    _changeBtn = btn;
    [rightView addSubview:btn];
    //消息值需改变   如果有消息推送，则显示，否则隐藏
    [btn setImage:[UIImage imageNamed:@"store_car"] forState:UIControlStateNormal];
    [btn bk_addEventHandler:^(id sender) {
        //跳转购物车界面
        //需要用户的uid
        JSCartViewController *carVC = [[JSCartViewController alloc]init];
        [self.navigationController pushViewController:carVC animated:YES];

    } forControlEvents:UIControlEventTouchUpInside];
    
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(10);
        make.top.equalTo(8);
        make.bottom.equalTo(-5);
        make.width.equalTo(25);
    }];
    UIButton * btnInfo = [[UIButton alloc]init];
    btnInfo.hidden = YES;
    _btnInfo = btnInfo;
    [btn addSubview:btnInfo];
    
    //消息值需改变   如果有消息推送，则显示，否则隐藏
    btnInfo.layer.masksToBounds = YES;
    btnInfo.layer.cornerRadius = 8.5;
    btnInfo.backgroundColor = [UIColor redColor];
    btnInfo.font = [UIFont systemFontOfSize:11];
    [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
        NSLog(@"%ld",model.car);
        if (model.car == 0) {
            btnInfo.hidden = YES;
        }else if (model.car > 99) {
            _btnInfo.hidden = NO;
            _btnInfo.font = [UIFont systemFontOfSize:9];
            [_btnInfo setTitle:@"99+" forState:UIControlStateNormal];
        }else {
            btnInfo.hidden = NO;
            [btnInfo setTitle:[NSString stringWithFormat:@"%ld",model.car] forState:UIControlStateNormal];
        }
               _carCount = model.car;
    }];
    [btnInfo setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [btnInfo mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(5);
        make.right.equalTo(10);
        make.size.equalTo(CGSizeMake(17, 17));
    }];
    UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
    self.navigationItem.rightBarButtonItem = rightBarButtonItem;
}
-(void)enterInfo
{
    //分享
    //1、创建分享参数
    NSArray* imageArray = @[[UIImage imageNamed:@"header1"]];
    //（注意：图片必须要在Xcode左边目录里面，名称必须要传正确，如果要分享网络图片，可以这样传iamge参数 images:@[@"http://mob.com/Assets/images/logo.png?v=20150320"]）
    if (imageArray) {
        
        NSMutableDictionary *shareParams = [NSMutableDictionary dictionary];
        [shareParams SSDKSetupShareParamsByText:@"回龙观商圈"
                                         images:[UIImage imageNamed:@"header1"]
                                            url:[NSURL URLWithString:@"www.baidu.com"]
                                          title:@"商城"
                                           type:SSDKContentTypeAuto];
        /*特别的分享到微信朋友圈
         [shareParams SSDKSetupWeChatParamsByText:[self.videoVM titleForRow:row] title:[self.videoVM topicNameForRow:row] url:[self.videoVM videoURLForRow:row] thumbImage:[self.videoVM coverUrlForRow:row] image:[self.videoVM topicImgURLForRow:row] musicFileURL:nil extInfo:[self.videoVM topicDescForRow:row] fileData:[self.videoVM mp4_urlForRow:row] emoticonData:nil sourceFileExtension:[self.videoVM videosourceForRow:row] sourceFileData:nil type:SSDKContentTypeAuto forPlatformSubType:SSDKPlatformSubTypeWechatTimeline];
         */
        //2、分享（可以弹出我们的分享菜单和编辑界面）
        [ShareSDK showShareActionSheet:nil //要显示菜单的视图, iPad版中此参数作为弹出菜单的参照视图，只有传这个才可以弹出我们的分享菜单，可以传分享的按钮对象或者自己创建小的view 对象，iPhone可以传nil不会影响
                                 items:nil
                           shareParams:shareParams
                   onShareStateChanged:^(SSDKResponseState state, SSDKPlatformType platformType, NSDictionary *userData, SSDKContentEntity *contentEntity, NSError *error, BOOL end) {
                       
                       switch (state) {
                           case SSDKResponseStateSuccess:
                           {
                               UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"分享成功"
                                                                                   message:nil
                                                                                  delegate:nil
                                                                         cancelButtonTitle:@"确定"
                                                                         otherButtonTitles:nil];
                               [alertView show];
                               break;
                           }
                           case SSDKResponseStateFail:
                           {
                               UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"分享失败"
                                                                               message:[NSString stringWithFormat:@"%@",error]
                                                                              delegate:nil
                                                                     cancelButtonTitle:@"OK"
                                                                     otherButtonTitles:nil, nil];
                               [alert show];
                               break;
                           }
                           default:
                               break;
                       }
                   }
         ];}
    
    
}



#pragma tableView代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0.00001;//这里是设置tableView的第一部分的头视图高度为0.01
    }else {
        return 10;//这里设置其他部分的头视图高度为10
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 4;
}

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section == 3) {
        //添加查看全部评价按钮，然后更新此分区数据
        UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(100, 10, 60, 20)];
        btn.backgroundColor = [UIColor whiteColor];
        [btn setTitle:@"查看全部评论" forState:UIControlStateNormal];
        [btn setTitleColor:bgColor(0, 176, 191) forState:UIControlStateNormal];
        [btn bk_addEventHandler:^(id sender) {
            //刷新数据
        } forControlEvents:UIControlEventTouchUpInside];
        return btn;
    }else {
    return nil;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 3) {
        return 50;
    }else {
        return 0.01;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==3) {
        NSLog(@"%ld",[self.goodsdetailVM goodsDetailRowNumber]);
        return [self.goodsdetailVM goodsDetailRowNumber] + 1;
    }else {
        return 1;
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return SCREEN_HEIGHT*.43;
    }else if(indexPath.section == 1) {
        return SCREEN_HEIGHT*.1;
    }else if(indexPath.section == 3){
        if (indexPath.row == 0) {
            return SCREEN_HEIGHT*.12;
        }else {
            return 150;
        }
    }else {
        return 44;
    }
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:idens];
    if (indexPath.section == 0) {
        GoodsHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsHeaderCELL"];
        _offlineCell = cell;
        [self loadHeaderData];
        return cell;
       } else if(indexPath.section == 1){
           GoodsAdressCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsAdressCELL"];
           [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
               cell.titleLab.text = [NSString stringWithFormat:@"[%@]",model.datas[0].sname];
               cell.adressLab.text = [NSString stringWithFormat:@"%@",model.datas[0].address];
               cell.distanceLab.text = [NSString stringWithFormat:@"%@",model.datas[0].juli];
               [cell.phoneBtn bk_addEventHandler:^(id sender) {
                   [self phoneCall];
                   
               } forControlEvents:UIControlEventTouchUpInside];

           }];

           [cell.phoneBtn setImage:[UIImage imageNamed:@"store_phone"] forState:UIControlStateNormal];
           return cell;
       }else if(indexPath.section == 2){
           GoodsDetailsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsDetailsCELL"];
           [cell.goodsDetailBtn setTitle:@"[商品详情]" forState:UIControlStateNormal];
           return cell;
       }else if(indexPath.section == 3){
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
           if (indexPath.row == 0) {
               GoodsComentCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsComentCELL"];
               _commentCell = cell;
               cell.priceLab.text = @"全部";
               [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
                   NSLog(@"%ld",_pid);
                   cell.userCommentLab.text = [NSString stringWithFormat:@"[[用户评价] ( %ld )]",model.rep];
                   cell.environmentLab.text = [NSString stringWithFormat:@"好评(%ld)",model.gcount];
                   cell.serviceLab.text = [NSString stringWithFormat:@"差评(%ld)",model.bcount];
                   cell.ratioLab.text = [NSString stringWithFormat:@"好评率(%.2f%%)",model.lv];
               }];
               return cell;
           }else{
               GoodsCommentDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"GoodsCommentDetailCELL"];
               [cell.userImg setImageWithURL:[self.goodsdetailVM goodsDetailIcon:indexPath.row-1] placeholder:[UIImage imageNamed:@"store_commodity"]];
               cell.commentImg.image = [UIImage imageNamed:@"store_comments"];
               [cell setCommentBtnClicked:^(GoodsCommentDetailCell *cell) {
                   NSLog(@"VC 获取cell中评论的的按钮点击事件");
                   NSIndexPath *ip = [tableView indexPathForCell:cell];
                   [self entComment:ip.row];
               }];
               if ([[self.goodsdetailVM goodsDetailComtype:indexPath.row-1] isEqualToString:@"0"]) {
                   cell.ratioLab.text = @"好评";
               }else {
                    cell.ratioLab.text = @"差评";
               }
               
               cell.userPhoneLab.text = [self.goodsdetailVM goodsDetailNickname:indexPath.row-1];
               NSString *timeData = [self.goodsdetailVM goodsDetailTime:indexPath.row-1];
               //时间戳转时间的方法

               NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[timeData intValue]];
               NSLog(@" %@",confromTimesp);
               NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];//实例化一个NSDateFormatter对象
               //[dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];//设定时间格式
               [dateFormat setDateFormat:@"MM-dd"];
               NSString *dateString = [dateFormat stringFromDate:confromTimesp]; //求出当天的时间字符串，当更改时
               cell.userCommentTimeLab.text = dateString;
               cell.userdetailLab.text = [self.goodsdetailVM goodsDetailContent:indexPath.row-1];
               cell.commentCount.text = [self.goodsdetailVM goodsDetailReplay:indexPath.row-1];
               return cell;
           }
       }else {
                 }
    return [UITableViewCell new];
}
-(void)loadHeaderData
{
    [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
        [_offlineCell.iconIV setImageWithURL:[NSURL URLWithString:model.datas[0].img] placeholder:[UIImage imageNamed:@"store_commodity"]];
        _offlineCell.countLab.text = [NSString stringWithFormat:@"浏览次数 %ld",model.datas[0].viewnum];
        _offlineCell.soldLab.text = [NSString stringWithFormat:@"已售%ld",model.datas[0].sell_number];
        _offlineCell.sourcesLb.text  = [NSString stringWithFormat:@"门市价:￥%ld",model.datas[0].price];
        _offlineCell.discountLb.text = [NSString stringWithFormat:@"￥%ld",model.datas[0].disprice];
        _offlineCell.offlineLab.text = @"此商品需线下自取";
        NSMutableAttributedString * priceAttrString =[[NSMutableAttributedString alloc]initWithString:_offlineCell.sourcesLb.text];
        /**
         *  @author 李伟东
         *  添加样式
         *  @param NSUnderlineStyleSingle 单线
         *
         *  @param range  需要划线的字符索引
         */
        [priceAttrString addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(0, priceAttrString.length)];
        _offlineCell.sourcesLb.attributedText = priceAttrString;
    }];

}
-(void)entComment:(NSInteger)row{
    NSLog(@"%ld",row);
    
    NSInteger cid = [self.goodsdetailVM goodsDetailCid:row-1];
    NSLog(@"%ld",cid);
    jstReplyViewController *replyVC = [[jstReplyViewController alloc]initWithCid:cid];
    [self.navigationController pushViewController:replyVC animated:YES];
}

-(void)enterWriteOrder:(UIButton *)sender
{
    NSLog(@"填写订单");
    //[self.navigationController pushViewController:[DLWriteOrderController new] animated:YES];
}

- (GoodsDetailViewModel *) goodsdetailVM {
	if(_goodsdetailVM == nil) {
        NSLog(@"%ld",_pid);
		_goodsdetailVM = [[GoodsDetailViewModel alloc] initWithPid:_pid];
	}
	return _goodsdetailVM;
}
#pragma -mark---
-(void)phoneCall
{
  [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:1 CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
      NSMutableString * str=[[NSMutableString alloc] initWithFormat:@"tel:%@",model.datas[0].hotphone];
      NSLog(@"%@",str);
      UIWebView * callWebview = [[UIWebView alloc] init];
      [callWebview loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:str]]];
      [self.view addSubview:callWebview];
      [callWebview removeAllSubviews];
  }];
}
@end
