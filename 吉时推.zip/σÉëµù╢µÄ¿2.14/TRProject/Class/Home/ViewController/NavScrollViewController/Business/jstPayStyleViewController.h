//
//  jstPayStyleViewController.h
//  TRProject
//
//  Created by liweidong on 17/2/6.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstPayStyleViewController : BaseNSViewController

@property(nonatomic,strong)UIButton *alpayBtn;
@property(nonatomic,strong)UIButton *wechatBtn;

@end
