//
//  jstPayStyleViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/6.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "jstPayStyleViewController.h"

@interface jstPayStyleViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;

@property(nonatomic,assign)NSInteger payStyle;

@end

@implementation jstPayStyleViewController
static NSString * reuseIdentifier = @"PayCELL";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"在线支付";
    [self setTableViews];
    [self setBottomViews];
    
}
-(void)setBottomViews
{
    UIButton * btn = [[UIButton alloc]init];
    [btn setTitle:@"确认支付 ￥ 12.00" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 228, 103);
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.bottom.equalTo(0);
        make.height.equalTo(43);
    }];
    [btn bk_addEventHandler:^(id sender) {
        NSLog(@"%ld",_payStyle);
        if (_payStyle == 1) {
            [WSProgressHUD showSuccessWithStatus:@"微信支付接口"];
        }else{
            [WSProgressHUD showSuccessWithStatus:@"支付宝接口"];
        }
        
    } forControlEvents:UIControlEventTouchUpInside];

}
-(void)setTableViews
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];

}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            UILabel * titleLab = [[UILabel alloc]init];
            [cell.contentView addSubview:titleLab];
             titleLab.font = [UIFont fontWithName:@"Zapfino" size:24];
            titleLab.text = @"jishitui";
            titleLab.textAlignment = NSTextAlignmentCenter;
            [titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.center.equalTo(0);
                make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 90));
            }];
        }
        if (indexPath.row == 1) {
            UILabel *lab = [[UILabel alloc]init];
            [cell.contentView addSubview:lab];
            [lab mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(0);
                make.left.equalTo(10);
                make.width.equalTo(SCREEN_WIDTH*.7);
            }];
            lab.text = @"骨香色排骨米饭（西三旗店）...";
            UIButton *btn = [[UIButton alloc]init];
            [btn setTitle:@"详情" forState:UIControlStateNormal];
            [btn setTitleColor:bgColor(112, 112, 112) forState:UIControlStateNormal];
            [cell.contentView addSubview:btn];
            [btn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(0);
                make.left.equalTo(lab.mas_right).equalTo(0);
                make.width.equalTo(SCREEN_WIDTH*.1);
            }];
            UILabel *labPrice = [[UILabel alloc]init];
            [cell.contentView addSubview:labPrice];
            [labPrice mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(0);
                make.left.equalTo(btn.mas_right).equalTo(0);
                make.width.equalTo(SCREEN_WIDTH*.2);
            }];
            labPrice.text = @"￥12.00";
        }
        return cell;
    }else if (indexPath.section == 1) {
                        UIImageView *ig = [[UIImageView alloc]init];
                        [cell.contentView addSubview:ig];
                        [ig mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.centerY.equalTo(0);
                            make.left.equalTo(10);
                            make.size.equalTo(CGSizeMake(40, 40));
                        }];
                        UILabel *lab = [[UILabel alloc]init];
                        [cell.contentView addSubview:lab];
                        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
                            make.centerY.equalTo(0);
                            make.left.equalTo(ig.mas_right).equalTo(10);
                            make.width.equalTo(SCREEN_WIDTH*.5);
                        }];
        
        if (indexPath.row == 0) {
            ig.image = [UIImage imageNamed:@"zfb"];
            lab.text = @"支付宝";
            
            _alpayBtn = [[UIButton alloc]init];//gallery_chs_normal
            [cell.contentView addSubview:_alpayBtn];
            [_alpayBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(0);
                make.right.equalTo(-10);
                make.size.equalTo(CGSizeMake(20, 20));
            }];
            [_alpayBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];//默认选中支付宝支付
            _payStyle = 0;
            [_alpayBtn bk_addEventHandler:^(id sender) {
                [WSProgressHUD showSuccessWithStatus:@"支付宝"];
                _payStyle = 0;
                [_alpayBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
                [_wechatBtn setImage:[UIImage imageNamed:@"my_checkbox"] forState:UIControlStateNormal];
            } forControlEvents:UIControlEventTouchUpInside];
        }else{
            ig.image = [UIImage imageNamed:@"wx"];
            lab.text = @"微信支付";
            _wechatBtn = [[UIButton alloc]init];//gallery_chs_normal
            [cell.contentView addSubview:_wechatBtn];
            [_wechatBtn mas_makeConstraints:^(MASConstraintMaker *make) {
                make.centerY.equalTo(0);
                make.right.equalTo(-10);
                make.size.equalTo(CGSizeMake(20, 20));
            }];
            [_wechatBtn setImage:[UIImage imageNamed:@"my_checkbox"] forState:UIControlStateNormal];
            [_wechatBtn bk_addEventHandler:^(id sender) {
                [WSProgressHUD showSuccessWithStatus:@"微信支付"];
                _payStyle = 1;
                [_wechatBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
                [_alpayBtn setImage:[UIImage imageNamed:@"my_checkbox"] forState:UIControlStateNormal];
            } forControlEvents:UIControlEventTouchUpInside];
        }
        return cell;
    }

       return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (indexPath.section == 0) {
        if (indexPath.row == 1) {
            [self detailView];
        }
    }
}
-(void)detailView
{
    UIView *cover = [[UIView alloc]initWithFrame:self.view.frame];
    UILabel *lab = [[UILabel alloc]init];
    lab.textColor = [UIColor whiteColor];
    [cover addSubview:lab];
    [lab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(SCREEN_HEIGHT*0.2);
        make.width.equalTo(SCREEN_WIDTH*.9);
    }];
    lab.text = @"骨香色排骨米饭（西三旗店）外卖订单";
    lab.textAlignment = NSTextAlignmentCenter;
    lab.font = [UIFont systemFontOfSize:18];
    UIView *lineView = [[UIView alloc]init];
    lineView.backgroundColor = [UIColor lightGrayColor];
    [cover addSubview:lineView];
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(lab.mas_bottom).equalTo(40);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.9, 1));
    }];
    UILabel *delLab = [[UILabel alloc]init];
    delLab.layer.masksToBounds = YES;
    delLab.layer.cornerRadius = 10;
    delLab.layer.borderColor = [UIColor whiteColor].CGColor;
    delLab.layer.borderWidth = 1;
    delLab.textColor = [UIColor whiteColor];
    delLab.backgroundColor = [UIColor blackColor];
    [cover addSubview:delLab];
    [delLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(lab.mas_bottom).equalTo(30);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
    }];
    delLab.textAlignment = NSTextAlignmentCenter;
    delLab.font = [UIFont systemFontOfSize:14];
    delLab.text = @"订单详情";
    UILabel *infoLab = [[UILabel alloc]init];
    [cover addSubview:infoLab];
    infoLab.textColor = [UIColor whiteColor];
    [infoLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(delLab.mas_bottom).equalTo(15);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.9, 20));
    }];
    infoLab.text = @"李先生 188****5644";
    UILabel *addrLab = [[UILabel alloc]init];
    addrLab.textColor = [UIColor whiteColor];
    [cover addSubview:addrLab];
    [addrLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(infoLab.mas_bottom).equalTo(5);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.9, 20));
    }];
    addrLab.text = @"龙域西路二号院龙域北街与龙域西二路交汇处 7号楼1单元1304";
    addrLab.numberOfLines = 0;
    UILabel *nameLab = [[UILabel alloc]init];
    nameLab.textColor = [UIColor whiteColor];
    [cover addSubview:nameLab];
    [nameLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(0);
        make.top.equalTo(addrLab.mas_bottom).equalTo(10);
        make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.9, 20));
    }];
    nameLab.text = @"酸菜排骨套餐x1";

    [UIView animateWithDuration:1.0f animations:^{
        cover.tag = 199999;
        cover.backgroundColor = [UIColor blackColor];
        cover.alpha = .9;
        
    } completion:^(BOOL finished) {
        [self.view addSubview:cover];
    }];
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tap:)];
    tapGR.numberOfTapsRequired=1;
    [cover addGestureRecognizer:tapGR];
}
-(void)tap:(UITapGestureRecognizer *)gr
{
    //移除模糊图片
    UIView *cover = (UIView*)[self.view viewWithTag:199999];
    [UIView animateWithDuration:1.f animations:^{
        cover.alpha = 0.f;
    } completion:^(BOOL finished) {
        [cover removeFromSuperview];
    }];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 90;
        }else{
            return 50;
        }
    }else{
        return 50;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0.001f;
    }else{
        return 40;
    }
}
//设置头部标题
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    if (section == 1) {
        UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectMake(10, 0, tableView.frame.size.width, 40)];
        titleLab.backgroundColor = bgColor(245, 245, 245);
        titleLab.textColor = bgColor(134, 134, 134);
        titleLab.text = @"选择支付方式";
        return titleLab;
    }else{
           return nil;
    }
}

@end
