//
//  jstReplyViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstReplyViewController : UIViewController
-(instancetype)initWithCid:(NSInteger )cid;
@property(nonatomic,readonly) NSInteger cid;
@end
