//
//  jstReplyViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "jstReplyViewController.h"
#import "ReplyViewModel.h"
#import "ReplyCell.h"
@interface jstReplyViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)ReplyViewModel *replyVM;
/**表视图 */
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *inputViewBottomConstraint;

@property (weak, nonatomic) IBOutlet UITextField *commentTF;


@end

@implementation jstReplyViewController
- (instancetype)initWithCid:(NSInteger)cid
{
    if (self = [super init]) {
        _cid = cid;
    }
    return self;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"评论回复";
    [self setTableView];
    _commentTF.placeholder = @"回复：";
}
-(void)setTableView
{
    self.tableView.delegate =self;
    self.tableView.dataSource = self;
    [self.tableView registerNib:[UINib nibWithNibName:@"ReplyCell" bundle:nil] forCellReuseIdentifier:@"cell"];
    
    //设定tableView分割线的颜色
    self.tableView.separatorColor = [UIColor colorWithWhite:1 alpha:0.2];
    [self loadsData];
}
-(void)loadsData
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.replyVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];
    [self.tableView addFooterRefresh:^{
        //获取VM数据
        [weakSelf.replyVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
}
#pragma mark tableViewDelegate
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.replyVM replyRowNumber];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ReplyCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil) {
        cell = [[ReplyCell alloc]initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"cell"];
    }
    cell.backgroundColor = [UIColor colorWithWhite:0 alpha:0];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [cell.userImg setImageWithURL:[self.replyVM replyIcon:indexPath.row] placeholder:[UIImage imageNamed:@"store_commodity"]];
    cell.userImg.layer.masksToBounds = YES;
    cell.userImg.layer.cornerRadius = 19;
    cell.userNickname.text = [self.replyVM replyUserNickname:indexPath.row];
//    [cell.userDesc mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.right.equalTo(0);
//        make.top.equalTo(cell.userImg.mas_bottom).equalTo(0);
//    }];
    cell.userDesc.text =  [self.replyVM replyUserDesc:indexPath.row];
    //时间戳
    NSString *timeData =  [self.replyVM replyUserTime:indexPath.row];
    NSDate *confromTimesp = [NSDate dateWithTimeIntervalSince1970:[timeData intValue]];
    NSLog(@" %@",confromTimesp);
    NSDateFormatter* dateFormat = [[NSDateFormatter alloc] init];//实例化一个NSDateFormatter对象
    //[dateFormat setDateFormat:@"yyyy-MM-dd HH:mm:ss"];//设定时间格式
    [dateFormat setDateFormat:@"MM-dd"];
    NSString *dateString = [dateFormat stringFromDate:confromTimesp]; //求出当天的时间字符串，当更改时
    cell.userTime.text = dateString;
    return cell;
}
//自动设置高度
-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 164;
}
- (ReplyViewModel *)replyVM {
    if(_replyVM == nil) {
        NSLog(@"%ld",_cid);
        _replyVM = [[ReplyViewModel alloc] initWithCid:_cid];
    }
    return _replyVM;
}

#pragma 键盘通知
- (void)viewWillAppear:(BOOL)animated
{
    //添加键盘通知监听
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(openKeyboard:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(closeKeyboard:) name:UIKeyboardWillHideNotification object:nil];
}

-(void)openKeyboard:(NSNotification *)notification
{
    //按照键盘的高度修改输入框底部的约束的constant
    NSInteger option = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGRect keyboardFrame = [notification.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    
    self.inputViewBottomConstraint.constant = keyboardFrame.size.height;
    
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        [self.view layoutIfNeeded];
        // 滚动到最后一行
        [self scrollToTableViewLastRow];
    } completion:nil];
    
}
-(void)closeKeyboard:(NSNotification *)notification
{
    //修改输入框底部的约束的constant为0
    //按照键盘的高度修改输入框底部的约束的constant
    NSInteger option = [notification.userInfo[UIKeyboardAnimationCurveUserInfoKey] integerValue];
    NSTimeInterval duration = [notification.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    
    self.inputViewBottomConstraint.constant = 0;
    
    [UIView animateWithDuration:duration delay:0 options:option animations:^{
        [self.view layoutIfNeeded];
        // 滚动到最后一行
        [self scrollToTableViewLastRow];
    } completion:nil];
}

- (void)viewWillDisappear:(BOOL)animated
{
    //取消键盘通知监听
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}
-(void)scrollToTableViewLastRow
{
    // 创建最后一行数据对应的indexpath
//    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.allMessages.count-1 inSection:0];
//    // 控制表格滚动到最后一行对应的indexpath位置
//    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [self scrollToTableViewLastRow];
}
- (IBAction)sendComment:(id)sender {
    //调用接口，刷新数据
    //http://www.zhdp.com/Reply?parentid=1&uid=1&content=sdfsdfsdfsdfs
    NSString *str = [_commentTF.text stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    [NavScrollNetworking getGoodsDetailWithCid:_cid WithUid:1 WithComment:str CompletionHandler:^(SendCommentModel *model, NSError *error) {
        NSLog(@"%ld",model.status);
        if (model.status == 1) {
            [_commentTF resignFirstResponder];
            [WSProgressHUD showSuccessWithStatus:@"发送成功"];
            _commentTF.text = @"";
            [self loadsData];
        }else {
            [WSProgressHUD showErrorWithStatus:@"发送失败"];
        }
    }];
    
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_commentTF resignFirstResponder];
}
@end
