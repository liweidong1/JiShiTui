//
//  jstCarSearchViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/15.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "jstCarSearchViewController.h"

@interface jstCarSearchViewController ()

@end

@implementation jstCarSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"搜索";
}


@end
