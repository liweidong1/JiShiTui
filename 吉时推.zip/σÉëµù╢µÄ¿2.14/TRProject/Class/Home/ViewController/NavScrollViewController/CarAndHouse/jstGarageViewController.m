//
//  jstGarageViewController.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstGarageViewController.h"
/*分区1头文件*/
#import "HomeHeaderCell.h"
#import "CarScrollView.h"
#import "CarNormalCell.h"

#import "jstCarSearchViewController.h"

@interface jstGarageViewController ()<UITableViewDelegate,UITableViewDataSource,HomeHeaderCellDelegate, HomeHeaderCellDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)UITableViewCell * scrollCell;

@end

@implementation jstGarageViewController

static NSString * reuseCarHeaderIdentifier = @"carHeaderCELL";
static NSString * reuseCarScrollIdentifier = @"carScrollCELL";
static NSString * reuseCarNormalIdentifier = @"carNormalHeaderCELL";
#pragma mark - HomeHeaderCellDelegate
- (NSInteger)numberOfItemInCell:(HomeHeaderCell *)cell {
    return 3;
}

- (NSURL *)iconURLForItemInCell:(HomeHeaderCell *)cell atIndex:(NSInteger)index {
//    return [self.homeVM indexIconURLForRow:index];
    return [NSURL URLWithString:@"http://www.zhdp.com/img/3.jpg"];
}

- (void)homeHeaderCell:(HomeHeaderCell *)cell didSelectedIconAtIndex:(NSInteger)index {
    //跳转到对应的界面
    NSLog(@"%ld",(long)index);
    [WSProgressHUD showSuccessWithStatus:@"点点"];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
        self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"车房租售";
    
    
    [self setTableView];
    
    
    
    //创建右边两个item
    [self setupRightItems];
    //通知类
    [self setNotifacations];

}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.tableView.delegate =self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle =UITableViewCellSeparatorStyleNone;
    //设定tableView分割线的颜色
    self.tableView.separatorColor = [UIColor colorWithWhite:1 alpha:0.2];
    [self.tableView registerClass:[HomeHeaderCell class] forCellReuseIdentifier:reuseCarHeaderIdentifier];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseCarScrollIdentifier];
    [self.tableView registerClass:[CarNormalCell class] forCellReuseIdentifier:reuseCarNormalIdentifier];
    [self.view addSubview:self.tableView];
    [self loadsData];
}
-(void)loadsData
{

}
-(void)setupRightItems
{
        UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(5, 0, SCREEN_WIDTH*.2, 35)];
        UIImageView *iv = [[UIImageView alloc]init];
        [rightView addSubview:iv];
        iv.image = [UIImage imageNamed:@"garage_ja"];
        iv.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(carInfo:)];
        tapGR.numberOfTapsRequired=1;
        [iv addGestureRecognizer:tapGR];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(0);
            make.top.equalTo(8);
            make.bottom.equalTo(-8);
            make.width.equalTo(SCREEN_WIDTH*.05);
        }];
        UIImageView *iv0 = [[UIImageView alloc]init];
        [rightView addSubview:iv0];
        iv0.image = [UIImage imageNamed:@"garage_search"];
        iv0.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(searchCar:)];
        tapGR1.numberOfTapsRequired=1;
        [iv0 addGestureRecognizer:tapGR1];
        [iv0 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-30);
            make.top.equalTo(10);
            make.bottom.equalTo(-10);
            make.width.equalTo(SCREEN_WIDTH*.04);
        }];
        UIBarButtonItem *rightBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:rightView];
        self.navigationItem.rightBarButtonItem = rightBarButtonItem;

}
-(void)searchCar:(UIPanGestureRecognizer*)gr
{
    jstCarSearchViewController *searchVC = [[jstCarSearchViewController alloc]init];
    [self.navigationController pushViewController:searchVC animated:YES];
    
}
-(void)carInfo:(UIPanGestureRecognizer*)gr
{
    [WSProgressHUD showSuccessWithStatus:@"进入车信息页"];
    
}
-(void)setNotifacations
{
    
}

#pragma mark-表视图
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 2) {
        return 20;
    }
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        HomeHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseCarHeaderIdentifier forIndexPath:indexPath];
        //一个section刷新
        cell.dataSource = self;
        cell.delegate = self;
        [cell reloaedData];
        return cell;
    }
    if (indexPath.section == 1) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseCarScrollIdentifier];
        CarScrollView *scrollView = [[CarScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.25)];
        [cell.contentView addSubview:scrollView];
        scrollView.navBtn.layer.masksToBounds = YES;
        scrollView.navBtn.layer.cornerRadius = 20;
        return cell;
    }
    if (indexPath.section == 2) {
        CarNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseCarNormalIdentifier];
        cell.iv.image = [UIImage imageNamed:@"header4"];
        cell.titleLb.text = @"特色房，首次出售，南北通透，带储物间飞机瓦解安慰法师打发";
        cell.descLb.text = @"3室一厅/150/m2/ 南北";
        cell.priceLb.text = @"25万元";
        cell.adressLb.text = @"昌平区西三旗家园2号楼5单元23层2301室";
        cell.line.backgroundColor = [UIColor grayColor];
        return cell;
    }
    return [UITableViewCell new];
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 0) {
        return SCREEN_WIDTH * 615 / 1125;
    }else if (indexPath.section == 1) {
        return SCREEN_HEIGHT*.25;
    }else {
        return 100;
    }
}

@end
