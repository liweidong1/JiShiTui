//
//  jstConvenientController.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "jstConvenientController.h"

@interface jstConvenientController ()

@end

@implementation jstConvenientController

- (void)viewDidLoad {
    [super viewDidLoad];
    [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
        self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"吉时便民";

}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
}

@end
