//
//  jstHonestViewController.m
//  
//
//  Created by liweidong on 16/12/14.
//
//

#import "jstHonestViewController.h"

@interface jstHonestViewController ()

@end

@implementation jstHonestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
        self.view.backgroundColor = [UIColor whiteColor];
        self.navigationItem.title = @"诚信金融";
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
}

@end
