//
//  jstPaymentViewController.h
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface jstPaymentViewController : UIViewController

@end
