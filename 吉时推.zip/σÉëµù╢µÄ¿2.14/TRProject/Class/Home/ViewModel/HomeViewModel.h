//
//  HomeViewModel.h
//  TRProject
//
//  Created by liweidong on 16/12/12.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "HomeNetworking.h"
@interface HomeViewModel : BaseViewModel
- (instancetype)initWithlngLat:(NSString *)Lat AndLng:(NSString *)Lng;
@property (nonatomic, readonly) NSString *Lat;
@property (nonatomic, readonly) NSString *Lng;


/*********  头部滚动广告栏  ***********/
@property (nonatomic) NSMutableArray<HeaderDataModel *> *bannerList;
@property (nonatomic, readonly) NSInteger indexNum;
- (NSURL *)indexIconURLForRow:(NSInteger)row;
- (NSString *)uidInAdForRow:(NSInteger)row;//跳转到对应的界面链接

/*********   天气栏目  ***********/
//直接写在了控制器中


/*********  为你优选  ***********/
//UI决定
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)iconURL:(NSInteger)row;
- (NSString *)title:(NSInteger)row;
- (NSString *)subtitle:(NSInteger)row;
- (NSString *)distance:(NSInteger)row;
- (NSString *)addr:(NSInteger)row;
//根据model
//readonly可以保证某属性只有本身.m文件能修改,非本对象无法修改
@property (nonatomic, assign) NSInteger page;
@property (nonatomic) NSMutableArray<HomeOtherDataModel *> *selectFirstList;



@end
