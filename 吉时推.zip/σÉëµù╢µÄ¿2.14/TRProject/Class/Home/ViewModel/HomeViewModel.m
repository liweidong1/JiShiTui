//
//  HomeViewModel.m
//  TRProject
//
//  Created by liweidong on 16/12/12.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "HomeViewModel.h"
#import "HomeViewController.h"
@implementation HomeViewModel
- (instancetype)initWithlngLat:(NSString *)Lat AndLng:(NSString *)Lng
{
    self = [super init];
    if (self) {
        _Lat = Lat;
        _Lng = Lng;
    }
    return self;
}

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    //总请求次数
    __block int total = 2;
    NSLog(@"%@,%@",_Lat,_Lng);
   [HomeNetworking getLat:_Lat Lng:_Lng BannerCompletionHandler:^(HomeHeaderModel *model, NSError *error) {
       total--;
       NSLog(@"%@,%@",_Lat,_Lng);
       if (!error) {
           if (requestMode == RequestModeRefresh) {
               [self.bannerList removeAllObjects];
           }
           if (total == 0) {//所有请求都完毕了
               !completionHandler ?: completionHandler(error);
           }
           self.bannerList = (NSMutableArray *)model.data;
       }

   }];
    
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
        
    }
    [HomeNetworking getLat:_Lat Lng:_Lng SelectFirst:tmpStart completionHandler:^(HomeOtherModel *model, NSError *error) {
        NSLog(@"%@,%@",_Lat,_Lng);
        total--;
        NSLog(@"%ld",tmpStart);
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.selectFirstList removeAllObjects];
            }

            _page = tmpStart;
            [self.selectFirstList addObjectsFromArray:model.data];
            NSLog(@"%ld",self.selectFirstList.count);
        }
        if (total == 0) {//所有请求都完毕了
            !completionHandler ?: completionHandler(error);
        }
    }];
}
/*********  头部滚动广告栏  ***********/
- (NSInteger)indexNum {
     NSLog(@"%ld",self.bannerList.count);
    return self.bannerList.count;
}
- (NSURL *)indexIconURLForRow:(NSInteger)row {
    return self.bannerList[row].photo.yx_URL;
}
- (NSString *)uidInAdForRow:(NSInteger)row{
    return self.bannerList[row].link_addr;
}

//********  为你优选  **********
- (NSMutableArray<HomeOtherDataModel *> *)selectFirstList {
    if(_selectFirstList == nil) {
        _selectFirstList = [[NSMutableArray<HomeOtherDataModel *> alloc] init];
    }
    return _selectFirstList;
}
- (NSInteger)rowNumber
{
    NSLog(@"%ld",self.selectFirstList.count);
    return self.selectFirstList.count;
}
- (NSURL *)iconURL:(NSInteger)row{
    return self.selectFirstList[row].img.yx_URL;
}
- (NSString *)title:(NSInteger)row{
    return self.selectFirstList[row].title;
}
- (NSString *)subtitle:(NSInteger)row
{
    return self.selectFirstList[row].descript;
}
- (NSString *)addr:(NSInteger)row
{
    return self.selectFirstList[row].addr;
}
- (NSString *)distance:(NSInteger)row
{
    return self.selectFirstList[row].juli;
}



@end


