//
//  CityViewModel.h
//  TRProject
//
//  Created by liweidong on 16/12/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "HomeNetworking.h"
@interface CityViewModel : BaseViewModel
- (instancetype)initWithCityID:(NSString *)cityID;
@property (nonatomic, readonly) NSString *cityID;


//UI决定
@property (nonatomic, readonly) NSInteger mainRowNumber;
@property (nonatomic, readonly) NSInteger subRowNumber;
- (NSString *)maintableViewText:(NSInteger)row;
- (NSString *)maintableViewID:(NSInteger)row;

- (NSString *)subtableViewText:(NSInteger)row;
- (NSString *)subtableViewCid:(NSInteger)row;
//根据model
@property (nonatomic) NSMutableArray<CurrentCityModel *> *mainList;
@property (nonatomic) NSMutableArray<CityShopModel *> *subList;

@property(nonatomic,strong)NSMutableArray<CityDataModel *> *allCityList;
@property (nonatomic, readonly) NSInteger allCityRowNumber;
- (NSString *)allCitytableViewText:(NSInteger)row;
- (NSString *)allCitytableViewID:(NSInteger)row;

@property (nonatomic) NSMutableArray *seList;





@end
