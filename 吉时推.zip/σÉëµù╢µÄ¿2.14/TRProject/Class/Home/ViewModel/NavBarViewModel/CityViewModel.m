//
//  CityViewModel.m
//  TRProject
//
//  Created by liweidong on 16/12/19.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "CityViewModel.h"

@implementation CityViewModel
- (instancetype)initWithCityID:(NSString *)cityID
{
    self = [super init];
    if (self) {
        _cityID = cityID;
    }
    return self;

}


- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSLog(@"%@",_cityID);
    [HomeNetworking getCitysWithcityID:_cityID CompletionHandler:^(CityModel *model, NSError *error) {
               NSLog(@"****%@",_cityID);
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.mainList removeAllObjects];
                [self.subList removeAllObjects];
                [self.allCityList removeAllObjects];
            }
            [self.mainList addObjectsFromArray:model.data];
            [self.subList addObjectsFromArray:model.shop];
            
            
            [self.allCityList addObjectsFromArray:model.city];
            NSLog(@"%ld",self.mainList.count);
            NSLog(@"%ld",self.subList.count);
            NSLog(@"%ld",self.allCityList.count);
            
        }
        !completionHandler ?: completionHandler(error);
    }];
}

- (NSInteger)mainRowNumber
{
    NSLog(@"%ld",self.mainList.count);
    return self.mainList.count;
}

- (NSString *)maintableViewText:(NSInteger)row
{
    NSLog(@"%@",self.mainList[row].name);
    return self.mainList[row].name;
}
- (NSString *)maintableViewID:(NSInteger)row
{
    NSLog(@"%ld",self.mainList[row].ID);
    return [NSString stringWithFormat:@"%ld",self.mainList[row].ID];
}
- (NSMutableArray<CurrentCityModel *> *)mainList {
    if(_mainList == nil) {
        _mainList = [[NSMutableArray<CurrentCityModel *> alloc] init];
    }
    return _mainList;
}
- (NSInteger)subRowNumber
{
    NSLog(@"%ld",self.subList.count);
    return self.subList.count;
}

- (NSString *)subtableViewText:(NSInteger)row
{
    NSLog(@"%@",self.subList[row].sname);
    return self.subList[row].sname;
}
- (NSMutableArray<CityShopModel *> *)subList {
    if(_subList == nil) {
        _subList = [[NSMutableArray<CityShopModel *> alloc] init];
    }
    return _subList;
}

/**
 *  除去当前城市所有城市
 *
 *  @return 李伟东
 */
- (NSInteger)allCityRowNumber
{
   NSLog(@"%ld",self.allCityList.count);
   return self.allCityList.count;
}
- (NSString *)allCitytableViewText:(NSInteger)row
{
    NSLog(@"%@",self.allCityList[row].name);
    return self.allCityList[row].name;
}
- (NSString *)allCitytableViewID:(NSInteger)row
{
    NSLog(@"%ld",self.allCityList[row].ID);
    return [NSString stringWithFormat:@"%ld",self.allCityList[row].ID];
}
- (NSMutableArray<CityDataModel *> *)allCityList {
    if(_allCityList == nil) {
        _allCityList = [[NSMutableArray<CityDataModel *> alloc] init];
    }
    return _allCityList;
}
@end
