//
//  SearchViewModel.h
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "HomeNetworking.h"
@interface SearchViewModel : BaseViewModel

- (instancetype)initWithSearchContent:(NSString *)searchContent;
@property(nonatomic,strong)NSString *searchContent;

//UI决定
@property (nonatomic, readonly) NSInteger ProductRowNumber;
- (NSURL *)ProductIcon:(NSInteger)row;
- (NSString *)ProductTitle:(NSInteger)row;
- (NSString *)ProductDesc:(NSInteger)row;
- (NSString *)ProductDiscount:(NSInteger)row;
- (NSString *)ProductSource:(NSInteger)row;
- (NSString *)ProductQuantity:(NSInteger)row;
@property (nonatomic, readonly) NSInteger ShopRowNumber;
- (NSURL *)ShopIcon:(NSInteger)row;
- (NSString *)ShopTitle:(NSInteger)row;
- (NSString *)ShopDesc:(NSInteger)row;
- (NSString *)ShopAddress:(NSInteger)row;
@property (nonatomic, readonly) NSInteger CoordRowNumber;
- (NSString *)CoordSname:(NSInteger)row;
- (NSString *)CoordScope:(NSInteger)row;
- (NSString *)CoordLat:(NSInteger)row;
- (NSString *)CoordLng:(NSInteger)row;

//根据model
@property (nonatomic) NSMutableArray<SearchProductModel *> *productList;
@property (nonatomic) NSMutableArray<SearchShopModel *> *shopList;
@property (nonatomic) NSMutableArray<SearchCoordModel *> *coordList;

@property (nonatomic, assign) NSInteger page;
@end
