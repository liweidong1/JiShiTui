//
//  SearchViewModel.m
//  TRProject
//
//  Created by liweidong on 16/12/29.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "SearchViewModel.h"

@implementation SearchViewModel

- (instancetype)initWithSearchContent:(NSString *)searchContent
{
    if (self = [super init]) {
        _searchContent = searchContent;
    }
    return self;
}

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
    }
    
    [HomeNetworking getSearchWithPage:tmpStart WithSearchContent:_searchContent CompletionHandler:^(SearchModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.productList removeAllObjects];
                [self.shopList removeAllObjects];
                [self.coordList removeAllObjects];
            }
            _page = tmpStart;
            
            [self.productList addObjectsFromArray:model.product];
            [self.shopList addObjectsFromArray:model.shop];
            [self.coordList addObjectsFromArray:model.coord];
            
            NSLog(@"%ld",self.productList.count);
            NSLog(@"%ld",self.shopList.count);
            NSLog(@"%ld",self.coordList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}
//商品
- (NSInteger)ProductRowNumber
{
    NSLog(@"%ld",self.productList.count);
   return self.productList.count;
}
-(NSURL *)ProductIcon:(NSInteger)row
{
    return self.productList[row].img.yx_URL;
}
- (NSString *)ProductTitle:(NSInteger)row
{
    return self.productList[row].title;
}
-(NSString *)ProductDesc:(NSInteger)row
{
    return self.productList[row].descript;
}
- (NSString *)ProductDiscount:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.productList[row].disprice];
}
-(NSString *)ProductSource:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.productList[row].price];
}
- (NSString *)ProductQuantity:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.productList[row].quantity];
}
//商家
- (NSInteger)ShopRowNumber
{
    return self.shopList.count;
}
-(NSURL *)ShopIcon:(NSInteger)row
{
    return self.shopList[row].img.yx_URL;
}
- (NSString *)ShopTitle:(NSInteger)row
{
    return self.shopList[row].title;
}
-(NSString *)ShopDesc:(NSInteger)row
{
    return self.shopList[row].descript;
}
- (NSString *)ShopAddress:(NSInteger)row
{
    return self.shopList[row].addr;
}
//商圈
-(NSInteger)CoordRowNumber
{
    return self.coordList.count;
}
-(NSString *)CoordSname:(NSInteger)row

{
    return self.coordList[row].sname;
}
-(NSString *)CoordScope:(NSInteger)row

{
    return [NSString stringWithFormat:@"%ld",self.coordList[row].scope];
}
-(NSString *)CoordLat:(NSInteger)row

{
    return self.coordList[row].lat;
}
-(NSString *)CoordLng:(NSInteger)row

{
    return self.coordList[row].lng;
}

- (NSMutableArray<SearchProductModel *> *)productList {
    if(_productList == nil) {
        _productList = [[NSMutableArray<SearchProductModel *> alloc] init];
    }
    return _productList;
}

- (NSMutableArray<SearchShopModel *> *)shopList {
    if(_shopList == nil) {
        _shopList = [[NSMutableArray<SearchShopModel *> alloc] init];
    }
    return _shopList;
}

- (NSMutableArray<SearchCoordModel *> *)coordList {
    if(_coordList == nil) {
        _coordList = [[NSMutableArray<SearchCoordModel *> alloc] init];
    }
    return _coordList;
}

@end
