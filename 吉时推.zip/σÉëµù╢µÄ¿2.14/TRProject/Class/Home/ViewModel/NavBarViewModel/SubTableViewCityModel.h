//
//  SubTableViewCityModel.h
//  TRProject
//
//  Created by liweidong on 16/12/27.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "HomeNetworking.h"
@interface SubTableViewCityModel : BaseViewModel
- (instancetype)initWithCityID:(NSString *)cityID;
@property (nonatomic, readonly) NSString *cityID;


//UI决定
@property (nonatomic, readonly) NSInteger subRowNumber;
- (NSString *)subtableViewText:(NSInteger)row;
- (NSString *)subtableViewlat:(NSInteger)row;
- (NSString *)subtableViewlng:(NSInteger)row;
//根据model


@property(nonatomic,strong)NSMutableArray<CoordsData *> *allCoordsList;




@end
