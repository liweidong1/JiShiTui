//
//  SubTableViewCityModel.m
//  TRProject
//
//  Created by liweidong on 16/12/27.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "SubTableViewCityModel.h"

@implementation SubTableViewCityModel
- (instancetype)initWithCityID:(NSString *)cityID
{
    self = [super init];
    if (self) {
        _cityID = cityID;
    }
    return self;
    
}
- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSLog(@"%@",_cityID);
    [HomeNetworking getAllCitysSubTableViewWithcityID:_cityID CompletionHandler:^(CoordsModel *model, NSError *error) {
        NSLog(@"****%@",_cityID);
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.allCoordsList removeAllObjects];
            }
            [self.allCoordsList addObjectsFromArray:model.data];
            NSLog(@"%ld",self.allCoordsList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}
- (NSInteger)subRowNumber
{
    NSLog(@"%ld",self.allCoordsList.count);
    return self.allCoordsList.count;
}

- (NSString *)subtableViewText:(NSInteger)row
{
    NSLog(@"%@",self.allCoordsList[row].sname);
    return self.allCoordsList[row].sname;
}
- (NSString *)subtableViewlat:(NSInteger)row
{
    return self.allCoordsList[row].lat;
}
-(NSString *)subtableViewlng:(NSInteger)row
{
    return self.allCoordsList[row].lng;
}
- (NSMutableArray<CoordsData *> *)allCoordsList {
    if(_allCoordsList == nil) {
        _allCoordsList = [[NSMutableArray<CoordsData *> alloc] init];
    }
    return _allCoordsList;
}

@end

