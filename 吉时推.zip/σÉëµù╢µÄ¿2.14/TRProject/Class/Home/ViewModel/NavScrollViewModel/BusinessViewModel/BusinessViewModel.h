//
//  BusinessViewModel.h
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "NavScrollNetworking.h"
@interface BusinessViewModel : BaseViewModel
/*********  头部滚动广告栏  ***********/
@property (nonatomic) NSMutableArray<BusinessHomeAdModel *> *adList;
@property (nonatomic, readonly) NSInteger indexNum;
- (NSURL *)indexIconURLForRow:(NSInteger)row;
- (NSString *)endTimeAdForRow:(NSInteger)row;
- (NSString *)uidInAdForRow:(NSInteger)row;//跳转到对应的界面链接


//UI决定
@property (nonatomic, readonly) NSInteger goodsRowNumber;
- (NSURL *)goodsIcon:(NSInteger)row;
- (NSString *)goodsTitle:(NSInteger)row;
- (NSString *)goodsSold:(NSInteger)row;
- (NSString *)goodsDiscount:(NSInteger)row;
- (NSString *)goodsSources:(NSInteger)row;

- (NSInteger )goodsPid:(NSInteger)row;
//根据model
@property (nonatomic) NSMutableArray<BusinessHomeCollecdtionDataModel *> *goodsList;
@property (nonatomic, assign) NSInteger page;



@end
