//
//  BusinessViewModel.m
//  TRProject
//
//  Created by liweidong on 16/12/25.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BusinessViewModel.h"

@implementation BusinessViewModel
- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
    }
    
    [NavScrollNetworking getBusinessWithPage:tmpStart completionHandler:^(BusinessHomeModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.adList removeAllObjects];
                [self.goodsList removeAllObjects];
            }
            _page = tmpStart;
            
            [self.adList addObjectsFromArray:model.ad];
            [self.goodsList addObjectsFromArray:model.data.data];
            NSLog(@"%ld",self.adList.count);
            NSLog(@"%ld",self.goodsList.count);
        }
        !completionHandler ?: completionHandler(error);
    }];
}
/*********  头部滚动广告栏  ***********/
- (NSInteger)indexNum {
    NSLog(@"%ld",self.adList.count);
    return self.adList.count;
}
- (NSURL *)indexIconURLForRow:(NSInteger)row {
    return self.adList[row].photo.yx_URL;
}
- (NSString *)endTimeAdForRow:(NSInteger)row
{
    return self.adList[row].end_time;
}
- (NSString *)uidInAdForRow:(NSInteger)row{
    return self.adList[row].link_addr;
}

//********  底部商品视图  **********
- (NSInteger)goodsRowNumber
{
    return self.goodsList.count;
}
-(NSURL *)goodsIcon:(NSInteger)row
{
    return self.goodsList[row].img.yx_URL;
}
- (NSString *)goodsTitle:(NSInteger)row
{
    return self.goodsList[row].title;
}
-(NSString *)goodsSold:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.goodsList[row].sell_number];
}
- (NSString *)goodsDiscount:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.goodsList[row].disprice];
}
- (NSString *)goodsSources:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.goodsList[row].price];
}
- (NSInteger)goodsPid:(NSInteger)row
{
    return self.goodsList[row].pid;
}



- (NSMutableArray<BusinessHomeAdModel *> *)adList {
    if(_adList == nil) {
        _adList = [[NSMutableArray<BusinessHomeAdModel *> alloc] init];
    }
    return _adList;
}

- (NSMutableArray<BusinessHomeCollecdtionDataModel *> *)goodsList {
    if(_goodsList == nil) {
        _goodsList = [[NSMutableArray<BusinessHomeCollecdtionDataModel *> alloc] init];
    }
    return _goodsList;
}


@end
