//
//  GoodsDetailViewModel.h
//  TRProject
//
//  Created by liweidong on 16/12/30.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "NavScrollNetworking.h"
@interface GoodsDetailViewModel : BaseViewModel
///**
// *  前2个分区
// */
////UI决定
//@property (nonatomic, readonly) NSInteger goodsRowNumber;
//- (NSURL *)goodsIcon:(NSInteger)row;
//
//- (NSString *)goodsThrough:(NSInteger)row;
//- (NSString *)goodsSold:(NSInteger)row;
//- (NSString *)goodsSources:(NSInteger)row;
//- (NSString *)goodsDiscount:(NSInteger)row;
//- (NSURL *)goodsTitle:(NSInteger)row;
//- (NSURL *)goodsAddress:(NSInteger)row;
//- (NSURL *)goodsDistances:(NSInteger)row;
//- (NSURL *)goodsPhone:(NSInteger)row;
////根据model
//@property (nonatomic) NSMutableArray<BusinessDetailDatasModel *> *goodsDatasList;

/**
 *  第3个分区
 */
//UI决定

- (instancetype)initWithPid:(NSInteger)pid;
@property (nonatomic, readonly) NSInteger pid;


@property (nonatomic, readonly) NSInteger goodsDetailRowNumber;
- (NSURL *)goodsDetailIcon:(NSInteger)row;
- (NSString *)goodsDetailNickname:(NSInteger)row;
- (NSString *)goodsDetailTime:(NSInteger)row;
- (NSString *)goodsDetailContent:(NSInteger)row;
- (NSString *)goodsDetailReplay:(NSInteger)row;
- (NSString *)goodsDetailComtype:(NSInteger)row;

- (NSInteger)goodsDetailCid:(NSInteger)row;

//根据model
@property (nonatomic) NSMutableArray<BusinessDetailDataModel *> *goodsAllrepList;//所有好评


@property (nonatomic, assign) NSInteger page;



@property (nonatomic, assign) NSInteger dataInteger;

@end
