//
//  GoodsDetailViewModel.m
//  TRProject
//
//  Created by liweidong on 16/12/30.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "GoodsDetailViewModel.h"

@implementation GoodsDetailViewModel
- (instancetype)initWithPid:(NSInteger)pid
{
    self = [super init];
    if (self) {
        _pid = pid;
    }
    return self;
}


- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeAllDatas:) name:@"AllCOMMENTVM" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeGoodDatas:) name:@"GOODCOMMENTVM" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(changeBedDatas:) name:@"BEDCOMMENTVM" object:nil];
    
    [NavScrollNetworking getGoodsDetailWithPid:_pid WithPage:tmpStart CompletionHandler:^(BusinessDetailModel *model, NSError *error) {
        NSLog(@"%ld",_pid);
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.goodsAllrepList removeAllObjects];
            }
            _page = tmpStart;
            //点击了好评按钮   差评  还是全部     默认好评按钮
            if (_dataInteger == 0) {
                [self.goodsAllrepList addObjectsFromArray:model.allrep.data];
            }
            if (_dataInteger == 10000) {
                [self.goodsAllrepList addObjectsFromArray:model.allrep.data];
            } else if(_dataInteger == 20000){
                [self.goodsAllrepList addObjectsFromArray:model.grep.data];
            }else if(_dataInteger == 30000){
                [self.goodsAllrepList addObjectsFromArray:model.brep.data];
            }
            NSLog(@"%ld",self.goodsAllrepList.count);
        }
        !completionHandler ?: completionHandler(error);
    }];
}
-(void)changeAllDatas:(NSNotification *)notification
{
    //接收通知改变数组的种类   差评
    _dataInteger = 10000;
}
-(void)changeGoodDatas:(NSNotification *)notification
{
    //接收通知改变数组的种类  好评按钮
    _dataInteger = 20000;
}
-(void)changeBedDatas:(NSNotification *)notification
{
    //接收通知改变数组的种类  全部
    _dataInteger = 30000;
}

//********  视图  **********
- (NSInteger)goodsDetailRowNumber
{
    NSLog(@"%ld",self.goodsAllrepList.count);
    return self.goodsAllrepList.count;
}
-(NSURL *)goodsDetailIcon:(NSInteger)row
{
    return self.goodsAllrepList[row].avatar.yx_URL;
}
- (NSString *)goodsDetailNickname:(NSInteger)row
{
     return self.goodsAllrepList[row].nickname;
}
- (NSString *)goodsDetailTime:(NSInteger)row
{
    return self.goodsAllrepList[row].comment_time;
}
- (NSString *)goodsDetailContent:(NSInteger)row
{
    return self.goodsAllrepList[row].content;
}
- (NSString *)goodsDetailReplay:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.goodsAllrepList[row].sl];
}
- (NSString *)goodsDetailComtype:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.goodsAllrepList[row].comtype];
}

- (NSInteger)goodsDetailCid:(NSInteger)row
{
    return self.goodsAllrepList[row].cid;
}


- (NSMutableArray<BusinessDetailDataModel *> *)goodsAllrepList {
    if(_goodsAllrepList == nil) {
        _goodsAllrepList = [[NSMutableArray<BusinessDetailDataModel *> alloc] init];
    }
    return _goodsAllrepList;
}


@end
