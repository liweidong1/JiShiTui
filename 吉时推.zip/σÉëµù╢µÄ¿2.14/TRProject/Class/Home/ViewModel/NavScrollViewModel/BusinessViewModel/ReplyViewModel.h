//
//  ReplyViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "NavScrollNetworking.h"
@interface ReplyViewModel : BaseViewModel
- (instancetype)initWithCid:(NSInteger)cid;
@property (nonatomic, readonly) NSInteger cid;


@property (nonatomic, readonly) NSInteger replyRowNumber;
- (NSURL *)replyIcon:(NSInteger)row;
- (NSString *)replyUserNickname:(NSInteger)row;
- (NSString *)replyUserDesc:(NSInteger)row;
- (NSString *)replyUserTime:(NSInteger)row;


//根据model
@property (nonatomic) NSMutableArray<BusinessReplyDataModel *> *replyList;//所有好评


@property (nonatomic, assign) NSInteger page;

@end
