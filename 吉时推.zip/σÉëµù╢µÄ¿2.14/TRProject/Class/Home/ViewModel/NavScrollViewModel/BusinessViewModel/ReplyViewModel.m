//
//  ReplyViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/3.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ReplyViewModel.h"

@implementation ReplyViewModel
- (instancetype)initWithCid:(NSInteger)cid
{
    self = [super init];
    if (self) {
        _cid = cid;
    }
    return self;
}


- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
    }
    [NavScrollNetworking getGoodsDetailWithCid:_cid WithPage:tmpStart CompletionHandler:^(BusinessReplyModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.replyList removeAllObjects];
            }
            _page = tmpStart;
            
            [self.replyList addObjectsFromArray:model.datas.data];
            NSLog(@"%ld",self.replyList.count);
        }
        !completionHandler ?: completionHandler(error);
    }];
}


- (NSInteger)replyRowNumber
{
    return self.replyList.count;
}
- (NSURL *)replyIcon:(NSInteger)row
{
    return self.replyList[row].avatar.yx_URL;
}
- (NSString *)replyUserNickname:(NSInteger)row
{
    return self.replyList[row].nickname;
}
- (NSString *)replyUserDesc:(NSInteger)row
{
    return self.replyList[row].content;
}
- (NSString *)replyUserTime:(NSInteger)row
{
    return self.replyList[row].comment_time;
}
- (NSMutableArray<BusinessReplyDataModel *> *)replyList {
    if(_replyList == nil) {
        _replyList = [[NSMutableArray<BusinessReplyDataModel *> alloc] init];
    }
    return _replyList;
}

@end
