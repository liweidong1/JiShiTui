//
//  JstTabBarViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "JstTabBarViewController.h"
#import "HomeViewController.h"
#import "ReadViewController.h"
#import "HealthViewController.h"
#import "ChinaCharaViewController.h"
#import "MineViewController.h"

@interface JstTabBarViewController ()
@property (nonatomic) HomeViewController *homeVC;
@property (nonatomic) ReadViewController *readVC;
@property (nonatomic) HealthViewController *healthVC;
@property (nonatomic) ChinaCharaViewController *chinaVC;
@property (nonatomic) MineViewController *mineVC;
@end

@implementation JstTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [UINavigationBar appearance].barTintColor = jRGBA(0, 177, 200, 1);
    [UINavigationBar appearance].barStyle = UIBarStyleBlack;
    [UINavigationBar appearance].tintColor = [UIColor whiteColor];
    
    UINavigationController *navi1 = [[UINavigationController alloc]initWithRootViewController:self.homeVC];
    UINavigationController *navi2 = [[UINavigationController alloc] initWithRootViewController:self.readVC];
    UINavigationController *navi3 = [[UINavigationController alloc]initWithRootViewController:self.healthVC];
    UINavigationController *navi4 = [[UINavigationController alloc]initWithRootViewController:self.chinaVC];
    UINavigationController *navi5 = [[UINavigationController alloc] initWithRootViewController:self.mineVC];
    self.viewControllers = @[navi1, navi2, navi3, navi4,navi5];

}

- (HomeViewController *)homeVC {
    if(_homeVC == nil) {
        _homeVC = [[HomeViewController alloc] init];
        _homeVC.title = @"首页";
        _homeVC.tabBarItem.image = [UIImage imageNamed:@"icon_home"];
        _homeVC.tabBarItem.selectedImage = [UIImage imageNamed:@"icon_home0"];
    }
    return _homeVC;
}
- (ReadViewController *)readVC {
    if(_readVC == nil) {
        _readVC = [[ReadViewController alloc] init];
        _readVC.title =@"全民阅读";
        _readVC.tabBarItem.image=[UIImage imageNamed:@"icon_reading"];
        _readVC.tabBarItem.selectedImage=[UIImage imageNamed:@"icon_reading0"];
    }
    return _readVC;
}
- (HealthViewController *)healthVC {
    if(_healthVC == nil) {
        _healthVC = [[HealthViewController alloc] init];
        _healthVC.title = @"吉时养生";
        _healthVC.tabBarItem.image = [UIImage imageNamed:@"icon_preserve"];
        _healthVC.tabBarItem.selectedImage = [UIImage imageNamed:@"icon_preserve0"];
        
    }
    return _healthVC;
}
- (ChinaCharaViewController *)chinaVC {
    if(_chinaVC == nil) {
        _chinaVC = [[ChinaCharaViewController alloc] init];
        _chinaVC.title = @"中国特色";
        _chinaVC.tabBarItem.image = [UIImage imageNamed:@"icon_chinarac"];
        _chinaVC.tabBarItem.selectedImage = [UIImage imageNamed:@"icon_chinarac0"];
        
    }
    return _chinaVC;
}

- (MineViewController *)mineVC {
    if(_mineVC == nil) {
        _mineVC = [[MineViewController alloc] init];
        //_mineC.tabBarItem.title = @"我的";
        _mineVC.title = @"我的";
        _mineVC.tabBarItem.image = [UIImage imageNamed:@"icon_my"];
        _mineVC.tabBarItem.selectedImage = [UIImage imageNamed:@"icon_my0"];
    }
    return _mineVC;
}



@end
