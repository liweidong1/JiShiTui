//
//  WelcomeViewController.h
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeViewController : UIViewController

@end
