//
//  WelcomeViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "WelcomeViewController.h"
#import "AppDelegate.h"
@import AVFoundation;

@interface WelcomeViewController ()<iCarouselDelegate,iCarouselDataSource,UIApplicationDelegate>
@property (nonatomic) iCarousel *ic;
@property (nonatomic) NSArray<UIImage *> *imageList;
@property (nonatomic) AVPlayerLayer *playerLayer;
@property (nonatomic) UIPageControl *pageC;
@end

@implementation WelcomeViewController

#pragma mark LazyLoad
- (NSArray<UIImage *> *)imageList{
    if (!_imageList) {
        NSArray *imageNames = @[@"welcome1", @"welcome2", @"welcome3", @"welcome4"];
        NSMutableArray *tmpArr = [NSMutableArray new];
        [imageNames enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
            [tmpArr addObject:[UIImage imageNamed:obj]];
        }];
        _imageList = tmpArr.copy;
    }
    return _imageList;
}

- (iCarousel *)ic{
    if (!_ic) {
        _ic = [[iCarousel alloc] initWithFrame:self.view.bounds];
        [self.view addSubview:_ic];
        _ic.delegate = self;
        _ic.dataSource = self;
        _ic.scrollSpeed = .1;
        _ic.bounces = NO;
    }
    return _ic;
}
- (UIPageControl *)pageC {
    if(_pageC == nil) {
        _pageC = [[UIPageControl alloc] init];
        _pageC.numberOfPages = self.imageList.count;
        _pageC.currentPageIndicatorTintColor = [UIColor whiteColor];
        _pageC.pageIndicatorTintColor = jRGBA(255, 255, 255, 0.4);
        [self.ic addSubview:_pageC];
        [_pageC mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.bottom.equalTo(-30);
        }];
    }
    return _pageC;
}

#pragma mark ic dataSource & delegate
- (NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel{
    return self.imageList.count;
}
- (UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view{
    if (!view) {
        view = [[UIImageView alloc] initWithFrame:carousel.bounds];
        view.contentMode = UIViewContentModeScaleAspectFill;
        view.clipsToBounds = YES;
    }
    ((UIImageView *)view).image = self.imageList[index];
    return view;
}

- (void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index{
    if (index == self.imageList.count - 1) {
        [UIApplication sharedApplication].statusBarHidden = NO;
        [UIView animateWithDuration:1 animations:^{
            self.view.window.alpha = 0;
            self.view.window.transform = CGAffineTransformMakeScale(1.5, 1.5);
        } completion:^(BOOL finished) {
            AppDelegate *delegate = (AppDelegate *)[UIApplication sharedApplication].delegate;
            delegate.welcomeWindow.hidden = YES;
            //释放欢迎控制器的指针索引
            delegate.welcomeWindow.rootViewController = nil;
            delegate.welcomeWindow = nil;
            //设置当前版本号为已读版本号
            NSDictionary *infoDic = [NSBundle mainBundle].infoDictionary;
            NSString *version = infoDic[@"CFBundleShortVersionString"];
            [[NSUserDefaults standardUserDefaults] setObject:version forKey:@"ReadVersion"];
            [[NSUserDefaults standardUserDefaults] synchronize];
        }];
    }
}
- (void)carouselCurrentItemIndexDidChange:(iCarousel *)carousel{
    _pageC.currentPage = carousel.currentItemIndex;
}

#pragma mark LifeCycel
- (void)viewDidLoad {
    [super viewDidLoad];
    [UIApplication sharedApplication].statusBarHidden = YES;
    UIImageView *iv = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"default"]];
    [self.view addSubview:iv];
    [iv mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(0);
    }];
    
    [self.ic reloadData];
    [self pageC];
}
- (void)dealloc{
    //切记: 监听者必须在添加的对应生命周期中删除
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}
@end
