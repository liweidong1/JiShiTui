//
//  ShopStyleModel.h
//  TRProject
//
//  Created by liweidong on 17/1/21.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ShopStyleTypeModel;
@interface ShopStyleModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<ShopStyleTypeModel *> *type;

@end
@interface ShopStyleTypeModel : NSObject

@property (nonatomic, assign) NSInteger id;

@property (nonatomic, copy) NSString *name;

@end

