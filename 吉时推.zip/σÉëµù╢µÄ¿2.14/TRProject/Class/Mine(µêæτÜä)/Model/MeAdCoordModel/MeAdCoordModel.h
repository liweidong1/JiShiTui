//
//  PickerModel.h
//  TRProject
//
//  Created by liweidong on 17/1/21.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeAdCoordCitysModel,MeAdCoordCoordModel,MeAdCoordShopModel;
@interface MeAdCoordModel : NSObject

@property (nonatomic, strong) NSArray<MeAdCoordCitysModel *> *citys;

@end
@interface MeAdCoordCitysModel : NSObject

@property (nonatomic, copy) NSString *name;
//id -->  ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, strong) NSArray<MeAdCoordCoordModel *> *coord;

@end

@interface MeAdCoordCoordModel : NSObject

@property (nonatomic, assign) NSInteger cid;

@property (nonatomic, copy) NSString *sname;

@property (nonatomic, strong) NSArray<MeAdCoordShopModel *> *shop;

@end
@interface MeAdCoordShopModel : NSObject

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) NSInteger sid ;

@property (nonatomic, strong) NSString *title;

@end
