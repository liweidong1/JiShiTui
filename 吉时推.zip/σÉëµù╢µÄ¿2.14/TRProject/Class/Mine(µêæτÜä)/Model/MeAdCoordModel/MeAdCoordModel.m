//
//  PickerModel.m
//  TRProject
//
//  Created by liweidong on 17/1/21.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeAdCoordModel.h"

@implementation MeAdCoordModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"citys" : [MeAdCoordCitysModel class]};
}

@end
@implementation MeAdCoordCitysModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"coord" : [MeAdCoordCoordModel class]};
}
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}
@end


@implementation MeAdCoordCoordModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"shop" : [MeAdCoordShopModel class]};
}
@end
@implementation MeAdCoordShopModel

@end

