//
//  MeInfoModel.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeInfoAllCityModel,MeInfoProvinceModel,MeInfoModelCityModel,MeInfoModelAreaModel;
@interface MeInfoModel : NSObject

@property (nonatomic, strong) MeInfoAllCityModel *city;

@end
@interface MeInfoAllCityModel : NSObject

@property (nonatomic, strong) NSArray<MeInfoProvinceModel *> *province;

@property (nonatomic, strong) NSArray<MeInfoModelCityModel *> *city;

@property (nonatomic, strong) NSArray<MeInfoModelAreaModel *> *area;

@end

@interface MeInfoProvinceModel : NSObject
// id --> ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger parent_id;

@end

@interface MeInfoModelCityModel : NSObject

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger parent_id;

@end

@interface MeInfoModelAreaModel : NSObject

@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, assign) NSInteger parent_id;

@end

