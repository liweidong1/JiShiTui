
//
//  MeInfoModel.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeInfoModel.h"

@implementation MeInfoModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"city" : [MeInfoAllCityModel class]};
}
@end
@implementation MeInfoAllCityModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"province" : [MeInfoProvinceModel class],
             @"city" : [MeInfoModelCityModel class],
             @"area" : [MeInfoModelAreaModel class]};
}

@end


@implementation MeInfoProvinceModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}

@end


@implementation MeInfoModelCityModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}
@end


@implementation MeInfoModelAreaModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}
@end


