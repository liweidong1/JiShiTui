//
//  MeProductBundingModel.h
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeProductBundingDatasModel,MeProductBundingDataModel;
@interface MeProductBundingModel : NSObject

@property (nonatomic, strong) MeProductBundingDatasModel *datas;

@property (nonatomic, assign) NSInteger status;

@end
@interface MeProductBundingDatasModel : NSObject

@property (nonatomic, assign) NSInteger per_page;

@property (nonatomic, assign) NSInteger from;

@property (nonatomic, assign) NSInteger to;

@property (nonatomic, strong) NSArray<MeProductBundingDataModel *> *data;

@property (nonatomic, copy) NSString *next_page_url;

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, assign) NSInteger current_page;

@property (nonatomic, assign) NSInteger last_page;

@property (nonatomic, copy) NSString *prev_page_url;

@end

@interface MeProductBundingDataModel : NSObject

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, copy) NSString *juli;

@property (nonatomic, assign) NSInteger bd;

@end

