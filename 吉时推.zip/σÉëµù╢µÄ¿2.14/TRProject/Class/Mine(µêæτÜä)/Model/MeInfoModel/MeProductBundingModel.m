//
//  MeProductBundingModel.m
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeProductBundingModel.h"

@implementation MeProductBundingModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"datas" : [MeProductBundingDatasModel class]};
}
@end
@implementation MeProductBundingDatasModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"data" : [MeProductBundingDataModel class]};
}

@end


@implementation MeProductBundingDataModel

@end


