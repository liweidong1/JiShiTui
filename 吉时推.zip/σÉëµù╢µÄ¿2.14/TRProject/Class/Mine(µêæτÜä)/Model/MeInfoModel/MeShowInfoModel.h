//
//  MeShowInfoModel.h
//  TRProject
//
//  Created by liweidong on 17/1/20.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeShowInfoDetailsModel;
@interface MeShowInfoModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) MeShowInfoDetailsModel *details;

@end
@interface MeShowInfoDetailsModel : NSObject

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *phone;

@property (nonatomic, copy) NSString *city;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, copy) NSString *area;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *addr;

@property (nonatomic, copy) NSString *email;

@property (nonatomic, copy) NSString *sex;

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *province;

@end

