//
//  MeShowInfoModel.m
//  TRProject
//
//  Created by liweidong on 17/1/20.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeShowInfoModel.h"

@implementation MeShowInfoModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"details" : [MeShowInfoDetailsModel class]};
}
@end
@implementation MeShowInfoDetailsModel

@end


