//
//  PickerModel.h
//  TRProject
//
//  Created by liweidong on 17/1/21.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PickerModel : NSObject
@property (nonatomic, copy) NSString *province;
@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *area;

@end
