//
//  MeOrderModel.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeOrderUnpayModel,MeOrderProductModel,MeOrderPayModel;
@interface MeOrderModel : NSObject

@property (nonatomic, strong) NSArray<MeOrderUnpayModel *> *unpay;

@property (nonatomic, strong) NSArray<MeOrderPayModel *> *pay;

@end
@interface MeOrderUnpayModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray<MeOrderProductModel *> *product;

@property (nonatomic, assign) NSInteger oid;

@end



@interface MeOrderPayModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, strong) NSArray<MeOrderProductModel *> *product;

@property (nonatomic, assign) NSInteger oid;

@end

@interface MeOrderProductModel : NSObject

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, assign) NSInteger count;

@end

