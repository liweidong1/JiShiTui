//
//  MeOrderModel.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeOrderModel.h"

@implementation MeOrderModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"unpay" : [MeOrderUnpayModel class],
             @"pay" : [MeOrderPayModel class]};
}
@end
@implementation MeOrderUnpayModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [MeOrderProductModel class]};
}

@end



@implementation MeOrderPayModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [MeOrderProductModel class]};
}
@end


@implementation MeOrderProductModel

@end


