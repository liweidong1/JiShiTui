//
//  MePayAttentionProductModel.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MePayAttentionProductBindModel,MePayAttentionProductGzModel;
@interface MePayAttentionProductModel : NSObject

@property (nonatomic, strong) MePayAttentionProductBindModel *bind;

@property (nonatomic, strong) NSArray<MePayAttentionProductGzModel *> *gz;

@property (nonatomic, assign) NSInteger status;

@end
@interface MePayAttentionProductBindModel : NSObject

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@end

@interface MePayAttentionProductGzModel : NSObject

@property (nonatomic, assign) NSInteger sid;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, copy) NSString *img;

@end

