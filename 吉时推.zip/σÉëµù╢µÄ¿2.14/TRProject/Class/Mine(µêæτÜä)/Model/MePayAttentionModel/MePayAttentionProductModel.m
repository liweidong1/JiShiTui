//
//  MePayAttentionProductModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MePayAttentionProductModel.h"

@implementation MePayAttentionProductModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"bind" : [MePayAttentionProductBindModel class],
             @"gz" : [MePayAttentionProductGzModel class]};
}

@end
@implementation MePayAttentionProductBindModel

@end


@implementation MePayAttentionProductGzModel

@end


