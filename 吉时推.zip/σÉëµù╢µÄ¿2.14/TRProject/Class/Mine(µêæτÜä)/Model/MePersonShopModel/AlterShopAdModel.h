//
//  AlterShopAdModel.h
//  TRProject
//
//  Created by liweidong on 17/2/9.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class AlterShopAdAdModel;
@interface AlterShopAdModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<AlterShopAdAdModel *> *ad;

@end

@interface AlterShopAdAdModel : NSObject
//id   ID
@property (nonatomic, assign) NSInteger ID;

@property (nonatomic, copy) NSString *pic;

@property (nonatomic, copy) NSString *info;

@end

