//
//  AlterShopAdModel.m
//  TRProject
//
//  Created by liweidong on 17/2/9.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "AlterShopAdModel.h"
@implementation AlterShopAdModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
     return @{@"ad" : [AlterShopAdAdModel class]};
}
@end

@implementation AlterShopAdAdModel
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper{
    return @{@"id": @"ID" };
}
@end


