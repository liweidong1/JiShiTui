//
//  FansOrderProductModel.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FansOrderProductUsertModel,FansOrderProductOrderModel,FansOrderProductProductModel;
@interface FansOrderProductModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<FansOrderProductOrderModel *> *order;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) CGFloat total;
@property (nonatomic, strong) FansOrderProductUsertModel *user;

@end

@interface FansOrderProductUsertModel : NSObject

@property (nonatomic, copy) NSString *avatar;

@property (nonatomic, copy) NSString *nickname;

@end

@interface FansOrderProductOrderModel : NSObject

@property (nonatomic, assign) NSInteger total;

@property (nonatomic, strong) NSArray<FansOrderProductProductModel *> *product;

@property (nonatomic, assign) NSInteger oid;

@property (nonatomic, copy) NSString *pay_time;

@property (nonatomic, copy) NSString *order_number;

@end

@interface FansOrderProductProductModel : NSObject

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger count;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, copy) NSString *img;

@end

