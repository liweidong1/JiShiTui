//
//  FansOrderProductModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansOrderProductModel.h"

@implementation FansOrderProductModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"order" : [FansOrderProductOrderModel class],
             @"user" : [FansOrderProductUsertModel class]};
}

@end
@implementation FansOrderProductOrderModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [FansOrderProductProductModel class]};
}
@end


@implementation FansOrderProductProductModel

@end

@implementation FansOrderProductUsertModel

@end


