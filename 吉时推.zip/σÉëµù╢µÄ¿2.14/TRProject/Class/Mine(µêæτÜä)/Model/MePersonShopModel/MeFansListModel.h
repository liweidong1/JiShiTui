//
//  MeFansListModel.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MeFansListUserModel;
@interface MeFansListModel : NSObject

@property (nonatomic, assign) NSInteger status;

@property (nonatomic, strong) NSArray<MeFansListUserModel *> *user;

@end
@interface MeFansListUserModel : NSObject

@property (nonatomic, copy) NSString *phone;

@property (nonatomic, copy) NSString *nickname;

@property (nonatomic, assign) NSInteger uid;

@property (nonatomic, copy) NSString *avatar;

@end

