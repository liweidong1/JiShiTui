//
//  MeFansListModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeFansListModel.h"

@implementation MeFansListModel


+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"user" : [MeFansListUserModel class]};
}
@end
@implementation MeFansListUserModel

@end


