//
//  ProductReviseModel.h
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ProductReviseProductModel;
@interface ProductReviseDetailModel : NSObject

@property (nonatomic, strong) ProductReviseProductModel *product;

@property (nonatomic, assign) NSInteger status;

@end
@interface ProductReviseProductModel : NSObject

@property (nonatomic, strong) NSArray<NSString *> *images;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *info;

@property (nonatomic, assign) NSInteger disprice;

@property (nonatomic, assign) NSInteger price;

@property (nonatomic, copy) NSString *title;

@property (nonatomic, assign) NSInteger quantity;

@property (nonatomic, copy) NSString *descript;

@property (nonatomic, assign) NSInteger pid;

@end

