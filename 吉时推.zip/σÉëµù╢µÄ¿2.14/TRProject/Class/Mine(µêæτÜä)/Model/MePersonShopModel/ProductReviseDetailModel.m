//
//  ProductReviseModel.m
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ProductReviseDetailModel.h"

@implementation ProductReviseDetailModel
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
    return @{@"product" : [ProductReviseProductModel class]};
}
@end
@implementation ProductReviseProductModel

@end


