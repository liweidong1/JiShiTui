//
//  ProductReviseListModel.h
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <Foundation/Foundation.h>

@class ProductReviseListProductModel;
@interface ProductReviseListModel : NSObject

@property (nonatomic, strong) NSArray<ProductReviseListProductModel *> *product;

@property (nonatomic, assign) NSInteger status;

@end
@interface ProductReviseListProductModel : NSObject

@property (nonatomic, assign) NSInteger pid;

@property (nonatomic, copy) NSString *img;

@property (nonatomic, copy) NSString *title;

@end

