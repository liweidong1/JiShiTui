//
//  ProductReviseListModel.m
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ProductReviseListModel.h"

@implementation ProductReviseListModel

+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass{
     return @{@"product" : [ProductReviseListProductModel class]};
}

@end
@implementation ProductReviseListProductModel

@end


