//
//  MeNetWorking.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseNetworking.h"
#import "MeShowInfoModel.h"
#import "MeInfoModel.h"//修改个人信息服务器接口
#import "MeProductBundingModel.h"

#import "ShopStyleModel.h"

#import "MePayAttentionProductModel.h"

#import "ProductReviseListModel.h"
#import "ProductReviseDetailModel.h"
#import "MeFansListModel.h"
#import "FansOrderProductModel.h"

#import "MeOrderModel.h"

#import "AlterShopAdModel.h"

#import "MeAdCoordModel.h"

#import "testModel.h"

@interface MeNetWorking : BaseNetworking

/**
 *  个人信息查询服务器显示数据 http://www.zhdp.com/Users?uid=1
 */
+ (id)getPersonInfoWithUid:(NSInteger)uid CompletionHandler:(void(^)(MeShowInfoModel *model, NSError *error))completionHandler;

/**
 *  个人信息修改的选择城市接口
 */
+ (id)getPersonInfoChooseCityCompletionHandler:(void(^)(MeInfoModel *model, NSError *error))completionHandler;
/**
 *  个人信息提交修改
 */
+ (id)getPersonInfoUpDateWithParameters:(NSDictionary *)parm Data:(NSData *)imgData ParmsKey:(NSString *)parmsKey  CompletionHandler:(void(^)(testModel *model, NSError *error))completionHandler;
/**
 *  个人信息修改的绑定商家接口
 */
+ (id)getPersonInfoBundingWithLat:(NSString *)Lat Lng:(NSString *)Lng Page:(NSInteger)page CompletionHandler:(void(^)(MeProductBundingModel *model, NSError *error))completionHandler;
/**
 *  我要开店  类型选择接口
 */
+ (id)getShopStyleCompletionHandler:(void(^)(ShopStyleModel *model, NSError *error))completionHandler;
/**
 *  个人订单
 */
+ (id)getMeOrderWithUid:(NSInteger)uid CompletionHandler:(void(^)(MeOrderModel *model, NSError *error))completionHandler;
/**
 *  我关注的店铺
 */

+ (id)getPayAttentionProductWithUid:(NSInteger)uid CompletionHandler:(void(^)(MePayAttentionProductModel *model, NSError *error))completionHandler;
/**
 *  g广告推广 1所属商圈
 */

+ (id)getAdCoordCompletionHandler:(void(^)(MeAdCoordModel *model, NSError *error))completionHandler;

//************  * 我的店铺相关/
/**
 *  商品修改   1列表  2详情    1粉丝列表   2粉丝详情(注:fansid:要看的粉丝的用户id   uid:登陆者的uid)
 */

+ (id)getProductReviseListWithUid:(NSInteger)uid CompletionHandler:(void(^)(ProductReviseListModel *model, NSError *error))completionHandler;
+ (id)getProductReviseDetailWithPid:(NSInteger)pid CompletionHandler:(void(^)(ProductReviseDetailModel *model, NSError *error))completionHandler;
+ (id)getFansListWithUid:(NSInteger)uid CompletionHandler:(void(^)(MeFansListModel *model, NSError *error))completionHandler;

+ (id)getFansOrderDetailWithFansId:(NSInteger)fansId Uid:(NSInteger)uid CompletionHandler:(void(^)(FansOrderProductModel *model, NSError *error))completionHandler;
/**
 *  店铺管理   1.店铺轮播图
 */
+ (id)AlterShopAdWithUid:(NSInteger)uid CompletionHandler:(void(^)(AlterShopAdModel *model, NSError *error))completionHandler;
@end
