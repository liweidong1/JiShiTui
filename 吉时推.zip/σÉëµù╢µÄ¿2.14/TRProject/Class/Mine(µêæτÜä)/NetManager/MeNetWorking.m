//
//  MeNetWorking.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeNetWorking.h"

@implementation MeNetWorking


+ (id)getPersonInfoWithUid:(NSInteger)uid CompletionHandler:(void (^)(MeShowInfoModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMepersonShowInfoPath,uid];
    
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeShowInfoModel parse:repsonseObj], error);
    }];
}
+ (id)getPersonInfoChooseCityCompletionHandler:(void (^)(MeInfoModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMepersonInfoChooseCityPath];
    
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeInfoModel parse:repsonseObj], error);
    }];
}
+ (id)getPersonInfoBundingWithLat:(NSString *)Lat Lng:(NSString *)Lng Page:(NSInteger)page CompletionHandler:(void (^)(MeProductBundingModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMepersonInfoProductBundingPath,Lat,Lng,page];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeProductBundingModel parse:repsonseObj], error);
    }];
}
+(id)getShopStyleCompletionHandler:(void (^)(ShopStyleModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMepersonInfoShopStylePath];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ShopStyleModel parse:repsonseObj], error);
    }];
}
+ (id)getPersonInfoUpDateWithParameters:(NSDictionary *)parm Data:(NSData *)imgData ParmsKey:(NSString *)parmsKey CompletionHandler:(void (^)(testModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMepersonInfoPath];
    return [self POSTFile:urlPath parameters:parm Data:imgData ParmsKey:parmsKey completionHandler:^(id repsonseObj, NSError *error) {
         !completionHandler ?: completionHandler([testModel parse:repsonseObj], error);
    }];
}

+ (id)getMeOrderWithUid:(NSInteger)uid CompletionHandler:(void (^)(MeOrderModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeOrderPath,uid];
    
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeOrderModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];

}

+ (id)getPayAttentionProductWithUid:(NSInteger)uid CompletionHandler:(void (^)(MePayAttentionProductModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMePayAttentionProductPath,uid];
    
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MePayAttentionProductModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
+(id)getAdCoordCompletionHandler:(void (^)(MeAdCoordModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeAdCoordPath];
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeAdCoordModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];

}
+ (id)getProductReviseListWithUid:(NSInteger)uid CompletionHandler:(void (^)(ProductReviseListModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeProductReviseListPath,uid];
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ProductReviseListModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
+ (id)getProductReviseDetailWithPid:(NSInteger)pid CompletionHandler:(void (^)(ProductReviseDetailModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeProductReviseDetailPath,pid];
    NSLog(@"%@",urlPath);
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([ProductReviseDetailModel parse:repsonseObj], error);
        NSLog(@"---%@",repsonseObj);
    }];
}
+ (id)getFansListWithUid:(NSInteger)uid CompletionHandler:(void (^)(MeFansListModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeFansListPath,uid];
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([MeFansListModel parse:repsonseObj], error);
    }];
}
+ (id)getFansOrderDetailWithFansId:(NSInteger)fansId Uid:(NSInteger)uid CompletionHandler:(void (^)(FansOrderProductModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstMeFansOrderProductPath,fansId,uid];
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([FansOrderProductModel parse:repsonseObj], error);
    }];
}
+ (id)AlterShopAdWithUid:(NSInteger)uid CompletionHandler:(void (^)(AlterShopAdModel *, NSError *))completionHandler
{
    NSString * urlPath = [NSString stringWithFormat:jstAlterShopAdPath,uid];
    return [self GET:urlPath parameters:nil completionHandler:^(id repsonseObj, NSError *error) {
        !completionHandler ?: completionHandler([AlterShopAdModel parse:repsonseObj], error);
    }];

}
@end
