//
//  ApplyShopCell.h
//  TRProject
//
//  Created by liweidong on 17/1/11.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
//------------------普通cell
@interface ApplyShopNormalCell : UITableViewCell
/* 3个参数 */
@property(nonatomic,strong)UILabel * ShopNameLab;
@property(nonatomic,strong)UITextField * ShopNameTF;
@property(nonatomic,strong)UIImageView *rightIv;
@property (nonatomic, strong) void(^styleChooseHandler)();
@end

//------------------代理cell
@interface ApplyShopActCell : UITableViewCell
@property(nonatomic,strong)UILabel *actLab;
@property(nonatomic,strong)UITextField *actTF;
@property(nonatomic,strong)UIImageView *rightIv;
@property(nonatomic,strong)UILabel *actrightInfoLab;

@property (nonatomic, strong) void(^actChooseHandler)();

@end

//------------------上传身份证照片cell
@interface ApplyShopPhotoCell : UITableViewCell
@property(nonatomic,strong)UILabel * userNameLab;
@property(nonatomic,strong)UILabel * userNameGrayLab;
@property(nonatomic,strong)UIButton * photoBtn;
@property(nonatomic,strong)UILabel * promptLab;
@property(nonatomic,strong)UIImageView *ptoto1;
@property(nonatomic,strong)UIImageView *ptoto2;

@property (nonatomic, strong) void(^photoHandler)();

@end

//------------------收款方式cell
@interface ApplyShopCollectMoneyCell : UITableViewCell
@property(nonatomic,strong)UILabel *collectLab;
@property(nonatomic,strong)UIButton *noBtn;
@property(nonatomic,strong)UILabel *noLab;
@property(nonatomic,strong)UIButton *wexinBtn;
@property(nonatomic,strong)UILabel *weixinLab;
@property(nonatomic,strong)UIButton *alipayBtn;
@property(nonatomic,strong)UILabel *alipayLab;

@property (nonatomic, strong) void(^noChooseHandler)();
@property (nonatomic, strong) void(^weixinChooseHandler)();
@property (nonatomic, strong) void(^alipayChooseHandler)();

@end
//------------------协议cell
@interface ApplyShopAgreeCell : UITableViewCell
@property(nonatomic,strong)UIButton *chooseBtn;
@property(nonatomic,strong)UILabel *readLab;
@property(nonatomic,strong)UIButton *readEnterBtn;

@end
