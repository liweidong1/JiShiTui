//
//  ApplyShopCell.m
//  TRProject
//
//  Created by liweidong on 17/1/11.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ApplyShopCell.h"
//
@implementation ApplyShopNormalCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) ShopNameLab {
    if(_ShopNameLab == nil) {
        _ShopNameLab = [[UILabel alloc] init];
        _ShopNameLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_ShopNameLab];
        [_ShopNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.height.equalTo(20);
        }];
    }
    return _ShopNameLab;
}

- (UITextField *) ShopNameTF {
    if(_ShopNameTF == nil) {
        _ShopNameTF = [[UITextField alloc] init];
        [self.contentView addSubview:_ShopNameTF];
        _ShopNameTF.font = [UIFont systemFontOfSize:11];
        [_ShopNameTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ShopNameLab.mas_right).equalTo(4);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.8-60, 20));

        }];
    }
    return _ShopNameTF;
}

- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        _rightIv.hidden = YES;
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-29);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(7, 10));
        }];

        _rightIv.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chooseStyle:)];
        tapGR.numberOfTapsRequired=1;
        [_rightIv addGestureRecognizer:tapGR];

    }
    return _rightIv;
}

-(void)chooseStyle:(UIPanGestureRecognizer*)gr
{
    !self.styleChooseHandler ?: self.styleChooseHandler();
}

@end

@implementation ApplyShopActCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)actLab {
    if(_actLab == nil) {
        _actLab = [[UILabel alloc] init];
        _actLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_actLab];
        [_actLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];

    }
    return _actLab;
}
- (UITextField *)actTF {
    if(_actTF == nil) {
        _actTF = [[UITextField alloc] init];
        [self.contentView addSubview:_actTF];
        _actTF.font = [UIFont systemFontOfSize:11];
        [_actTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.actLab.mas_right).equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.8-60, 20));
            
        }];

    }
    return _actTF;
}
- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        _rightIv.userInteractionEnabled = YES;
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-29);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(7, 10));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chooseAct:)];
        tapGR.numberOfTapsRequired=1;
        [_rightIv addGestureRecognizer:tapGR];

    }
    return _rightIv;
}

- (UILabel *)actrightInfoLab {
    if(_actrightInfoLab == nil) {
        _actrightInfoLab = [[UILabel alloc] init];
        _actrightInfoLab.font = [UIFont systemFontOfSize:14];
        _actrightInfoLab.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_actrightInfoLab];
        [_actrightInfoLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-10);
            make.top.equalTo(self.rightIv.mas_bottom).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.4, 20));
        }];

    }
    return _actrightInfoLab;
}


-(void)chooseAct:(UIPanGestureRecognizer*)gr
{
    !self.actChooseHandler ?: self.actChooseHandler();
}

@end

@implementation ApplyShopPhotoCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) userNameLab {
    if(_userNameLab == nil) {
        _userNameLab = [[UILabel alloc] init];
        _userNameLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_userNameLab];
        [_userNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.25, 20));
        }];

    }
    return _userNameLab;
}
- (UILabel *) userNameGrayLab {
    if(_userNameGrayLab == nil) {
        _userNameGrayLab = [[UILabel alloc] init];
        _userNameGrayLab.font = [UIFont systemFontOfSize:12];
        _userNameGrayLab.textColor = [UIColor grayColor];
        [self.contentView addSubview:_userNameGrayLab];
        [_userNameGrayLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.userNameLab.mas_right).equalTo(3);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];

    }
    return _userNameGrayLab;
}
- (UIButton *) photoBtn {
    if(_photoBtn == nil) {
        _photoBtn = [[UIButton alloc] init];
        _photoBtn.layer.borderWidth = .5f;
        _photoBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_photoBtn bk_addEventHandler:^(id sender) {
         !self.photoHandler ?: self.photoHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_photoBtn];
        [_photoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(self.userNameLab.mas_bottom).equalTo(20);
            make.size.equalTo(CGSizeMake(50, 50));
            
        }];

    }
    return _photoBtn;
}

- (UILabel *) promptLab {
    if(_promptLab == nil) {
        _promptLab = [[UILabel alloc] init];
        _promptLab.font = [UIFont systemFontOfSize:12];
        _promptLab.textColor = [UIColor grayColor];
        [self.contentView addSubview:_promptLab];
        [_promptLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.photoBtn.mas_right).equalTo(3);
            make.top.equalTo(self.userNameGrayLab.mas_bottom).equalTo(35);
            make.size.equalTo(CGSizeMake(60, 20));
        }];

    }
    return _promptLab;
}

- (UIImageView *)ptoto1 {
    if(_ptoto1 == nil) {
        _ptoto1 = [[UIImageView alloc] init];
        _ptoto1.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto1];
        [_ptoto1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.promptLab.mas_right).equalTo(10);
            make.top.equalTo(self.userNameLab.mas_bottom).equalTo(20);
            make.size.equalTo(CGSizeMake(50, 50));
            
        }];
    }
    return _ptoto1;
}

- (UIImageView *)ptoto2 {
    if(_ptoto2 == nil) {
        _ptoto2 = [[UIImageView alloc] init];
        _ptoto2.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto2];
        [_ptoto2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ptoto1.mas_right).equalTo(10);
            make.top.equalTo(self.userNameLab.mas_bottom).equalTo(20);
            make.size.equalTo(CGSizeMake(50, 50));
            
        }];
    }
    return _ptoto2;
}
@end
@implementation ApplyShopCollectMoneyCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)collectLab {
    if(_collectLab == nil) {
        _collectLab = [[UILabel alloc] init];
        _collectLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_collectLab];
        [_collectLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _collectLab;
}
- (UIButton *)noBtn {
    if(_noBtn == nil) {
        _noBtn = [[UIButton alloc] init];
        [_noBtn bk_addEventHandler:^(id sender) {
            !self.noChooseHandler ?: self.noChooseHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_noBtn];
        [_noBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.collectLab.mas_right).equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];

    }
    return _noBtn;
}

- (UILabel *)noLab {
    if(_noLab == nil) {
        _noLab = [[UILabel alloc] init];
        _noLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_noLab];
        [_noLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.noBtn.mas_right).equalTo(5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, 20));
        }];

    }
    return _noLab;
}

- (UIButton *)wexinBtn {
    if(_wexinBtn == nil) {
        _wexinBtn = [[UIButton alloc] init];
        [_wexinBtn bk_addEventHandler:^(id sender) {
            !self.weixinChooseHandler ?: self.weixinChooseHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_wexinBtn];
        [_wexinBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.noLab.mas_right).equalTo(SCREEN_WIDTH*.05);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];
    }
    return _wexinBtn;
}

- (UILabel *)weixinLab {
    if(_weixinLab == nil) {
        _weixinLab = [[UILabel alloc] init];
        _weixinLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_weixinLab];
        [_weixinLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.wexinBtn.mas_right).equalTo(5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, 20));
        }];
    }
    return _weixinLab;
}

- (UIButton *)alipayBtn {
    if(_alipayBtn == nil) {
        _alipayBtn = [[UIButton alloc] init];
        [_alipayBtn bk_addEventHandler:^(id sender) {
            !self.alipayChooseHandler ?: self.alipayChooseHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_alipayBtn];
        [_alipayBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.weixinLab.mas_right).equalTo(SCREEN_WIDTH*.05);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];
    }
    return _alipayBtn;
}

- (UILabel *)alipayLab {
    if(_alipayLab == nil) {
        _alipayLab = [[UILabel alloc] init];
        _alipayLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_alipayLab];
        [_alipayLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.alipayBtn.mas_right).equalTo(5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.15, 20));
        }];
    }
    return _alipayLab;
}

@end

@implementation ApplyShopAgreeCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIButton *)chooseBtn {
    if(_chooseBtn == nil) {
        _chooseBtn = [[UIButton alloc] init];
        [_chooseBtn bk_addEventHandler:^(id sender) {
            
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_chooseBtn];
        [_chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];

    }
    return _chooseBtn;
}

- (UILabel *)readLab {
    if(_readLab == nil) {
        _readLab = [[UILabel alloc] init];
        _readLab.font = [UIFont systemFontOfSize:12];
        _readLab.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_readLab];
        [_readLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.chooseBtn.mas_right).equalTo(5);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(60, 20));
        }];

    }
    return _readLab;
}

- (UIButton *)readEnterBtn {
    if(_readEnterBtn == nil) {
        _readEnterBtn = [[UIButton alloc] init];
        _readEnterBtn.font = [UIFont systemFontOfSize:12];
        [_readEnterBtn setTitleColor:bgColor(119, 205, 218) forState:UIControlStateNormal];
        [self.contentView addSubview:_readEnterBtn];
        [_readEnterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.readLab.mas_right).equalTo(2);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.30, 20));
        }];
    }
    return _readEnterBtn;
}
@end
