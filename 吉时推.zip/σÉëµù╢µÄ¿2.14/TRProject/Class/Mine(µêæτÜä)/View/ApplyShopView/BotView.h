//
//  BotView.h
//  TRProject
//
//  Created by liweidong on 17/1/11.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BotView : UIView
/* 开通   取消 */

@property(nonatomic,strong)UIButton * applyBtn;
@property(nonatomic,strong)UIButton * ccelBtn;



@property (nonatomic, strong) void(^applyHandler)();
@property (nonatomic, strong) void(^ccelHandler)();

@end
