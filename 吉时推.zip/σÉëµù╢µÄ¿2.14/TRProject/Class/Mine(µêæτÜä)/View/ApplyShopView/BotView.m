//
//  BotView.m
//  TRProject
//
//  Created by liweidong on 17/1/11.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BotView.h"

@implementation BotView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self applyBtn];
        [self ccelBtn];
    }
    return self;
}
- (UIButton *)applyBtn {
    if(_applyBtn == nil) {
        _applyBtn = [[UIButton alloc] init];
        _applyBtn.backgroundColor = bgColor(0, 177, 200);
        _applyBtn.layer.masksToBounds = YES;
        [_applyBtn bk_addEventHandler:^(id sender) {
            !self.applyHandler ?: self.applyHandler();
        } forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:_applyBtn];
        [_applyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.height.equalTo(40);
        }];

    }
    return _applyBtn;
}

- (UIButton *)ccelBtn {
    if(_ccelBtn == nil) {
        _ccelBtn = [[UIButton alloc] init];
        _ccelBtn.backgroundColor = bgColor(144, 144, 144);
        [_ccelBtn bk_addEventHandler:^(id sender) {
            !self.ccelHandler ?: self.ccelHandler();
        } forControlEvents:UIControlEventTouchUpInside];

        [self addSubview:_ccelBtn];
        [_ccelBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.right.equalTo(0);
            make.height.equalTo(40);
        }];

    }
    return _ccelBtn;
}

@end
