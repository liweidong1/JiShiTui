//
//  MeAdCell.h
//  TRProject
//
//  Created by liweidong on 17/2/12.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeAdCell : UITableViewCell
@property(nonatomic,strong)UILabel *adNameLab;
@property(nonatomic,strong)UILabel *adPlLab;
@property(nonatomic,strong)UILabel *endTimeLab;
@property(nonatomic,strong)UIButton *endBtn;
@property(nonatomic,strong)UILabel *startTimeLab;
@property(nonatomic,strong)UIButton *startBtn;

@property(nonatomic,strong)UILabel *endCeshiLab;
@property(nonatomic,strong)UILabel *startCeshiLab;
@property (nonatomic, strong) void(^setStartHandler)();
@property (nonatomic, strong) void(^setEndHandler)();


@end
