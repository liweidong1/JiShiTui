//
//  MeAdCell.m
//  TRProject
//
//  Created by liweidong on 17/2/12.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeAdCell.h"

@implementation MeAdCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}

- (UILabel *)adNameLab {
    if(_adNameLab == nil) {
        _adNameLab = [[UILabel alloc] init];
        _adNameLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_adNameLab];
        [_adNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
            
        }];
    }
    return _adNameLab;
}

- (UILabel *)adPlLab {
    if(_adPlLab == nil) {
        _adPlLab = [[UILabel alloc] init];
        _adPlLab.font = [UIFont systemFontOfSize:11];
        _adPlLab.textColor = [UIColor grayColor];
        [self.contentView addSubview:_adPlLab];
        [_adPlLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.adNameLab.mas_right).equalTo(0);
        }];
    }
    return _adPlLab;
}

- (UILabel *)endTimeLab {
    if(_endTimeLab == nil) {
        _endTimeLab = [[UILabel alloc] init];
        _endTimeLab.font = [UIFont systemFontOfSize:9];
        _endTimeLab.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_endTimeLab];
        [_endTimeLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.15);
            make.right.equalTo(0);
        }];
//        _endTimeLab.userInteractionEnabled = YES;
//        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setEnd:)];
//        tapGR.numberOfTapsRequired=1;
//        [self.endTimeLab addGestureRecognizer:tapGR];
    }
    return _endTimeLab;
}
- (UILabel *)endCeshiLab {
    if(_endCeshiLab == nil) {
        _endCeshiLab = [[UILabel alloc] init];
        _endCeshiLab.font = [UIFont systemFontOfSize:9];
        [self.contentView addSubview:_endCeshiLab];
        [_endCeshiLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.top.bottom.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.15);
        }];
        _endCeshiLab.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setEnd:)];
        tapGR.numberOfTapsRequired=1;
        [self.endCeshiLab addGestureRecognizer:tapGR];
    }
    return _endCeshiLab;
}
-(void)setEnd:(UIPanGestureRecognizer*)gr
{
    !self.setEndHandler ?: self.setEndHandler();
}
- (UIButton *)endBtn {
    if(_endBtn == nil) {
        _endBtn = [[UIButton alloc] init];
        _endBtn.font = [UIFont systemFontOfSize:12];
        [_endBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_endBtn setTitle:@"结束于" forState:UIControlStateNormal];
        [self.contentView addSubview:_endBtn];
        [_endBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.right.equalTo(self.endTimeLab.mas_left).equalTo(0);
        }];
    }
    return _endBtn;
}

- (UILabel *)startTimeLab {
    if(_startTimeLab == nil) {
        _startTimeLab = [[UILabel alloc] init];
        _startTimeLab.font = [UIFont systemFontOfSize:9];
        _startTimeLab.textColor = [UIColor lightGrayColor];
        [self.contentView addSubview:_startTimeLab];
        [_startTimeLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.15);
            make.right.equalTo(self.endBtn.mas_left).equalTo(0);
        }];
//        _startTimeLab.userInteractionEnabled = YES;
//        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setStart:)];
//        tapGR.numberOfTapsRequired=1;
//        [self.startTimeLab addGestureRecognizer:tapGR];

    }
    return _startTimeLab;
}
- (UILabel *)startCeshiLab {
    if(_startCeshiLab == nil) {
        _startCeshiLab = [[UILabel alloc] init];
        _startCeshiLab.font = [UIFont systemFontOfSize:9];
        [self.contentView addSubview:_startCeshiLab];
        [_startCeshiLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.equalTo(0);
            make.right.equalTo(self.endBtn.mas_left).equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.15);
        }];
        _startCeshiLab.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(setStart:)];
        tapGR.numberOfTapsRequired=1;
        [self.startCeshiLab addGestureRecognizer:tapGR];

    }
    return _startCeshiLab;
}
-(void)setStart:(UIPanGestureRecognizer*)gr
{
    !self.setStartHandler ?: self.setStartHandler();
}
- (UIButton *)startBtn {
    if(_startBtn == nil) {
        _startBtn = [[UIButton alloc] init];
        _startBtn.font = [UIFont systemFontOfSize:12];
        [_startBtn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_startBtn setTitle:@"开始于" forState:UIControlStateNormal];
        [self.contentView addSubview:_startBtn];
        [_startBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.right.equalTo(self.startTimeLab.mas_left).equalTo(0);
        }];
    }
    return _startBtn;
}

@end
