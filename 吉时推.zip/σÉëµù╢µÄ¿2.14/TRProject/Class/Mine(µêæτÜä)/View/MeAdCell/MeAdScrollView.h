//
//  NavScrollView.h
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeAdScrollView : UIView
@property(nonatomic,strong)UIPageControl * pc;
@property(nonatomic,assign)NSInteger page;



@property(nonatomic,strong)UILabel *shopLab1;
@property(nonatomic,strong)UILabel *fansLab1;

@property(nonatomic,strong)UILabel *shopLab2;
@property(nonatomic,strong)UILabel *fansLab2;

@property(nonatomic,strong)UILabel *shopLab3;
@property(nonatomic,strong)UILabel *fansLab3;

@property(nonatomic,strong)UILabel *shopLab4;
@property(nonatomic,strong)UILabel *fansLab4;

@property(nonatomic,strong)UILabel *shopLab5;
@property(nonatomic,strong)UILabel *fansLab5;

@property(nonatomic,strong)UILabel *shopLab6;
@property(nonatomic,strong)UILabel *fansLab6;

@property(nonatomic,strong)UILabel *shopLab7;
@property(nonatomic,strong)UILabel *fansLab7;

@property(nonatomic,strong)UILabel *shopLab8;
@property(nonatomic,strong)UILabel *fansLab8;
@end
