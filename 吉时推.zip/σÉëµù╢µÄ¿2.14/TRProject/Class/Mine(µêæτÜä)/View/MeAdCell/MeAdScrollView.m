//
//  NavScrollView.m
//  TRProject
//
//  Created by liweidong on 16/12/14.
//  Copyright © 2016年 yingxin. All rights reserved.
//

#import "MeAdScrollView.h"
@interface MeAdScrollView ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView * sv;
@end
@implementation MeAdScrollView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //1滚动视图
        UIScrollView * sv =[[UIScrollView alloc]init];
        self.sv=sv;
        sv.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
        [self addSubview:sv];
        //姿势图
        for (int i = 0; i<1 ; i++) {
            UIView *view1 = [[UIView alloc]init];
            view1.frame = CGRectMake(i*sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height);
            view1.backgroundColor = [UIColor whiteColor];
            [sv addSubview:view1];
            sv.bounces =NO;
            sv.showsHorizontalScrollIndicator = YES;
            sv.scrollEnabled = YES;
            sv.pagingEnabled = YES;
            
            sv.contentSize = CGSizeMake(1*sv.bounds.size.width, sv.bounds.size.height);
            
            [self addSubview:sv];
            if(i==0){
                //添加第1个视图的8个按钮
                [self addFirstView:view1];
            }

        }
        
    }
    return self;
}
/**************************************************************navView页面1Start**********************/
-(void)addFirstView:(UIView *)view1{
    //循环8个盒子 u847   u851
    for (int i=0; i<8; i++) {
        UIView *boxView = [[UIView alloc]initWithFrame:CGRectMake(i*SCREEN_WIDTH/4+3, 10, SCREEN_WIDTH/4 -3, 30)];
        boxView.layer.borderWidth = 1;
        boxView.layer.borderColor = [UIColor grayColor].CGColor;
        boxView.backgroundColor = bgColor(249, 249, 249);
        UILabel *shopLb = [[UILabel alloc]init];
        shopLb.font = [UIFont systemFontOfSize:13];
        [boxView addSubview:shopLb];
        [shopLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(2);
            make.size.equalTo(CGSizeMake((SCREEN_WIDTH/4)*.4, 30));
        }];
        UILabel *fansLab = [[UILabel alloc]init];
        fansLab.font = [UIFont systemFontOfSize:9];
        fansLab.textColor = bgColor(81, 171, 184);
        [boxView addSubview:fansLab];
        [fansLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(shopLb.mas_right).equalTo(0);
            make.size.equalTo(CGSizeMake((SCREEN_WIDTH/4)*.6, 30));
        }];
        if (i>=4) {
            boxView.frame = CGRectMake((i-4)*SCREEN_WIDTH/4+3, 60, SCREEN_WIDTH/4-3, 30);
        }
        if (i == 0) {
            _shopLab1 = shopLb;
            _fansLab1 = fansLab;
        } else if(i == 1) {
            _shopLab2 = shopLb;
            _fansLab2 = fansLab;
        }else if(i == 2) {
            _shopLab3 = shopLb;
            _fansLab3 = fansLab;
        }else if(i == 3) {
            _shopLab4 = shopLb;
            _fansLab4 = fansLab;
        }else if(i == 4) {
            _shopLab5 = shopLb;
            _fansLab5 = fansLab;
        }else if(i == 5) {
            _shopLab6 = shopLb;
            _fansLab6 = fansLab;
        }else if(i == 6) {
            _shopLab7 = shopLb;
            _fansLab7 = fansLab;
        }else if(i == 7) {
            _shopLab8 = shopLb;
            _fansLab8 = fansLab;
        }

        [view1 addSubview:boxView];
    }
}
@end
