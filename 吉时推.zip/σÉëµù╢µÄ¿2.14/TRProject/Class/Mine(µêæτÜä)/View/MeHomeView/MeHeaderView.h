//
//  MeHeaderView.h
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeHeaderView : UIView
@property(nonatomic,strong)UIView *maskView;
@property(nonatomic,strong)UIButton *setBtn;
@property(nonatomic,strong)UIButton *applyShopBtn;//我要开店
@property(nonatomic,strong)UIButton *bundingCardBtn;//绑定银行卡 默认隐藏
@property(nonatomic,strong)UIImageView *userIV;
@property(nonatomic,strong)UILabel *userLab;


@property(nonatomic,strong)UIView *botView;

@property(nonatomic,strong)UIView *leftView;
@property(nonatomic,strong)UIView *rightView;
@property(nonatomic,strong)UIButton *enterShopBtn;//进店逛逛透明按钮
@property(nonatomic,strong)UIButton *moneyBtn;//余额透明按钮
@property(nonatomic,strong)UILabel *lab;//余额
@property(nonatomic,strong)UIImageView *iv;//图
@property(nonatomic,strong)UILabel *moneyLab;//余额值

@property (nonatomic, strong) void(^setHandler)();

@property (nonatomic, strong) void(^setUserImgHandler)();
@property (nonatomic, strong) void(^setEnterIssueHandler)();

@end
