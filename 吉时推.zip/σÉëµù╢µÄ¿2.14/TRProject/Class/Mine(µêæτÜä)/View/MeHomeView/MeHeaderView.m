//
//  MeHeaderView.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeHeaderView.h"

@implementation MeHeaderView
//重写init方法
- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        [self maskView];
        [self setBtn];
        [self applyShopBtn];
        [self bundingCardBtn];
        [self userIV];
        [self userLab];
        [self leftView];
        [self rightView];
    }
    
    return self;
}
- (UIView *)maskView {
    if(_maskView == nil) {
        _maskView = [[UIView alloc] init];
        [self addSubview:_maskView];
        _maskView.backgroundColor = bgColor(0, 177, 200);
        [_maskView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.top.right.equalTo(0);
            make.height.equalTo(CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT*.4));
        }];
    }
    return _maskView;
}
- (UIButton *)setBtn {
    if(_setBtn == nil) {
        _setBtn = [[UIButton alloc] init];
        [self.maskView addSubview:_setBtn];
        [_setBtn setImage:[UIImage imageNamed:@"my_intercalate"] forState:UIControlStateNormal];
        [_setBtn bk_addEventHandler:^(id sender) {
           !self.setHandler ?: self.setHandler();
        } forControlEvents:UIControlEventTouchUpInside];

        [_setBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.top.equalTo(17);
            make.size.equalTo(CGSizeMake(25, 25));
        }];

    }
    return _setBtn;
}
- (UIButton *)applyShopBtn {
    if(_applyShopBtn == nil) {
    _applyShopBtn = [[UIButton alloc] init];
    [_applyShopBtn setTitle:@"我要开店" forState:UIControlStateNormal];
    [self.maskView addSubview:_applyShopBtn];
    [_applyShopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(-15);
        make.top.equalTo(17);
        make.size.equalTo(CGSizeMake(100, 25));
    }];
    }
    return _applyShopBtn;
}
- (UIButton *)bundingCardBtn {
    if(_bundingCardBtn == nil) {
        _bundingCardBtn = [[UIButton alloc] init];
        [_bundingCardBtn setTitle:@"绑定银行卡" forState:UIControlStateNormal];
        _bundingCardBtn.hidden = YES;
        [self.maskView addSubview:_bundingCardBtn];
        [_bundingCardBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-15);
            make.top.equalTo(17);
            make.size.equalTo(CGSizeMake(100, 25));
        }];
    }
    return _bundingCardBtn;
}
- (UIImageView *)userIV {
    if(_userIV == nil) {
        _userIV = [[UIImageView alloc] init];
        _userIV.layer.cornerRadius = 40;
        _userIV.layer.masksToBounds = YES;
        _userIV.layer.borderColor = [bgColor(138, 218, 229) CGColor];
        _userIV.layer.borderWidth = 5.0f;
        [self.maskView addSubview:_userIV];
        _userIV.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(userImg:)];
        tapGR.numberOfTapsRequired=1;
        [_userIV addGestureRecognizer:tapGR];
        [_userIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.1);
            make.size.equalTo(CGSizeMake(80, 80));
        }];
    }
    return _userIV;
}

- (UILabel *)userLab {
    if(_userLab == nil) {
        _userLab = [[UILabel alloc] init];
        [self.maskView addSubview:_userLab];
        _userLab.textColor = [UIColor whiteColor];
        _userLab.textAlignment = NSTextAlignmentCenter;
        [_userLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.userIV.mas_bottom).equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 20));
        }];
    }
    return _userLab;
}

- (UIView *)leftView {
    if(_leftView == nil) {
        _leftView = [[UIView alloc] init];
        [self.maskView addSubview:_leftView];
        _leftView.layer.borderColor = [bgColor(108, 203, 218) CGColor];
        _leftView.layer.borderWidth = .5f;
        [_leftView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.bottom.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, 55));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(leftView:)];
        tapGR.numberOfTapsRequired=1;
        [_leftView addGestureRecognizer:tapGR];
        //我的发布   图
        UILabel *lab = [[UILabel alloc]init];
        lab.textAlignment = NSTextAlignmentCenter;
        lab.text = @"我的发布";
        [_leftView addSubview:lab];
        lab.textColor = [UIColor whiteColor];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 20));
        }];
        
        
        UIImageView * iv = [[UIImageView alloc]init];
        iv.image = [UIImage imageNamed:@"my_fb"];
        [self.leftView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(lab.mas_bottom).equalTo(5);
            make.size.equalTo(CGSizeMake(15, 15));
        }];

    }
    return _leftView;
}

- (UIView *)rightView {
    if(_rightView == nil) {
        _rightView = [[UIView alloc] init];
        [self.maskView addSubview:_rightView];
        _rightView.layer.borderColor = [bgColor(108, 203, 218) CGColor];
        _rightView.layer.borderWidth = .5f;
        [_rightView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, 55));
        }];
        //进店逛逛按钮    余额按钮
        _enterShopBtn = [[UIButton alloc] init];
        _enterShopBtn.backgroundColor = [UIColor clearColor];
        [_rightView addSubview:_enterShopBtn];
        [_enterShopBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.right.top.bottom.equalTo(0);
        }];
        
        _moneyBtn = [[UIButton alloc] init];
        _moneyBtn.backgroundColor = [UIColor clearColor];
        _moneyBtn.hidden = YES;
        [_rightView addSubview:_moneyBtn];
        [_moneyBtn mas_makeConstraints:^(MASConstraintMaker *make) {
           make.left.right.top.bottom.equalTo(0);
        }];
        
        //进店逛逛   图
        UILabel *lab = [[UILabel alloc]init];
        _lab = lab;
        lab.textAlignment = NSTextAlignmentCenter;
        lab.text = @"进店逛逛";
         [_rightView addSubview:lab];
        lab.textColor = [UIColor whiteColor];
        [lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH/2, 20));
        }];
        UIImageView * iv = [[UIImageView alloc]init];
        _iv = iv;
        iv.image = [UIImage imageNamed:@"my_stroll"];
        [self.rightView addSubview:iv];
        [iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(lab.mas_bottom).equalTo(5);
            make.size.equalTo(CGSizeMake(25, 15));
        }];
        UILabel *moneyLab = [[UILabel alloc]init];
        _moneyLab = moneyLab;
        moneyLab.textAlignment = NSTextAlignmentCenter;
        moneyLab.hidden = YES;
        moneyLab.text = @"0.00";
        [_rightView addSubview:moneyLab];
        moneyLab.textColor = [UIColor whiteColor];
        [moneyLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(lab.mas_bottom).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH/2, 20));
        }];
    }
    return _rightView;
}

/**
 *  点击事件
 */
-(void)leftView:(UIPanGestureRecognizer*)gr
{
    !self.setEnterIssueHandler ?: self.setEnterIssueHandler();
}

-(void)userImg:(UIPanGestureRecognizer*)gr
{
    !self.setUserImgHandler ?: self.setUserImgHandler();
}

@end
