//
//  MeNormalCell.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeNormalCell.h"

@implementation MeNormalCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)icon {
    if(_icon == nil) {
        _icon = [[UIImageView alloc] init];
        [self.contentView addSubview:_icon];
        [_icon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(15);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(15, 20));
        }];
    }
    return _icon;
}

- (UILabel *)lab {
    if(_lab == nil) {
        _lab = [[UILabel alloc] init];
        _lab.textColor = bgColor(67, 187, 208);
        _lab.font = [UIFont systemFontOfSize:16.0f];
        [self.contentView addSubview:_lab];
        [_lab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.icon.mas_right).equalTo(16);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*0.6, 20));
        }];
    }
    return _lab;
}

- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-29);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(7, 10));
        }];
    }
    return _rightIv;
}

@end
