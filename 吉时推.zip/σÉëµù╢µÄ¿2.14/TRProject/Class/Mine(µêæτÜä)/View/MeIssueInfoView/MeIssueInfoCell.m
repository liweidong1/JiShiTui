//
//  MeIssueInfoCell.m
//  TRProject
//
//  Created by liweidong on 17/2/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeIssueInfoCell.h"

@implementation MeIssueInfoCell

- (void)setUI
{
    _delete.layer.borderWidth = 1;
    _delete.layer.borderColor = bgColor(0, 177, 201).CGColor;
}

@end
