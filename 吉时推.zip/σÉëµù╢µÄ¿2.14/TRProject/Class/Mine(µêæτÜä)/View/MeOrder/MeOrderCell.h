//
//  MeOrderCell.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MeOrderModel.h"
@interface MeOrderCell : UITableViewCell
@property (nonatomic) UIImageView *iconIV;

@property (nonatomic) UILabel *titleLab;//标题

@property (nonatomic) UILabel *descLab;//描述

@property (nonatomic) UILabel *priceLab;//价格

@property (nonatomic) UILabel *countLab;//数量

@property (nonatomic, strong) MeOrderProductModel *model;

+ (instancetype)cellWIthTableView:(UITableView *)tableView;



@end
