//
//  MeOrderCell.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeOrderCell.h"

@implementation MeOrderCell

+ (instancetype)cellWIthTableView:(UITableView *)tableView
{
    //cell复用，唯一标识
    static NSString *identifier = @"MeOrderCell";
    //先在缓存池中取
    MeOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    //缓存池中没有再创建，并添加标识，cell移出屏幕时放入缓存池以复用
    if (cell == nil) {
        cell = [[MeOrderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    return cell;
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        self.backgroundColor = bgColor(241, 241, 241);
        
    }
    return self;
}
- (UIImageView *)iconIV {
    if(_iconIV == nil) {
        _iconIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_iconIV];
        _iconIV.image = [UIImage imageNamed:@"odetials_fruit2"];
        //_iconIV.contentMode = UIViewContentModeScaleAspectFill;
        [_iconIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
            make.size.equalTo(CGSizeMake(60, 60));
        }];
        
    }
    return _iconIV;
}
- (UILabel *)titleLab {
    if(_titleLab == nil) {
        _titleLab = [[UILabel alloc] init];
        _titleLab.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_titleLab];
        [_titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iconIV.mas_top).equalTo(0);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.width.equalTo(SCREEN_WIDTH*.7);
            make.height.equalTo(20);
        }];
    }
    return _titleLab;
}
- (UILabel *)descLab {
    if(_descLab == nil) {
        _descLab = [[UILabel alloc] init];
        _descLab.font = [UIFont systemFontOfSize:12];
        [self.contentView addSubview:_descLab];
        [_descLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLab.mas_bottom).equalTo(5);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.width.equalTo(SCREEN_WIDTH*.7);
            make.height.equalTo(20);
        }];
    }
    return _descLab;
}
- (UILabel *)priceLab {
    if(_priceLab == nil) {
        _priceLab = [[UILabel alloc] init];
        _priceLab.font = [UIFont systemFontOfSize:12];
        _priceLab.textColor = bgColor(0, 177, 200);
        [self.contentView addSubview:_priceLab];
        [_priceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.iconIV.mas_bottom).equalTo(0);
            make.left.equalTo(self.iconIV.mas_right).equalTo(10);
            make.width.equalTo(SCREEN_WIDTH*.15);
            make.height.equalTo(15);
        }];
    }
    return _priceLab;
}
- (UILabel *)countLab {
    if(_countLab == nil) {
        _countLab = [[UILabel alloc] init];
        _countLab.font = [UIFont systemFontOfSize:12];
        _countLab.textColor = bgColor(0, 177, 200);
        [self.contentView addSubview:_countLab];
        [_countLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.iconIV.mas_bottom).equalTo(0);
            make.left.equalTo(self.priceLab.mas_right).equalTo(0);
            make.width.equalTo(SCREEN_WIDTH*.7);
            make.height.equalTo(15);
        }];

    }
    return _countLab;
}
- (void)setModel:(MeOrderProductModel *)model
{
    _model = model;
    self.titleLab.text = model.title;
    if (model.disprice == nil) {//原价和打折价需进行判断
         self.priceLab.text = [NSString stringWithFormat:@"%ld.00",model.price];
    }else {
         self.priceLab.text = [NSString stringWithFormat:@"%ld.00",model.disprice];
    }
    self.descLab.text = model.descript;
    self.countLab.text = [NSString stringWithFormat:@"x%ld",model.count];
    [self.iconIV setImageWithURL:model.img.yx_URL placeholder:[UIImage imageNamed:@"store_commodity"]];

}
@end
