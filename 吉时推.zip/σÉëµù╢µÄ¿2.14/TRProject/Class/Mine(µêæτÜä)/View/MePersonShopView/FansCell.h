//
//  FansCell.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  粉丝列表
 */
@interface FansCell : UITableViewCell
@property(nonatomic,strong)UIImageView *userImg;
@property(nonatomic,strong)UILabel *titleLb;
@property(nonatomic,strong)UIImageView *phoneImg;
@property(nonatomic,strong)UILabel *phoneLb;
@property(nonatomic,strong)UIImageView *timeImg;
@property(nonatomic,strong)UILabel *timeLb;
@property(nonatomic,strong)UIView *horiLine;
@property(nonatomic,strong)UILabel *reviewLb;
@property(nonatomic,strong)UIImageView *rightIv;
@property(nonatomic,strong)UIView *botClearView;

//此属性表示cell拥有一个向外部通知按钮被点击的能力.
@property (nonatomic, copy) void(^reViewFansClicked)(FansCell *cell);

@end
