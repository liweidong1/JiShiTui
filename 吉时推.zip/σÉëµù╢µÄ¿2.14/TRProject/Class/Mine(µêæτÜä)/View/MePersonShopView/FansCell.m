//
//  FansCell.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansCell.h"

@implementation FansCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}

- (UIImageView *)userImg {
    if(_userImg == nil) {
        _userImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_userImg];
        [_userImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(55, 55));
        }];
    }
    return _userImg;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(20);
            make.left.equalTo(self.userImg.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
    }
    return _titleLb;
}
- (UIImageView *)phoneImg {
    if(_phoneImg == nil) {
        _phoneImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_phoneImg];
        [_phoneImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.userImg.mas_right).equalTo(15);
            make.bottom.equalTo(self.userImg.mas_bottom).equalTo(-5);
            make.size.equalTo(CGSizeMake(5, 10));
        }];
    }
    return _phoneImg;
}

- (UILabel *)phoneLb {
    if(_phoneLb == nil) {
        _phoneLb = [[UILabel alloc] init];
        _phoneLb.font = [UIFont systemFontOfSize:12];
        _phoneLb.textColor = bgColor(19, 185, 206);
        [self.contentView addSubview:_phoneLb];
        [_phoneLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.userImg.mas_bottom).equalTo(0);
            make.left.equalTo(self.phoneImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];

    }
    return _phoneLb;
}
//- (UIImageView *)timeImg {
//    if(_timeImg == nil) {
//        _timeImg = [[UIImageView alloc] init];
//        [self.contentView addSubview:_timeImg];
//        [_timeImg mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.phoneLb.mas_bottom).equalTo(5);
//            make.left.equalTo(self.userImg.mas_right).equalTo(15);
//            make.size.equalTo(CGSizeMake(10, 10));
//        }];
//        
//    }
//    return _timeImg;
//}
//- (UILabel *)timeLb {
//    if(_timeLb == nil) {
//        _timeLb = [[UILabel alloc] init];
//        [self.contentView addSubview:_timeLb];
//        _timeLb.font = [UIFont systemFontOfSize:12];
//        [_timeLb mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.phoneLb.mas_bottom).equalTo(0);
//            make.left.equalTo(self.timeImg.mas_right).equalTo(5);
//            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
//        }];
//
//    }
//    return _timeLb;
//}


- (UIView *)horiLine {
    if(_horiLine == nil) {
        _horiLine = [[UIView alloc] init];
        [self.contentView addSubview:_horiLine];
        [_horiLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.userImg.mas_bottom).equalTo(10);
            make.left.right.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 1));
        }];
    }
    return _horiLine;
}
- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-10);
            make.bottom.equalTo(-15);
            make.size.equalTo(CGSizeMake(7, 10));
        }];

    }
    return _rightIv;
}
- (UILabel *)reviewLb {
    if(_reviewLb == nil) {
        _reviewLb = [[UILabel alloc] init];
        [self.contentView addSubview:_reviewLb];
        _reviewLb.font = [UIFont systemFontOfSize:14];
        _reviewLb.textAlignment = NSTextAlignmentCenter;
        [_reviewLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.rightIv.mas_left).equalTo(-10);
            make.bottom.equalTo(-10);
            make.size.equalTo(CGSizeMake(40, 20));
        }];

    }
    return _reviewLb;
}



- (UIView *)botClearView {
    if(_botClearView == nil) {
        _botClearView = [[UIView alloc] init];
        [self.contentView addSubview:_botClearView];
        [_botClearView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.right.left.equalTo(0);
            make.height.equalTo(40);
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(reViewTap:)];
        tapGR.numberOfTapsRequired=1;
        [self.botClearView addGestureRecognizer:tapGR];
    }
    return _botClearView;
}
-(void)reViewTap:(UIPanGestureRecognizer*)gr
{
    NSLog(@"查看");
        !_reViewFansClicked ?: _reViewFansClicked(self);
}
@end
