//
//  FansDetailHeaderView.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *  粉丝详情页  ---->头部视图
 */
@interface FansDetailHeaderView : UIView
@property(nonatomic,strong)UIView *blueView;
@property(nonatomic,strong)UIImageView *userImg;
@property(nonatomic,strong)UILabel *userLab;

@property(nonatomic,strong)UIImageView *leftImg;
@property(nonatomic,strong)UILabel *consumeCountLab;
@property(nonatomic,strong)UILabel *consumeNoteLab;


@property(nonatomic,strong)UIView *erectLine;

@property(nonatomic,strong)UIImageView *rightImg;
@property(nonatomic,strong)UILabel *totalCountLab;
@property(nonatomic,strong)UILabel *totalLab;

@end
