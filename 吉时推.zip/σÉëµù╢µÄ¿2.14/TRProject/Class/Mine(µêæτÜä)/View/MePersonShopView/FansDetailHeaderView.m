//
//  FansDetailHeaderView.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansDetailHeaderView.h"

@implementation FansDetailHeaderView

- (instancetype)initWithFrame:(CGRect)frame

{
    if (self = [super initWithFrame:frame]) {
        [self blueView];
        [self userImg];
        [self userLab];
        [self leftImg];
        [self consumeCountLab];
        [self consumeNoteLab];
        [self erectLine];
        [self rightImg];
        [self totalCountLab];
        [self totalLab];
    }
    return self;
}
- (UIView *)blueView {
    if(_blueView == nil) {
        _blueView = [[UIView alloc] init];
        _blueView.backgroundColor = bgColor(0, 176, 200);
        [self addSubview:_blueView];
        [_blueView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.right.equalTo(0);
            make.height.equalTo(SCREEN_HEIGHT*.2);
        }];
    }
    return _blueView;
}

- (UIImageView *)userImg {
    if(_userImg == nil) {
        _userImg = [[UIImageView alloc] init];
        _userImg.layer.masksToBounds = YES;
        _userImg.layer.cornerRadius = SCREEN_HEIGHT*.1/2;
        [self.blueView addSubview:_userImg];
        [_userImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.02);
            make.size.equalTo(CGSizeMake(SCREEN_HEIGHT*.1, SCREEN_HEIGHT*.1));
        }];
    }
    return _userImg;
}

- (UILabel *)userLab {
    if(_userLab == nil) {
        _userLab = [[UILabel alloc] init];
        _userLab.textAlignment = NSTextAlignmentCenter;
        _userLab.textColor = [UIColor whiteColor];
        [self.blueView addSubview:_userLab];
        [_userLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.userImg.mas_bottom).equalTo(SCREEN_HEIGHT*.02);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT*.02));
        }];
    }
    return _userLab;
}

- (UIImageView *)leftImg {
    if(_leftImg == nil) {
        _leftImg = [[UIImageView alloc] init];
        [self addSubview:_leftImg];
        [_leftImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(SCREEN_WIDTH*.07);
            make.top.equalTo(self.blueView.mas_bottom).equalTo(SCREEN_HEIGHT*.025);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.08, SCREEN_HEIGHT*.05));
        }];
    }
    return _leftImg;
}

- (UILabel *)consumeCountLab {
    if(_consumeCountLab == nil) {
        _consumeCountLab = [[UILabel alloc] init];
        [self addSubview:_consumeCountLab];
        [_consumeCountLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.blueView.mas_bottom).equalTo(SCREEN_HEIGHT*.02);
            make.left.equalTo(self.leftImg.mas_right).equalTo(2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.02));
        }];
    }
    return _consumeCountLab;
}

- (UILabel *)consumeNoteLab {
    if(_consumeNoteLab == nil) {
        _consumeNoteLab = [[UILabel alloc] init];
        _consumeNoteLab.textColor = [UIColor grayColor];
        _consumeNoteLab.font = [UIFont systemFontOfSize:14];
        [self addSubview:_consumeNoteLab];
        [_consumeNoteLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.leftImg.mas_bottom).equalTo(0);
            make.left.equalTo(self.leftImg.mas_right).equalTo(2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.02));
        }];

    }
    return _consumeNoteLab;
}


- (UIView *)erectLine {
    if(_erectLine == nil) {
        _erectLine = [[UIView alloc] init];
        _erectLine.backgroundColor = [UIColor grayColor];
        _erectLine.alpha = .5;
        [self addSubview:_erectLine];
        [_erectLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.blueView.mas_bottom).equalTo(SCREEN_HEIGHT*.025);
            make.left.equalTo(SCREEN_WIDTH/2-1);
            make.size.equalTo(CGSizeMake(1, SCREEN_HEIGHT*.05));
        }];
        
    }
    return _erectLine;
}


- (UIImageView *)rightImg {
    if(_rightImg == nil) {
        _rightImg = [[UIImageView alloc] init];
        [self addSubview:_rightImg];
        [_rightImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.erectLine.mas_right).equalTo(SCREEN_WIDTH*.07);
            make.top.equalTo(self.blueView.mas_bottom).equalTo(SCREEN_HEIGHT*.025);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.08, SCREEN_HEIGHT*.05));
        }];

    }
    return _rightImg;
}

- (UILabel *)totalCountLab {
    if(_totalCountLab == nil) {
        _totalCountLab = [[UILabel alloc] init];
        _totalCountLab.font = [UIFont systemFontOfSize:14];
        [self addSubview:_totalCountLab];
        [_totalCountLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.blueView.mas_bottom).equalTo(SCREEN_HEIGHT*.02);
            make.left.equalTo(self.rightImg.mas_right).equalTo(2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.02));
        }];
    }
    return _totalCountLab;
}

- (UILabel *)totalLab {
    if(_totalLab == nil) {
        _totalLab = [[UILabel alloc] init];
        _totalLab.textColor = bgColor(251, 103, 26);
        _totalLab.font = [UIFont systemFontOfSize:14];
        [self addSubview:_totalLab];
        [_totalLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.leftImg.mas_bottom).equalTo(0);
            make.left.equalTo(self.rightImg.mas_right).equalTo(2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.02));
        }];

    }
    return _totalLab;
}



@end
