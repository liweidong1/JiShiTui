//
//  FansOrderDetailCell.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface FansOrderDetailCell : UITableViewCell
@property(nonatomic,strong)UILabel *titleLb;//订单编号
@property(nonatomic,strong)UIImageView *timeImg;
@property(nonatomic,strong)UILabel *timeLb;//交易时间
@property(nonatomic,strong)UIImageView *priceImg;
@property(nonatomic,strong)UILabel *priceLb;//消费金额

@property(nonatomic,strong)UIButton *orderDetailBtn;


@property (nonatomic, copy) void(^fansOrderDetailClicked)(FansOrderDetailCell *cell);


@end
