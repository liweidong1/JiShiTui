//
//  FansOrderDetailCell.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansOrderDetailCell.h"

@implementation FansOrderDetailCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(20);
            make.left.equalTo(20);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 20));
        }];
    }
    return _titleLb;
}
- (UIImageView *)timeImg {
    if(_timeImg == nil) {
        _timeImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_timeImg];
        [_timeImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLb.mas_bottom).equalTo(4);
            make.left.equalTo(20);
            make.size.equalTo(CGSizeMake(14, 14));
        }];
        
    }
    return _timeImg;
}
- (UILabel *)timeLb {
    if(_timeLb == nil) {
        _timeLb = [[UILabel alloc] init];
        [self.contentView addSubview:_timeLb];
        _timeLb.font = [UIFont systemFontOfSize:15];
        [_timeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLb.mas_bottom).equalTo(0);
            make.left.equalTo(self.timeImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
        
    }
    return _timeLb;
}
- (UIImageView *)priceImg {
    if(_priceImg == nil) {
        _priceImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_priceImg];
        [_priceImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.timeLb.mas_bottom).equalTo(0);
            make.left.equalTo(20);
            make.size.equalTo(CGSizeMake(10, 14));
        }];

    }
    return _priceImg;
}
- (UILabel *)priceLb {
    if(_priceLb == nil) {
        _priceLb = [[UILabel alloc] init];
        _priceLb.font = [UIFont systemFontOfSize:15];
        [self.contentView addSubview:_priceLb];
        [_priceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.timeLb.mas_bottom).equalTo(0);
            make.left.equalTo(self.priceImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
    }
    return _priceLb;
}
- (UIButton *)orderDetailBtn {
    if(_orderDetailBtn == nil) {
        _orderDetailBtn = [[UIButton alloc] init];
        [self.contentView addSubview:_orderDetailBtn];
        [_orderDetailBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-20);
            make.bottom.equalTo(-10);
            make.size.equalTo(CGSizeMake(12, 12));
        }];
        [_orderDetailBtn bk_addEventHandler:^(id sender) {
            !_fansOrderDetailClicked ?: _fansOrderDetailClicked(self);
        } forControlEvents:UIControlEventTouchUpInside];

    }
    return _orderDetailBtn;
}
@end
