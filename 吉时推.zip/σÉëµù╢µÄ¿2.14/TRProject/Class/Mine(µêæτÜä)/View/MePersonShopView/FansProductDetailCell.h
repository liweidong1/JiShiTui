//
//  FansProductDetailCell.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FansProductDetailCell : UITableViewCell
@property(nonatomic,strong)UIImageView *userImg;
@property(nonatomic,strong)UILabel *titleLb;
@property(nonatomic,strong)UILabel *priceLb;
@property(nonatomic,strong)UIImageView *timeImg;
@property(nonatomic,strong)UILabel *timeLb;
@end
