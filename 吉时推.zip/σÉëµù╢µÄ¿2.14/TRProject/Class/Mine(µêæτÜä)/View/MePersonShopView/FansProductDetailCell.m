//
//  FansProductDetailCell.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansProductDetailCell.h"

@implementation FansProductDetailCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}

- (UIImageView *)userImg {
    if(_userImg == nil) {
        _userImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_userImg];
        [_userImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(55, 55));
        }];
    }
    return _userImg;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(20);
            make.left.equalTo(self.userImg.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
    }
    return _titleLb;
}
- (UILabel *)priceLb {
    if(_priceLb == nil) {
        _priceLb = [[UILabel alloc] init];
        _priceLb.font = [UIFont systemFontOfSize:12];
        _priceLb.textColor = bgColor(19, 185, 206);
        [self.contentView addSubview:_priceLb];
        [_priceLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(self.userImg.mas_bottom).equalTo(0);
            make.left.equalTo(self.userImg.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
        
    }
    return _priceLb;
}
- (UIImageView *)timeImg {
    if(_timeImg == nil) {
        _timeImg = [[UIImageView alloc] init];
        [self.contentView addSubview:_timeImg];
        [_timeImg mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.priceLb.mas_bottom).equalTo(5);
            make.left.equalTo(self.userImg.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(10, 10));
        }];
        
    }
    return _timeImg;
}
- (UILabel *)timeLb {
    if(_timeLb == nil) {
        _timeLb = [[UILabel alloc] init];
        [self.contentView addSubview:_timeLb];
        _timeLb.font = [UIFont systemFontOfSize:12];
        [_timeLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.priceLb.mas_bottom).equalTo(0);
            make.left.equalTo(self.timeImg.mas_right).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.7, 20));
        }];
        
    }
    return _timeLb;
}

@end
