//
//  ProductReviseDetailCell.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
/**   ------产品名称 ---------*/
@interface ProductReviseDetailStyleOneCell : UITableViewCell
@property(nonatomic,strong)UILabel *productNameLab;
@property(nonatomic,strong)UITextField *productNameTF;
@end
/**   ------产品标题      产品详情 ---------*/
@interface ProductReviseDetailStyleTworCell : UITableViewCell
@property(nonatomic,strong)UILabel *productNameLab;
@property(nonatomic,strong)UITextView *productNameTF;
@property(nonatomic,strong)UILabel *promLb;
@end
/**   ------产品展示图   ---------*/
@interface ProductReviseDetailStyleThreeCell : UITableViewCell
@property(nonatomic,strong)UILabel *productNameLab;
@property(nonatomic,strong)UIImageView *productIv;
@property (nonatomic, strong) void(^productIvHandler)();
@end
/**   ------ 产品多图 ---------*/
@interface ProductReviseDetailStyleFourCell : UITableViewCell
@property(nonatomic,strong)UILabel *productNameLab;
@property(nonatomic,strong)UIButton * photoBtn;
@property(nonatomic,strong)UIImageView *ptoto1;
@property(nonatomic,strong)UIImageView *ptoto2;
@property(nonatomic,strong)UIImageView *ptoto3;
@property(nonatomic,strong)UIImageView *ptoto4;
@property(nonatomic,strong)UIImageView *ptoto5;

@property (nonatomic, strong) void(^photoHandler)();

@end
/**   ------产品价格   折扣价   库存 ---------*/
@interface ProductReviseDetailStyleFifthCell : UITableViewCell
@property(nonatomic,strong)UILabel *productPriceLab;
@property(nonatomic,strong)UITextField *productmoneyTF;
@property(nonatomic,strong)UILabel *unitLab;



@end
