//
//  ProductReviseDetailCell.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ProductReviseDetailCell.h"
/**   ------产品名称 ---------*/
@implementation ProductReviseDetailStyleOneCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)productNameLab {
    if(_productNameLab == nil) {
        _productNameLab = [[UILabel alloc] init];
        _productNameLab.textColor = bgColor(0, 154, 176);
        [self.contentView addSubview:_productNameLab];
        [_productNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
        }];

    }
    return _productNameLab;
}

- (UITextField *)productNameTF {
    if(_productNameTF == nil) {
        _productNameTF = [[UITextField alloc] init];
        [self.contentView addSubview:_productNameTF];
        [_productNameTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.productNameLab.mas_right).equalTo(10);
            make.right.equalTo(0);
        }];
    }
    return _productNameTF;
}
@end

/**   ------产品标题      产品详情 ---------*/
@implementation ProductReviseDetailStyleTworCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)productNameLab {
    if(_productNameLab == nil) {
        _productNameLab = [[UILabel alloc] init];
        _productNameLab.textColor = bgColor(0, 154, 176);
        [self.contentView addSubview:_productNameLab];
        [_productNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(5);
            make.height.equalTo(30);
        }];
    }
    return _productNameLab;
}

- (UITextView *)productNameTF {
    if(_productNameTF == nil) {
        _productNameTF = [[UITextView alloc] init];
        _productNameTF.backgroundColor = [UIColor clearColor];
        _productNameTF.font = [UIFont systemFontOfSize:12];
        _productNameTF.textColor = [UIColor grayColor];
        [self.contentView addSubview:_productNameTF];
        [_productNameTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(5);
            make.left.equalTo(self.productNameLab.mas_right).equalTo(10);
            make.right.equalTo(0);
            make.height.equalTo(60);
        }];
    }
    return _productNameTF;
}
- (UILabel *)promLb {
    if(_promLb == nil) {
        _promLb = [[UILabel alloc] init];
        _promLb.textAlignment = NSTextAlignmentRight;
        _promLb.font = [UIFont systemFontOfSize:12];
        _promLb.textColor = [UIColor grayColor];
        [self.contentView addSubview:_promLb];
        [_promLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.bottom.equalTo(-5);
            make.height.equalTo(20);
        }];
    }
    return _promLb;
}
@end

/**   ------产品展示图      产品多图 ---------*/
@implementation ProductReviseDetailStyleThreeCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)productNameLab {
    if(_productNameLab == nil) {
        _productNameLab = [[UILabel alloc] init];
        _productNameLab.textColor = bgColor(0, 154, 176);
        [self.contentView addSubview:_productNameLab];
        [_productNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.equalTo(10);
            make.height.equalTo(20);
        }];
    }
    return _productNameLab;
}

- (UIImageView *)productIv {
    if(_productIv == nil) {
        _productIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_productIv];
        _productIv.userInteractionEnabled = YES;
        [_productIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(5);
            make.left.equalTo(self.productNameLab.mas_right).equalTo(10);
            make.size.equalTo(CGSizeMake(60, 60));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chooseProductImg:)];
        tapGR.numberOfTapsRequired=1;
        [_productIv addGestureRecognizer:tapGR];
    }
    return _productIv;
}
-(void)chooseProductImg:(UIPanGestureRecognizer*)gr
{
    !self.productIvHandler ?: self.productIvHandler();
}
@end
@implementation ProductReviseDetailStyleFourCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *)productNameLab {
    if(_productNameLab == nil) {
        _productNameLab = [[UILabel alloc] init];
        _productNameLab.textColor = bgColor(0, 154, 176);
        [self.contentView addSubview:_productNameLab];
        [_productNameLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.left.equalTo(10);
            make.height.equalTo(20);
        }];
    }
    return _productNameLab;
}
- (UIButton *) photoBtn {
    if(_photoBtn == nil) {
        _photoBtn = [[UIButton alloc] init];
        _photoBtn.layer.borderWidth = .5f;
        _photoBtn.layer.borderColor = [UIColor grayColor].CGColor;
        [_photoBtn bk_addEventHandler:^(id sender) {
            !self.photoHandler ?: self.photoHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_photoBtn];
        [_photoBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.productNameLab.mas_right).equalTo(10);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
        
    }
    return _photoBtn;
}

- (UIImageView *)ptoto1 {
    if(_ptoto1 == nil) {
        _ptoto1 = [[UIImageView alloc] init];
        _ptoto1.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto1];
        [_ptoto1 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.photoBtn.mas_right).equalTo(5);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
    }
    return _ptoto1;
}

- (UIImageView *)ptoto2 {
    if(_ptoto2 == nil) {
        _ptoto2 = [[UIImageView alloc] init];
        _ptoto2.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto2];
        [_ptoto2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ptoto1.mas_right).equalTo(5);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
    }
    return _ptoto2;
}
- (UIImageView *)ptoto3 {
    if(_ptoto3 == nil) {
        _ptoto3 = [[UIImageView alloc] init];
        _ptoto3.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto3];
        [_ptoto3 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ptoto2.mas_right).equalTo(5);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
    }
    return _ptoto3;
}
- (UIImageView *)ptoto4 {
    if(_ptoto4 == nil) {
        _ptoto4 = [[UIImageView alloc] init];
        _ptoto4.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto4];
        [_ptoto4 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ptoto3.mas_right).equalTo(5);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
    }
    return _ptoto4;
}
- (UIImageView *)ptoto5 {
    if(_ptoto5 == nil) {
        _ptoto5 = [[UIImageView alloc] init];
        _ptoto5.backgroundColor = bgColor(0, 177, 200);
        [self addSubview:_ptoto5];
        [_ptoto5 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.ptoto4.mas_right).equalTo(5);
            make.top.equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
            
        }];
    }
    return _ptoto5;
}

@end

/**   ------产品价格   折扣价   库存 ---------*/
@implementation ProductReviseDetailStyleFifthCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}

- (UILabel *)productPriceLab {
    if(_productPriceLab == nil) {
        _productPriceLab = [[UILabel alloc] init];
        _productPriceLab.textColor = bgColor(0, 154, 176);
        [self.contentView addSubview:_productPriceLab];
        [_productPriceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
        }];
    }
    return _productPriceLab;
}

- (UITextField *)productmoneyTF {
    if(_productmoneyTF == nil) {
        _productmoneyTF = [[UITextField alloc] init];
        _productmoneyTF.textColor = bgColor(0, 154, 176);
        _productmoneyTF.textAlignment = NSTextAlignmentCenter;
        _productmoneyTF.layer.borderWidth = 1;
        _productmoneyTF.layer.borderColor = [UIColor grayColor].CGColor;
        [self.contentView addSubview:_productmoneyTF];
        [_productmoneyTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.productPriceLab.mas_right).equalTo(10);
            make.size.equalTo(CGSizeMake(50, 20));
        }];
    }
    return _productmoneyTF;
}

- (UILabel *)unitLab {
    if(_unitLab == nil) {
        _unitLab = [[UILabel alloc] init];
        [self.contentView addSubview:_unitLab];
        [_unitLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.productmoneyTF.mas_right).equalTo(10);
        }];
    }
    return _unitLab;
}
@end
