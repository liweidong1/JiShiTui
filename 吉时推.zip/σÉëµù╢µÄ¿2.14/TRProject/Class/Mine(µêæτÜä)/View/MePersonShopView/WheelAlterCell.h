//
//  WheelAlterCell.h
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WheelAlterCell : UITableViewCell
@property(nonatomic,strong)UIImageView *adIv;
@property(nonatomic,strong)UITextField *adTF;
@property(nonatomic,strong)UIImageView *adAleterIV;
@property(nonatomic,strong)UIButton *adAleterBtn;
//此属性表示cell拥有一个向外部通知按钮被点击的能力.
//至于上级用不用, 是上级的事情
@property (nonatomic, copy) void(^adAleterBtnClicked)(WheelAlterCell *cell);
@end
