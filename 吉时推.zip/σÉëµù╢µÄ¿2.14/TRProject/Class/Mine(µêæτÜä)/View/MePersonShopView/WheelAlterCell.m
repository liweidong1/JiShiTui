//
//  WheelAlterCell.m
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "WheelAlterCell.h"

@implementation WheelAlterCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)adIv {
    if(_adIv == nil) {
        _adIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_adIv];
        _adIv.userInteractionEnabled = NO;
        [_adIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(5);
            make.left.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, SCREEN_WIDTH*.1));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_adIv addGestureRecognizer:tapGR];
    }
    return _adIv;
}

-(void)start:(UIPanGestureRecognizer*)gr
{
    
}
- (UITextField *)adTF {
    if(_adTF == nil) {
        _adTF = [[UITextField alloc] init];
        _adTF.userInteractionEnabled = NO;
        [self.contentView addSubview:_adTF];
        [_adTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(5);
            make.left.equalTo(self.adIv.mas_right).equalTo(10);

            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.6, 30));
        }];
    }
    return _adTF;
}
- (UIButton *)adAleterBtn {
    if(_adAleterBtn == nil) {
        _adAleterBtn = [[UIButton alloc] init];
        [_adAleterBtn setTitleColor:bgColor(0, 178, 201) forState:UIControlStateNormal];
        
        [_adAleterBtn bk_addEventHandler:^(id sender) {
        !_adAleterBtnClicked ?: _adAleterBtnClicked(self);
        } forControlEvents:UIControlEventTouchUpInside];

        [self.contentView addSubview:_adAleterBtn];
        [_adAleterBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.adTF);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, 15));
        }];

    }
    return _adAleterBtn;
}
- (UIImageView *)adAleterIV {
    if(_adAleterIV == nil) {
        _adAleterIV = [[UIImageView alloc] init];
        [self.contentView addSubview:_adAleterIV];
        [_adAleterIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self.adTF);
            make.right.equalTo(self.adAleterBtn.mas_left).equalTo(-5);
            make.size.equalTo(CGSizeMake(15, 15));
        }];

    }
    return _adAleterIV;
}




@end
