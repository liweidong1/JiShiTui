//
//  personShopHeaderView.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface personShopHeaderView : UIView
@property(nonatomic,strong)UIView *horiLine;
@property(nonatomic,strong)UIView *erectLine;
@property(nonatomic,strong)UILabel *payAttLb;
@property(nonatomic,strong)UILabel *payAttCountLb;
@property(nonatomic,strong)UILabel *fansLb;
@property(nonatomic,strong)UILabel *fansCountLb;



@end
