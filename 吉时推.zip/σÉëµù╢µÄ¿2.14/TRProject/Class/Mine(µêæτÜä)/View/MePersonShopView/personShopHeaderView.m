//
//  personShopHeaderView.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "personShopHeaderView.h"

@implementation personShopHeaderView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self erectLine];
        [self horiLine];
        [self payAttLb];
        [self payAttCountLb];
        [self fansLb];
        [self fansCountLb];
    }
    return self;
}
- (UIView *)horiLine {
    if(_horiLine == nil) {
        _horiLine = [[UIView alloc] init];
        _horiLine.backgroundColor = [UIColor lightGrayColor];
        _horiLine.alpha = .5;
        [self addSubview:_horiLine];
        [_horiLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(15);
            make.centerX.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 1));
        }];
    }
    return _horiLine;
}

- (UIView *)erectLine {
    if(_erectLine == nil) {
        _erectLine = [[UIView alloc] init];
        _erectLine.backgroundColor = [UIColor grayColor];
        _erectLine.alpha = .5;
        [self addSubview:_erectLine];
        [_erectLine mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.horiLine.mas_bottom).equalTo(15);
            make.left.equalTo(SCREEN_WIDTH/2);
            make.size.equalTo(CGSizeMake(1, 42));
        }];

    }
    return _erectLine;
}
- (UILabel *)payAttLb {
    if(_payAttLb == nil) {
        _payAttLb = [[UILabel alloc] init];
        _payAttLb.text = @"关注人数";
        _payAttLb.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_payAttLb];
        [_payAttLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.horiLine.mas_bottom).equalTo(15);
            make.left.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH/2);
            make.height.equalTo(20);
        }];
    }
    return _payAttLb;
}

- (UILabel *)payAttCountLb {
    if(_payAttCountLb == nil) {
        _payAttCountLb = [[UILabel alloc] init];
        _payAttCountLb.textAlignment = NSTextAlignmentCenter;
        _payAttCountLb.text = @"30";
        [self addSubview:_payAttCountLb];
        [_payAttCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.payAttLb.mas_bottom).equalTo(2);
            make.left.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH/2);
            make.height.equalTo(20);
        }];

    }
    return _payAttCountLb;
}

- (UILabel *)fansLb {
    if(_fansLb == nil) {
        _fansLb = [[UILabel alloc] init];
        _fansLb.text = @"粉丝人数";
        _fansLb.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_fansLb];
        [_fansLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.horiLine.mas_bottom).equalTo(15);
            make.right.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH/2);
            make.height.equalTo(20);
        }];

    }
    return _fansLb;
}

- (UILabel *)fansCountLb {
    if(_fansCountLb == nil) {
        _fansCountLb = [[UILabel alloc] init];
        _fansCountLb.text = @"60";
        _fansCountLb.textAlignment = NSTextAlignmentCenter;
        [self addSubview:_fansCountLb];
        [_fansCountLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.fansLb.mas_bottom).equalTo(2);
            make.right.equalTo(0);
            make.width.equalTo(SCREEN_WIDTH/2);
            make.height.equalTo(20);
        }];

    }
    return _fansCountLb;
}

@end
