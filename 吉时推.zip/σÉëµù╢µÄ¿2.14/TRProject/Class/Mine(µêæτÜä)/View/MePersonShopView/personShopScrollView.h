//
//  personShopScrollView.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface personShopScrollView : UIView

@property(nonatomic,strong)UIPageControl * pc;
@property(nonatomic,assign)NSInteger page;

@property(nonatomic,assign)UIButton *navBtn;

@property(nonatomic,strong)UIButton *bt1;
@property(nonatomic,strong)UILabel *lab1;

@property(nonatomic,strong)UIButton *bt2;
@property(nonatomic,strong)UILabel *lab2;

@property(nonatomic,strong)UIButton *bt3;
@property(nonatomic,strong)UILabel *lab3;

@property(nonatomic,strong)UIButton *bt4;
@property(nonatomic,strong)UILabel *lab4;

@property(nonatomic,strong)UIButton *bt5;
@property(nonatomic,strong)UILabel *lab5;
/**
 *  我的收入
 */
//@property(nonatomic,strong)UIButton *bt6;
//@property(nonatomic,strong)UILabel *lab6;


@property (nonatomic, strong) void(^box1HeaderImgHandler)();
@property (nonatomic, strong) void(^box2HeaderImgHandler)();
@property (nonatomic, strong) void(^box3HeaderImgHandler)();
@property (nonatomic, strong) void(^box4HeaderImgHandler)();
@property (nonatomic, strong) void(^box5HeaderImgHandler)();
//@property (nonatomic, strong) void(^box6HeaderImgHandler)();

@end
