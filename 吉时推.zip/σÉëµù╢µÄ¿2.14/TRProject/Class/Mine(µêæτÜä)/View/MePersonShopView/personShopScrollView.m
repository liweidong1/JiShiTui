//
//  personShopScrollView.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "personShopScrollView.h"


@interface personShopScrollView ()<UIScrollViewDelegate>
@property(nonatomic,strong)UIScrollView * sv;
@end
@implementation personShopScrollView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        //1滚动视图
        UIScrollView * sv =[[UIScrollView alloc]init];
        self.sv=sv;
        sv.frame = CGRectMake(0, 0, self.bounds.size.width, self.bounds.size.height);
        [self addSubview:sv];
        //姿势图
        for (int i = 0; i<1 ; i++) {
            UIView *view1 = [[UIView alloc]init];
            view1.frame = CGRectMake(i*sv.bounds.size.width, 0, sv.bounds.size.width, sv.bounds.size.height);
            view1.backgroundColor = [UIColor whiteColor];
            [sv addSubview:view1];
            sv.bounces =NO;
            sv.showsHorizontalScrollIndicator = YES;
            sv.scrollEnabled = YES;
            sv.pagingEnabled = YES;
            
            sv.contentSize = CGSizeMake(1*sv.bounds.size.width, sv.bounds.size.height);
            
            [self addSubview:sv];
            if(i==0){
                //添加第1个视图的8个按钮
                [self addFirstView:view1];
            }
            
        }
        
    }
    return self;
}
/**************************************************************navView页面1Start**********************/
-(void)addFirstView:(UIView *)view1{
    //循环6个盒子 u847   u851
    for (int i=0; i<6; i++) {
        UIView *boxView = [[UIView alloc]initWithFrame:CGRectMake(i*SCREEN_WIDTH/3, 0, SCREEN_WIDTH/3, SCREEN_HEIGHT*.2)];
        boxView.layer.borderWidth = 0.5;
        boxView.layer.borderColor = bgColor(234, 234, 234).CGColor;
        UIButton *navBtn = [[UIButton alloc]init];
        self.navBtn = navBtn;
        [boxView addSubview:navBtn];
        [navBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.2*0.2);
            make.size.with.height.equalTo(SCREEN_HEIGHT*.2*0.5);
        }];
        navBtn.backgroundColor = [UIColor clearColor];
        UILabel *navLable = [[UILabel alloc]init];
        navLable.textAlignment = NSTextAlignmentCenter;
        [boxView addSubview:navLable];
        [navLable mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.left.right.equalTo(0);
            make.bottom.equalTo(-10);
        }];
        if (i>=3) {
            boxView.frame = CGRectMake((i-3)*SCREEN_WIDTH/3, SCREEN_HEIGHT*.2, SCREEN_WIDTH/3, SCREEN_HEIGHT*.2);
        }
        if (i == 0) {
            _lab1 = navLable;
            _lab1.text = @"发布商品";
            _bt1 = navBtn;
            [_bt1 setImage:[UIImage imageNamed:@"my_publish"] forState:UIControlStateNormal];
            [_bt1 addTarget:self action:@selector(clickjstHouse) forControlEvents:UIControlEventTouchUpInside];
        } else if(i == 1) {
            _lab2 = navLable;
            _lab2.text = @"商品修改";
            _bt2 = navBtn;
            [_bt2 setImage:[UIImage imageNamed:@"my_revise"] forState:UIControlStateNormal];
            [_bt2 addTarget:self action:@selector(clickjstPersonHouse) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 2) {
            _lab3 = navLable;
            _lab3.text = @"店铺管理";
            
            _bt3 = navBtn;
            [_bt3 setImage:[UIImage imageNamed:@"my_advertisement"] forState:UIControlStateNormal];
            [_bt3 addTarget:self action:@selector(clickjstShopChange) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 3) {
            _lab4 = navLable;
            _lab4.text = @"消息推送";
            
            _bt4 = navBtn;
            [_bt4 setImage:[UIImage imageNamed:@"my_news"] forState:UIControlStateNormal];
            [_bt4 addTarget:self action:@selector(clickjstErshouche) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 4) {
            _lab5 = navLable;
            _lab5.text = @"粉丝管理";
            _bt5 = navBtn;
            [_bt5 setImage:[UIImage imageNamed:@"my_follower"] forState:UIControlStateNormal];
            [_bt5 addTarget:self action:@selector(clickjstPersonCar) forControlEvents:UIControlEventTouchUpInside];
        }else if(i == 5) {
//            _lab6 = navLable;
//            _lab6.text = @"我的收入";
//            _bt6 = navBtn;
//            [_bt6 setImage:[UIImage imageNamed:@"my_income"] forState:UIControlStateNormal];
//            [_bt6 addTarget:self action:@selector(clickjstNewCar) forControlEvents:UIControlEventTouchUpInside];
        }
        [view1 addSubview:boxView];
    }
}
//-(void)clickjstNewCar
//{
//    NSLog(@"我的收入");
//    !self.box6HeaderImgHandler ?: self.box6HeaderImgHandler();
//}
-(void)clickjstPersonCar
{
    NSLog(@"粉丝管理");
    !self.box5HeaderImgHandler ?: self.box5HeaderImgHandler();
}
-(void)clickjstErshouche
{
    NSLog(@"消息推送");
    !self.box4HeaderImgHandler ?: self.box4HeaderImgHandler();
}
-(void)clickjstShopChange
{
    NSLog(@"轮播管理");
    !self.box3HeaderImgHandler ?: self.box3HeaderImgHandler();
}
-(void)clickjstPersonHouse
{
    NSLog(@"商品修改");
    !self.box2HeaderImgHandler ?: self.box2HeaderImgHandler();
}
-(void)clickjstHouse
{
    NSLog(@"发布商品");
    !self.box1HeaderImgHandler ?: self.box1HeaderImgHandler();
}


@end
