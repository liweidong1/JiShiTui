//
//  BindingCell.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BindingCell : UITableViewCell
@property(nonatomic,strong)UIImageView *iv;
@property(nonatomic,strong)UILabel *titleLb;
@property(nonatomic,strong)UILabel *gRateLab;
@property(nonatomic,strong)UILabel *distanceLab;
@property(nonatomic,strong)UILabel *descLab;
@property(nonatomic,strong)UIImageView *loveIv;
@property(nonatomic,strong)UILabel *countLab;

@end
