//
//  BindingCell.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BindingCell.h"

@implementation BindingCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(10);
            make.left.equalTo(8);
            make.size.equalTo(CGSizeMake(90, 60));
        }];
    }
    return _iv;
}

- (UILabel *)titleLb {
    if(_titleLb == nil) {
        _titleLb = [[UILabel alloc] init];
        _titleLb.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_titleLb];
        [_titleLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iv.mas_top).equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, 20));
        }];
    }
    return _titleLb;
}
- (UILabel *)gRateLab {
    if(_gRateLab == nil) {
        _gRateLab = [[UILabel alloc] init];
        _gRateLab.font = [UIFont systemFontOfSize:14];
        _gRateLab.textColor = bgColor(253, 148, 48);
        [self.contentView addSubview:_gRateLab];
        [_gRateLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.titleLb.mas_bottom).equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 20));
        }];
    }
    return _gRateLab;
}

- (UILabel *)distanceLab {
    if(_distanceLab == nil) {
        _distanceLab = [[UILabel alloc] init];
        _distanceLab.font = [UIFont systemFontOfSize:10];
        [self.contentView addSubview:_distanceLab];
        _distanceLab.textColor = bgColor(253, 148, 48);
        [_distanceLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.gRateLab.mas_bottom).equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-113, 20));
        }];
    }
    return _distanceLab;
}

- (UILabel *)descLab {
    if(_descLab == nil) {
        _descLab = [[UILabel alloc] init];
        _descLab.font = [UIFont systemFontOfSize:11];
        _descLab.numberOfLines = 0;
        _descLab.textColor = [UIColor grayColor];
        [self.contentView addSubview:_descLab];
        [_descLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.distanceLab.mas_bottom).equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH-115, 49));
        }];

    }
    return _descLab;
}
- (UILabel *)countLab {
    if(_countLab == nil) {
        _countLab = [[UILabel alloc] init];
        _countLab.font = [UIFont systemFontOfSize:14];
        _countLab.textColor = bgColor(0, 177, 200);
        [self.contentView addSubview:_countLab];
        [_countLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.iv.mas_top).equalTo(0);
            make.right.equalTo(-10);
            make.size.equalTo(CGSizeMake(30, 20));
        }];

    }
    return _countLab;
}

- (UIImageView *)loveIv {
    if(_loveIv == nil) {
        _loveIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_loveIv];
        [_loveIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(10);
            make.right.equalTo(self.countLab.mas_left).equalTo(-5);
            make.size.equalTo(CGSizeMake(20, 18));
        }];
    }
    return _loveIv;
}



@end
