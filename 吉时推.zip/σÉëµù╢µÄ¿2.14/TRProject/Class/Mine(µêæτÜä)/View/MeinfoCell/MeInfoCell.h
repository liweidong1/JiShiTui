//
//  MeInfoCell.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeInfoOneCell : UITableViewCell

@property(nonatomic,strong)UILabel * leftLab;
@property(nonatomic,strong)UIImageView *rightIv;
@property(nonatomic,strong)UILabel *plcLab;
@property (nonatomic, strong) void(^styleHeaderImgHandler)();
@end


@interface MeInfoTwoCell : UITableViewCell
@property(nonatomic,strong)UILabel * leftLab;
@property(nonatomic,strong)UITextField *infoTF;
@end

@interface MeInfoSexCell : UITableViewCell
@property(nonatomic,strong)UILabel * leftLab;
@property(nonatomic,strong)UIButton *noBtn;
@property(nonatomic,strong)UILabel *noLab;
@property(nonatomic,strong)UIButton *wexinBtn;
@property(nonatomic,strong)UILabel *weixinLab;
@property (nonatomic, strong) void(^noChooseHandler)();
@property (nonatomic, strong) void(^weixinChooseHandler)();
@end


@interface MeInfoNormalCell : UITableViewCell
@property(nonatomic,strong)UILabel * leftLab;
@property(nonatomic,strong)UITextField *infoTF;
@property(nonatomic,strong)UIImageView *rightIv;
@end




