//
//  MeInfoCell.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeInfoCell.h"

@implementation MeInfoOneCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) leftLab {
    if(_leftLab == nil) {
        _leftLab = [[UILabel alloc] init];
        [self.contentView addSubview:_leftLab];
        [_leftLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _leftLab;
}

- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-29);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(30, 30));
        }];
        
        _rightIv.userInteractionEnabled = YES;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chooseImg:)];
        tapGR.numberOfTapsRequired=1;
        [_rightIv addGestureRecognizer:tapGR];
        
    }
    return _rightIv;
}
- (UILabel *) plcLab {
    if(_plcLab == nil) {
        _plcLab = [[UILabel alloc] init];
        _plcLab.font = [UIFont systemFontOfSize:14];
         _plcLab.textColor = [UIColor grayColor];
        _plcLab.textAlignment = NSTextAlignmentRight;
        [self.contentView addSubview:_plcLab];
        [_plcLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.rightIv.mas_left).equalTo(-5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _plcLab;
}
-(void)chooseImg:(UIPanGestureRecognizer*)gr
{
    !self.styleHeaderImgHandler ?: self.styleHeaderImgHandler();
}
@end


@implementation MeInfoTwoCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) leftLab {
    if(_leftLab == nil) {
        _leftLab = [[UILabel alloc] init];
        [self.contentView addSubview:_leftLab];
        [_leftLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _leftLab;
}

- (UITextField *) infoTF {
    if(_infoTF == nil) {
        _infoTF = [[UITextField alloc] init];
        [self.contentView addSubview:_infoTF];
        _infoTF.textColor = [UIColor grayColor];
        _infoTF.textAlignment = NSTextAlignmentRight;
        [_infoTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.3, 20));
        }];
    }
    return _infoTF;
}

@end

@implementation MeInfoSexCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) leftLab {
    if(_leftLab == nil) {
        _leftLab = [[UILabel alloc] init];
        [self.contentView addSubview:_leftLab];
        [_leftLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _leftLab;
}
- (UIButton *)noBtn {
    if(_noBtn == nil) {
        _noBtn = [[UIButton alloc] init];
        [_noBtn bk_addEventHandler:^(id sender) {
            !self.noChooseHandler ?: self.noChooseHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_noBtn];
        [_noBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.leftLab.mas_right).equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];
        
    }
    return _noBtn;
}

- (UILabel *)noLab {
    if(_noLab == nil) {
        _noLab = [[UILabel alloc] init];
        _noLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_noLab];
        [_noLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.noBtn.mas_right).equalTo(5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, 20));
        }];
        
    }
    return _noLab;
}

- (UIButton *)wexinBtn {
    if(_wexinBtn == nil) {
        _wexinBtn = [[UIButton alloc] init];
        [_wexinBtn bk_addEventHandler:^(id sender) {
            !self.weixinChooseHandler ?: self.weixinChooseHandler();
        } forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:_wexinBtn];
        [_wexinBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.noLab.mas_right).equalTo(SCREEN_WIDTH*.05);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];
    }
    return _wexinBtn;
}

- (UILabel *)weixinLab {
    if(_weixinLab == nil) {
        _weixinLab = [[UILabel alloc] init];
        _weixinLab.font = [UIFont systemFontOfSize:14];
        [self.contentView addSubview:_weixinLab];
        [_weixinLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.wexinBtn.mas_right).equalTo(5);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.1, 20));
        }];
    }
    return _weixinLab;
}


@end
@implementation MeInfoNormalCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UILabel *) leftLab {
    if(_leftLab == nil) {
        _leftLab = [[UILabel alloc] init];
        [self.contentView addSubview:_leftLab];
        [_leftLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.2, 20));
        }];
    }
    return _leftLab;
}

- (UITextField *) infoTF {
    if(_infoTF == nil) {
        _infoTF = [[UITextField alloc] init];
        [self.contentView addSubview:_infoTF];
        _infoTF.font = [UIFont systemFontOfSize:12];
        [_infoTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.leftLab.mas_right).equalTo(4);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.8-60, 20));
        }];
    }
    return _infoTF;
}
- (UIImageView *)rightIv {
    if(_rightIv == nil) {
        _rightIv = [[UIImageView alloc] init];
        _rightIv.hidden = YES;
        [self.contentView addSubview:_rightIv];
        [_rightIv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(-29);
            make.centerY.equalTo(0);
            make.size.equalTo(CGSizeMake(7, 10));
        }];
//        _rightIv.userInteractionEnabled = YES;
//        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(chooseImg:)];
//        tapGR.numberOfTapsRequired=1;
//        [_rightIv addGestureRecognizer:tapGR];
        
    }
    return _rightIv;
}
@end
