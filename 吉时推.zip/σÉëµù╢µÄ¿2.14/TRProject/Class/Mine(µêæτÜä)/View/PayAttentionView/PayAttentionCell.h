//
//  PayAttentionCell.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PayAttentionHeaderCell : UITableViewCell
@property(nonatomic,strong)UIImageView *iv;
@property(nonatomic,strong)UILabel *shopLb;
@end


@interface PayAttentionNormalCell : UITableViewCell
@property(nonatomic,strong)UIImageView *iv;
@property(nonatomic,strong)UILabel *shopLb;






@end
