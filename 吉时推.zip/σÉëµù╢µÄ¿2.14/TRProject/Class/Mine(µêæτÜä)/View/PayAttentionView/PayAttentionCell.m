//
//  PayAttentionCell.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PayAttentionCell.h"

@implementation PayAttentionHeaderCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
    }
    return self;
}
- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(15);
            make.size.equalTo(CGSizeMake(70, 70));
        }];
    }
    return _iv;
}

- (UILabel *)shopLb {
    if(_shopLb == nil) {
        _shopLb = [[UILabel alloc] init];
        _shopLb.font = [UIFont systemFontOfSize:14];
        _shopLb.textAlignment = NSTextAlignmentCenter;
        [self.contentView addSubview:_shopLb];
        [_shopLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.iv.mas_bottom).equalTo(5);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 20));
        }];
    }
    return _shopLb;
}
@end


@implementation PayAttentionNormalCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        self.selectionStyle = UITableViewCellSelectionStyleNone;
        //去掉cell左侧分割线的间距
        self.separatorInset = UIEdgeInsetsZero;
        self.layoutMargins = UIEdgeInsetsZero;
        self.preservesSuperviewLayoutMargins = NO;
        self.accessoryType=UITableViewCellAccessoryDisclosureIndicator;
    }
    return self;
}
- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.contentView addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(10);
            make.size.equalTo(CGSizeMake(55, 55));
        }];

    }
    return _iv;
}

- (UILabel *)shopLb {
    if(_shopLb == nil) {
        _shopLb = [[UILabel alloc] init];
        [self.contentView addSubview:_shopLb];
        [_shopLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(0);
            make.left.equalTo(self.iv.mas_right).equalTo(15);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 30));
        }];

    }
    return _shopLb;
}
@end

