//
//  erweimaView.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface erweimaView : UIView
@property(nonatomic,strong)UIImageView *bgIV;
@property(nonatomic,strong)UIImageView *iv;
@property(nonatomic,strong)UILabel *ewmLb;

@property(nonatomic,strong)UIButton *shareBtn;

@property (nonatomic, strong) void(^setshareHandler)();



@end
