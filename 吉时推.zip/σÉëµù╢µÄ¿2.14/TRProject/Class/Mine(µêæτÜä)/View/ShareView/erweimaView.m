//
//  erweimaView.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "erweimaView.h"

@implementation erweimaView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self bgIV];
        [self iv];
        [self ewmLb];
        [self shareBtn];
    }
    return self;
}
- (UIView *)bgIV {
    if(_bgIV == nil) {
        _bgIV = [[UIImageView alloc] init];
        _bgIV.userInteractionEnabled = YES;
        [self addSubview:_bgIV];
        [_bgIV mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(SCREEN_HEIGHT*.2-10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH/3+20, SCREEN_WIDTH/3+20));
        }];
    }
    return _bgIV;
}
- (UIImageView *)iv {
    if(_iv == nil) {
        _iv = [[UIImageView alloc] init];
        [self.bgIV addSubview:_iv];
        [_iv mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(0);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH/3, SCREEN_WIDTH/3));
        }];
    }
    return _iv;
}

- (UILabel *)ewmLb {
    if(_ewmLb == nil) {
        _ewmLb = [[UILabel alloc] init];
        _ewmLb.font = [UIFont systemFontOfSize:16];
        _ewmLb.textAlignment = NSTextAlignmentCenter;
        _ewmLb.textColor = bgColor(0, 170, 243);
        [self addSubview:_ewmLb];
        [_ewmLb mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.iv.mas_bottom).equalTo(30);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH, 30));
        }];
    }
    return _ewmLb;
}
- (UIButton *)shareBtn {
    if(_shareBtn == nil) {
        _shareBtn = [[UIButton alloc] init];
        _shareBtn.layer.borderColor = bgColor(0, 170, 243).CGColor;
        [_shareBtn setTitleColor:bgColor(0, 170, 243) forState:UIControlStateNormal];
        [_shareBtn.layer setBorderWidth:1.0];   //边框宽度
        [self addSubview:_shareBtn];
        [_shareBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerX.equalTo(0);
            make.top.equalTo(self.ewmLb.mas_bottom).equalTo(SCREEN_HEIGHT*.2);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.5, 64));
        }];
        [_shareBtn bk_addEventHandler:^(id sender) {
            !self.setshareHandler ?: self.setshareHandler();
        } forControlEvents:UIControlEventTouchUpInside];
    }
    return _shareBtn;
}
@end
