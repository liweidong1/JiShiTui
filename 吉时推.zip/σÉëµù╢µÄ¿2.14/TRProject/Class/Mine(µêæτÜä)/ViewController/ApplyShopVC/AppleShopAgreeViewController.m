//
//  AppleShopViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/21.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "AppleShopAgreeViewController.h"

@interface AppleShopAgreeViewController ()<UIWebViewDelegate>
@property(nonatomic,strong)UIWebView *webView;

@end

@implementation AppleShopAgreeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"开店协议";
    self.webView.delegate = self;
    
    _webView = [UIWebView new];
    [self.view addSubview:_webView];
    [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.top.right.equalTo(0);
        make.bottom.equalTo(44);
    }];
    //http://3g.163.com/ntes/17/0208/18/CCP8J7VB002164A0.html
    NSString *urlStr = @"http://api.51jishitui.com/agreement";
    [_webView loadRequest:[NSURLRequest requestWithURL:urlStr.yx_URL]];

}
//代理方法
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [MBProgressHUD showHUDAddedTo:self.webView animated:YES];
}
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [MBProgressHUD hideAllHUDsForView:self.webView animated:YES];
}

//加载失败
-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.webView animated:YES];
    hud.labelText = @"加载失败";
    [hud hide:YES afterDelay:2];
}

@end
