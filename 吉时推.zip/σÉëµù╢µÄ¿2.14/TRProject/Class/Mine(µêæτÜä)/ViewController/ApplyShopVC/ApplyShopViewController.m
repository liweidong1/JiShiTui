//
//  ApplyShopViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/11.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "YLSOPickerView.h" //一级联动
#import "YLSThPickerView.h"//三级联动
#import "ApplyShopViewController.h"
#import "ApplyShopCell.h"
#import "BotView.h"
#import "MeNetWorking.h"
#import "AppleShopAgreeViewController.h"

#import "DPPhotoGroupViewController.h"

@interface ApplyShopViewController ()<UITableViewDelegate,UITableViewDataSource,UIPickerViewDelegate,UIPickerViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,DPPhotoGroupViewControllerDelegate>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)ApplyShopNormalCell * addrCell;//
@property(nonatomic,strong)ApplyShopNormalCell * styleCell;//经营类别
@property(nonatomic,strong)ApplyShopActCell * actCell;
@property(nonatomic,strong)ApplyShopCollectMoneyCell * moneyCell;//支付方式cell

@property(nonatomic,strong)ApplyShopPhotoCell * photoCell;//身份证
@property(nonatomic,strong)ApplyShopPhotoCell * photo5Cell;//营业执照
@property(nonatomic,strong)ApplyShopAgreeCell *agreeCell;//协议cell
@property(nonatomic,assign)UIImage *image;
@property(nonatomic,assign)BOOL didPickedImage;
@property(nonatomic,assign)NSInteger payStyleOne;
@property(nonatomic,assign)NSInteger agreeCount;
/**
 *  弹出视图相关
 */
/** array */
@property (nonatomic,strong) NSArray *arrayData;
@end

@implementation ApplyShopViewController

static NSString * reuseActIdentifier = @"ApplyShoActpCell";
static NSString * reusePhotoIdentifier = @"ApplyShopPhotopCell";
static NSString * reuseCollectMoneyIdentifier = @"ApplyShopCollectMoneyCell";
static NSString * reuseAgreeIdentifier = @"ApplyShopAgreeCell";
static NSString * reuseNormalIdentifier = @"ApplyShopNormalCell";
static NSString * reuseIdentifier = @"ApplyShopCell";

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我要开店";
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
    [self setTableView];
    [self setBotView];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}
-(void)setBotView
{
    BotView *botView = [[BotView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100)];
    [botView.applyBtn setTitle:@"开通" forState:UIControlStateNormal];
    [botView.ccelBtn setTitle:@"取消" forState:UIControlStateNormal];
    JSTWeakSelf
    botView.applyHandler = ^(){
        [weakSelf clickApplyBtn];
    };
    botView.ccelHandler = ^(){
        [weakSelf clickCcelBtn];
    };
    [self.view addSubview:botView];
}
-(void)clickCcelBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)clickApplyBtn
{
    [WSProgressHUD showSuccessWithStatus:@"发送开店请求"];
    //如果开店审核通过，则pop我的主页面
    [[NSNotificationCenter defaultCenter]postNotificationName:@"hiddenMineShop" object:nil];
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-100)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.tableView registerClass:[ApplyShopActCell class] forCellReuseIdentifier:reuseActIdentifier];
    [self.tableView registerClass:[ApplyShopPhotoCell class] forCellReuseIdentifier:reusePhotoIdentifier];
    [self.tableView registerClass:[ApplyShopCollectMoneyCell class] forCellReuseIdentifier:reuseCollectMoneyIdentifier];
     [self.tableView registerClass:[ApplyShopAgreeCell class] forCellReuseIdentifier:reuseAgreeIdentifier];
    [self.tableView registerClass:[ApplyShopNormalCell class] forCellReuseIdentifier:reuseNormalIdentifier];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];
    [self.view addSubview:self.tableView];
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 9;
    }else {
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
        JSTWeakSelf
        
         ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseNormalIdentifier];
        if (indexPath.row == 0) {
            cell.ShopNameLab.text = @"店铺名称:";
            cell.ShopNameTF.placeholder = @"(请输入您的店铺名称)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
            
        }else if (indexPath.row == 1) {
            _styleCell = cell;
            cell.ShopNameLab.text = @"经营类别:";
            cell.ShopNameTF.placeholder = @"(经营类别)";
            cell.ShopNameTF.userInteractionEnabled = NO;
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
            
        }
        else if (indexPath.row == 2) {
            cell.ShopNameLab.text = @"真实姓名:";
            cell.ShopNameTF.placeholder = @"(请输入您的真实姓名)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
        }else if (indexPath.row == 3) {
            cell.ShopNameLab.text = @"身份证号:";
            cell.ShopNameTF.placeholder = @"(请输入您正确的十八位身份证号)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
            
        }else if (indexPath.row == 4) {
            ApplyShopPhotoCell *cell = [tableView dequeueReusableCellWithIdentifier:reusePhotoIdentifier];
            _photoCell = cell;
            cell.userNameLab.text = @"身份证照片:";
            cell.userNameGrayLab.text = @"请上传您的身份证正反面照片";
            [cell.photoBtn setImage:[UIImage imageNamed:@"my_addimg"] forState:UIControlStateNormal];
            cell.promptLab.text = @"上传照片";
            cell.photoHandler =^(){
                [weakSelf clickChooseIDCard];
            };
            return cell;
        }else if (indexPath.row == 5) {
            ApplyShopPhotoCell *cell = [tableView dequeueReusableCellWithIdentifier:reusePhotoIdentifier];
            _photo5Cell =cell;
            cell.userNameLab.text = @"营业执照:";
            cell.userNameGrayLab.text = @"请上传您的营业执照照片";
            [cell.photoBtn setImage:[UIImage imageNamed:@"my_addimg"] forState:UIControlStateNormal];
            cell.promptLab.text = @"上传照片";
            cell.photoHandler =^(){
                [weakSelf clickChoosePhoto];
            };
            return cell;
        }
        else if (indexPath.row == 6) {
            cell.ShopNameLab.text = @"联系方式:";
            cell.ShopNameTF.placeholder = @"(请输入您的联系方式)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
            
        }else if (indexPath.row == 7) {
            _addrCell =cell;
            cell.ShopNameLab.text = @"所在地址:";
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
            
        }else if (indexPath.row == 8) {
            cell.ShopNameLab.text = @"详细地址:";
            cell.ShopNameTF.placeholder = @"(请填写详细地址)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
        }
    }else if(indexPath.section == 1){//协议
        ApplyShopAgreeCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseAgreeIdentifier];
        _agreeCell = cell;
        [cell.chooseBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
        [cell.chooseBtn bk_addEventHandler:^(id sender) {
            [self changeAgreeBtn];
        } forControlEvents:UIControlEventTouchUpInside];
        cell.readLab.text = @"我也阅读";
        [cell.readEnterBtn setTitle:@"《吉时推注册协议》" forState:UIControlStateNormal];
        [cell.readEnterBtn bk_addEventHandler:^(id sender) {
        [self.navigationController pushViewController:[AppleShopAgreeViewController new] animated:YES];
        } forControlEvents:UIControlEventTouchUpInside];
        return cell;
    }
    return [UITableViewCell new];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    if (indexPath.section == 0) {
        if (indexPath.row == 1) {
            [self clickChooseStyle];
        }
        if (indexPath.row == 7) {
            [self clickChooseAddr];
        }
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
//        if (indexPath.row == 2) {//代理商
//            return 64;
//        }else
        if(indexPath.row == 4 || indexPath.row == 5){
            return 120;
        }else {
            return 40;
        }
    }else {
        return 40;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0.001f;
    }else {
        return 10;
    }
}

#pragma mark- 点击事件
-(void)changeAgreeBtn
{
    _agreeCount++;
    if (_agreeCount %2 !=0) {
        [_agreeCell.chooseBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
    }else {
       [_agreeCell.chooseBtn setImage:[UIImage imageNamed:@"my_checkbox"] forState:UIControlStateNormal];
    }

    
}
-(void)clickChooseAddr
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getThreeValue:) name:@"ThreeValues" object:nil];//所在地址
    NSMutableArray * arrayProvince = [[NSMutableArray alloc] init];
    NSMutableArray * arrayCity = [[NSMutableArray alloc] init];
    NSMutableArray * arrayArea = [[NSMutableArray alloc] init];
    [MeNetWorking getPersonInfoChooseCityCompletionHandler:^(MeInfoModel *model, NSError *error) {
        for (int i = 0; i<model.city.province.count; i++) {
            [arrayProvince addObject:model.city.province[i].name];
        }
        for (int i = 0; i<model.city.city.count; i++) {
            [arrayCity addObject:model.city.city[i].name];
        }
        for (int i = 0; i<model.city.area.count; i++) {
            [arrayArea addObject:model.city.area[i].name];
        }
        
        YLSThPickerView *picker = [[YLSThPickerView alloc]init];
        picker.array = @[arrayProvince,arrayCity,arrayArea];
        self.arrayData = picker.array;
        [picker show];
    }];

}
#pragma mark - ---------------------- DPPhotoGroupViewControllerDelegate
- (void)didSelectPhotos:(NSMutableArray *)photos{
    NSLog(@"--%@--",photos);
    _photoCell.ptoto1.image = photos[0];
    if (photos.count>1) {
    _photoCell.ptoto2.image = photos[1];
    }
}
-(void)clickChooseIDCard
{
    DPPhotoGroupViewController *groupVC = [DPPhotoGroupViewController new];
    groupVC.maxSelectionCount = 9;
    groupVC.delegate = self;
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:groupVC] animated:YES completion:nil];
}
-(void)clickChoosePhoto
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];
}
-(void)clickChooseStyle
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getValue1:) name:@"value" object:nil];//经营方式
    [MeNetWorking getShopStyleCompletionHandler:^(ShopStyleModel *model, NSError *error) {
       NSMutableArray * array = [[NSMutableArray alloc] init];
        for (int i = 0; i<model.type.count; i++) {
            [array addObject:model.type[i].name];
        }
        YLSOPickerView *picker = [[YLSOPickerView alloc]init];
        picker.array = array;
        self.arrayData = picker.array;
        [picker show];
    }];
}
-(void)getValue1:(NSNotification *)notification
{
    _styleCell.ShopNameTF.text = notification.object;
}
-(void)getThreeValue:(NSNotification *)notification
{
    _addrCell.ShopNameTF.text = notification.object;
}

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component.
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.arrayData count];
}

#pragma mark - 代理
// 返回第component列第row行的标题
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return self.arrayData[row];
}

// 选中第component第row的时候调用
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _actCell.actTF.text = self.arrayData[row];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    NSData *imageData = nil;
    if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
        _photo5Cell.ptoto1.image = image;
        imageData = UIImagePNGRepresentation(image);
    }else{
        _photo5Cell.ptoto1.image = image;
        imageData = UIImageJPEGRepresentation(image, .5);
        
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}
@end
