//
//  BundingCardViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BundingCardViewController.h"
#import "ApplyShopCell.h"
#import "CardInfoViewController.h"
@interface BundingCardViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)ApplyShopNormalCell * cell1;
@property(nonatomic,strong)ApplyShopNormalCell * cell2;
@end

@implementation BundingCardViewController
static NSString * reuseIdentifierNor = @"NORCELL";//普通cell
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"绑定银行卡";
    [self setTableView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    
    [self.tableView registerClass:[ApplyShopNormalCell class] forCellReuseIdentifier:reuseIdentifierNor];
    
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.separatorStyle = NO;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.view addSubview:self.tableView];
    //表头
    [self setHeaderView];
    [self setNextBtn];
    UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endEdit:)];
    tapGR.numberOfTapsRequired=1;
    [self.tableView addGestureRecognizer:tapGR];
}
-(void)endEdit:(UIPanGestureRecognizer*)gr
{
    [self.view endEditing:YES];
}
-(void)setNextBtn
{
    JSTWeakSelf
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.6, SCREEN_WIDTH*.6, 40)];
    [btn setTitle:@"下一步" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [btn bk_addEventHandler:^(id sender) {
        if ([_cell1.ShopNameTF.text isEqualToString:@""]) {
            [weakSelf.view showStatus:@"请填写持卡人姓名"];
        }else if([_cell2.ShopNameTF.text isEqualToString:@""]){
            [weakSelf.view showStatus:@"请填写持卡人卡号"];
        }else if(_cell2.ShopNameTF.text.length != 19){
            [weakSelf.view showStatus:@"请正确输入持卡人卡号"];
        }else{
            CardInfoViewController *cardVC = [[CardInfoViewController alloc]init];
            [self.navigationController pushViewController:cardVC animated:YES];
        }
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}
-(void)setHeaderView
{
    UILabel *titleLab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 40)];
    titleLab.textAlignment = NSTextAlignmentCenter;
    titleLab.textColor = bgColor(0, 152, 177);
    titleLab.text = @"请绑定此卡人的银行卡";
    titleLab.font = [UIFont systemFontOfSize:15];
    self.tableView.tableHeaderView = titleLab;
}

#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierNor];
    
    if (indexPath.row == 0) {
        _cell1 = cell;
        cell.ShopNameLab.text = @"持卡人:";
        cell.ShopNameTF.placeholder = @"请填写此卡人的姓名";
    }else{
        _cell2 = cell;
        cell.ShopNameLab.text = @"卡号:";
        cell.ShopNameTF.placeholder = @"请填写银行卡号";

    }
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 4;
}
//- (void)scrollViewDidScroll:(UIScrollView *)scrollView
//{
//    [_cell.ShopNameTF resignFirstResponder];
//}

@end
