//
//  CardInfoViewController.h
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CardInfoViewController : BaseNSViewController

@end
