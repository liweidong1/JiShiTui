//
//  CardInfoViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "CardInfoViewController.h"
#import "ApplyShopCell.h"
#import "PhoneCodeViewController.h"
#import "LoginRegiseterNetworking.h"
@interface CardInfoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)ApplyShopNormalCell * cell1;
@property(nonatomic,strong)ApplyShopNormalCell * cell2;
@property(nonatomic,strong)UIButton * chooseBtn;
@property(nonatomic,assign)NSInteger agreeCount;

@property(nonatomic,strong)SMSModel *smsModel;
@end

@implementation CardInfoViewController
static NSString * reuseIdentifierNor = @"NORCELL";//普通cell
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"填写银行卡信息";
    [self setTableView];
    [self setNextBtn];
}
-(void)setNextBtn
{
    JSTWeakSelf
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.6, SCREEN_WIDTH*.6, 40)];
    [btn setTitle:@"下一步" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [btn bk_addEventHandler:^(id sender) {
        if ([_cell1.ShopNameTF.text isEqualToString:@""]) {
            [weakSelf.view showStatus:@"请填写卡类型"];
        }else if([_cell2.ShopNameTF.text isEqualToString:@""]){
            [weakSelf.view showStatus:@"请填写银行预留手机号"];
        }else if(_cell2.ShopNameTF.text.length != 11){
            [weakSelf.view showStatus:@"请正确输入手机号"];
        }else if (_agreeCount %2 != 0) {
            [weakSelf.view showStatus:@"请勾选同意服务协议"];
        }else{
            PhoneCodeViewController *cardVC = [[PhoneCodeViewController alloc]initWithPhoneStr:_cell2.ShopNameTF.text];
            //发送验证码请求
            [LoginRegiseterNetworking Phone:_cell2.ShopNameTF.text SMSCompletionHandler:^(SMSModel *model, NSError *error) {
                _smsModel = model;
                [WSProgressHUD showSuccessWithStatus:model.info];
            }];
            [self.navigationController pushViewController:cardVC animated:YES];
        }
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    
    [self.tableView registerClass:[ApplyShopNormalCell class] forCellReuseIdentifier:reuseIdentifierNor];
    
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.separatorStyle = NO;
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.view addSubview:self.tableView];
    
    UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endEdit:)];
    tapGR.numberOfTapsRequired=1;
    [self.tableView addGestureRecognizer:tapGR];
}
-(void)endEdit:(UIPanGestureRecognizer*)gr
{
    [self.view endEditing:YES];
}
#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierNor];
    if (indexPath.row == 0) {
        _cell1 = cell;
        cell.ShopNameLab.text = @"卡类型:";
        cell.ShopNameTF.placeholder = @"输入卡类型";
        cell.ShopNameTF.hidden = NO;
    }else if(indexPath.row == 1){
        _cell2 = cell;
        cell.ShopNameLab.text = @"手机号:";
        cell.ShopNameTF.placeholder = @"请填写此卡银行预留的手机号";
        
    }else{
        UIButton *chooseBtn = [[UIButton alloc] init];
        _chooseBtn = chooseBtn;
        [chooseBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
        [chooseBtn bk_addEventHandler:^(id sender) {
            [self changeAgreeBtn];
        } forControlEvents:UIControlEventTouchUpInside];
        [cell.contentView addSubview:chooseBtn];
        [chooseBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(10);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(20, 20));
        }];
        UILabel *agreeLab = [[UILabel alloc] init];//服务协议
        agreeLab.text = @"同意服务协议";
        agreeLab.font = [UIFont systemFontOfSize:14];
        agreeLab.textColor = bgColor(0, 152, 177);
        [cell.contentView addSubview:agreeLab];
        [agreeLab mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(chooseBtn.mas_right).equalTo(5);
            make.top.equalTo(10);
            make.size.equalTo(CGSizeMake(SCREEN_WIDTH*.8, 20));
        }];
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(endAgree:)];
        agreeLab.userInteractionEnabled = YES;
        tapGR.numberOfTapsRequired=1;
        [agreeLab addGestureRecognizer:tapGR];
    }
    return cell;
}
-(void)endAgree:(UIPanGestureRecognizer*)gr
{
     [WSProgressHUD showSuccessWithStatus:@"服务协议"];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 4;
}

#pragma mark- 点击事件
-(void)changeAgreeBtn
{
    _agreeCount++;
    if (_agreeCount %2 !=0) {//奇数
        [_chooseBtn setImage:[UIImage imageNamed:@"my_checkbox"] forState:UIControlStateNormal];
    }else {
        [_chooseBtn setImage:[UIImage imageNamed:@"my_checkbox1"] forState:UIControlStateNormal];
    }
    
    
}

@end
