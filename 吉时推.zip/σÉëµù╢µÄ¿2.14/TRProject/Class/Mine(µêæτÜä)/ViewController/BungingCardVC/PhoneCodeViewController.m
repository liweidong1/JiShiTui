//
//  PhoneCodeViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PhoneCodeViewController.h"
#import "LoginRegiseterNetworking.h"
@interface PhoneCodeViewController ()
@property(nonatomic,strong)UITextField *codeTF;
@property(nonatomic,strong)UIButton *codeBtn;
@property(nonatomic,strong)SMSModel *smsModel;
@end

@implementation PhoneCodeViewController
- (instancetype)initWithPhoneStr:(NSString *)phoneStr
{
    if (self = [super init]) {
        _phoneStr = phoneStr;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"==%@==",_phoneStr);
    self.navigationItem.title = @"验证码";
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(10, 64+SCREEN_HEIGHT*.2, SCREEN_WIDTH*.2, 30)];
    lab.text = @"手机验证码";
    lab.font = [UIFont systemFontOfSize:14];
    UITextField *codeTF = [[UITextField alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.2+10, 64+SCREEN_HEIGHT*.2, SCREEN_WIDTH*.4, 30)];
    _codeTF = codeTF;
    codeTF.font  = [UIFont systemFontOfSize:14];
    codeTF.backgroundColor = bgColor(245, 245, 245);
    codeTF.placeholder = @"请输入短信验证码";
    UIButton *codeBtn = [[UIButton alloc] initWithFrame:CGRectMake(SCREEN_WIDTH*.6+10, 64+SCREEN_HEIGHT*.2, SCREEN_WIDTH*.3, 30)];
    _codeBtn =codeBtn;
    codeBtn.backgroundColor = bgColor(0, 128, 68);
    codeBtn.font = [UIFont systemFontOfSize:14];
    [codeBtn addTarget:self action:@selector(clickcodeBtn) forControlEvents:UIControlEventTouchUpInside];
    [codeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    [self.view addSubview:lab];
    [self.view addSubview:codeTF];
    [self.view addSubview:codeBtn];
    [self setNextBtn];
    
    [codeBtn startWithTime:59 title:@"获取验证码" countDownTitle:@"s" mainColor:[UIColor colorWithRed:84/255.0 green:180/255.0 blue:98/255.0 alpha:1.0f] countColor:[UIColor lightGrayColor]];
}
-(void)clickcodeBtn
{
    [_codeBtn startWithTime:59 title:@"获取验证码" countDownTitle:@"s" mainColor:[UIColor colorWithRed:84/255.0 green:180/255.0 blue:98/255.0 alpha:1.0f] countColor:[UIColor lightGrayColor]];
    [LoginRegiseterNetworking Phone:_phoneStr SMSCompletionHandler:^(SMSModel *model, NSError *error) {
        _smsModel = model;
        [WSProgressHUD showSuccessWithStatus:model.info];
    }];
}
-(void)setNextBtn
{
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.2, SCREEN_HEIGHT*.5, SCREEN_WIDTH*.6, 40)];
    [btn setTitle:@"确认绑定" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [btn bk_addEventHandler:^(id sender) {
        [WSProgressHUD showSuccessWithStatus:@"确认绑定接口"];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}


@end
