//
//  MeAdChooseViewController.h
//  TRProject
//
//  Created by liweidong on 17/2/13.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MeAdChooseViewController : BaseNSViewController
@property (weak, nonatomic) IBOutlet UITableView *oneTableView;
@property (weak, nonatomic) IBOutlet UITableView *twoTableView;
@property (weak, nonatomic) IBOutlet UITableView *threeTableView;

@end
