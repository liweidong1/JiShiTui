//
//  MeAdChooseViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/13.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeAdChooseViewController.h"
#import "MeNetWorking.h"
#import "MeAdCoordVM.h"
@interface MeAdChooseViewController ()<UITableViewDataSource, UITableViewDelegate>
@property(nonatomic,strong)MeAdCoordVM *adcoordVM;
@end

@implementation MeAdChooseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"广告投放";
    self.oneTableView.delegate = self;
    self.oneTableView.dataSource = self;
    [self.oneTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"oneCELL"];
    self.twoTableView.delegate = self;
    self.twoTableView.dataSource = self;
    [self.twoTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"oneCELL"];
    self.threeTableView.delegate = self;
    self.threeTableView.dataSource = self;
    [self.threeTableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"oneCELL"];
    [self.adcoordVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
        //直接显示不刷新
        [self.oneTableView reloadData];
        [self.twoTableView reloadData];
        [self.threeTableView reloadData];
    }];
}
#pragma  mark --<UITableViewDataSource, UITableViewDelegate>
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.oneTableView) {
        //左边
        NSLog(@"**%ld",[self.adcoordVM OneRowNumber]);
        
        return [self.adcoordVM OneRowNumber];
    }else if(tableView == self.twoTableView){
        return [self.adcoordVM TwoRowNumber];
    }else{
        return [self.adcoordVM ThreeRowNumber];
    }
    
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{   UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"oneCELL"];
    if (tableView == self.oneTableView) {
        //类方法调用类
        cell.textLabel.text = [_adcoordVM OnetableViewText:indexPath.row];
        return cell;
    }else if(tableView == self.twoTableView){
        cell.textLabel.text = [_adcoordVM TwotableViewText:indexPath.row];
        return cell;
    }else{
        cell.textLabel.text = [_adcoordVM ThreetableViewText:indexPath.row];
        return cell;
    }

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == _oneTableView) {
        //点击左侧，右侧tableView刷新
    }
}

- (MeAdCoordVM *)adcoordVM {
	if(_adcoordVM == nil) {
		_adcoordVM = [[MeAdCoordVM alloc] init];
	}
	return _adcoordVM;
}

@end
