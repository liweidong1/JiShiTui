//
//  MeAdViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeAdViewController.h"
#import "YLSOPickerView.h" //一级联动
#import "YLSThPickerView.h"//三级联动
#import "MeNetWorking.h"
#import "BotView.h"
#import "MeAdChooseViewController.h"
#import "ApplyShopCell.h"
#import "MeAdCell.h"
#import "MeAdScrollView.h"
@interface MeAdViewController ()<UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)ApplyShopNormalCell * oneCell;//广告简介
@property(nonatomic,strong)ApplyShopPhotoCell * photoCell;//广告图片
@property(nonatomic,strong)ApplyShopNormalCell * plateCell;//所属板块
@property(nonatomic,strong)ApplyShopNormalCell * coordCell;//所属商圈
@property(nonatomic,strong)MeAdCell * timeCell;//广告投放时间

/**
 *  弹出视图相关
 */
/** array */
@property (nonatomic,strong) NSArray *arrayData;

@end

@implementation MeAdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"广告推广";
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
    [self setTableView];
    [self setBotView];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}

-(void)setBotView
{
    BotView *botView = [[BotView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100)];
    [botView.applyBtn setTitle:@"提交" forState:UIControlStateNormal];
    [botView.ccelBtn setTitle:@"取消" forState:UIControlStateNormal];
    JSTWeakSelf
    botView.applyHandler = ^(){
        [weakSelf clickApplyBtn];
    };
    botView.ccelHandler = ^(){
        [weakSelf clickCcelBtn];
    };
    [self.view addSubview:botView];
}
-(void)clickCcelBtn
{
    [WSProgressHUD showSuccessWithStatus:@"取消"];
}
-(void)clickApplyBtn
{
    [WSProgressHUD showSuccessWithStatus:@"提交"];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[ApplyShopNormalCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerClass:[ApplyShopPhotoCell class] forCellReuseIdentifier:@"photoCell"];
    [self.tableView registerClass:[MeAdCell class] forCellReuseIdentifier:@"adTimeCell"];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"scrollCell"];
//    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 3;
    }else if(section == 1){
        return 4;
    }else {
        return 1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.ShopNameLab.text  = @"广告简介";
            cell.ShopNameTF.placeholder = @"(提示:此简介时展示在广告图上层，限制在10个字以内)";
            return cell;
        }else if(indexPath.row == 1){
            JSTWeakSelf
            ApplyShopPhotoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"photoCell"];
            _photoCell =cell;
            cell.userNameLab.text = @"广告图片";
            cell.userNameGrayLab.text = @"请上传广告图片";
            [cell.photoBtn setImage:[UIImage imageNamed:@"my_addimg"] forState:UIControlStateNormal];
            cell.promptLab.text = @"上传照片";
            cell.photoHandler =^(){
                [weakSelf clickChoosePhoto];
            };
            return cell;
        }else {
            ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.ShopNameLab.text  = @"广告链接地址";
            cell.ShopNameTF.placeholder = @"请输入广告链接地址:http://";
            return cell;
        }
    }else if(indexPath.section == 1){
        if (indexPath.row == 0) {
            ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            _plateCell = cell;
            cell.ShopNameLab.text  = @"所属板块";
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
        }else if(indexPath.row == 1){
            ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.ShopNameLab.text  = @"所属商圈";
            cell.ShopNameTF.text = @"商圈1";
            cell.ShopNameTF.textColor = bgColor(68, 162, 167);
            cell.ShopNameTF.userInteractionEnabled = NO;
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            return cell;
        }else if(indexPath.row == 2){
            //自定义一个滚动视图，显示选择的商家
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"scrollCell"];
            MeAdScrollView *scrollView = [[MeAdScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
            [cell.contentView addSubview:scrollView];
            scrollView.shopLab1.text = @"商家1";
            scrollView.fansLab1.text = @"粉丝数:10";
            scrollView.shopLab2.text = @"商家2";
            scrollView.fansLab2.text = @"粉丝数:21";
            scrollView.shopLab3.text = @"商家3";
            scrollView.fansLab3.text = @"粉丝数:10";
            scrollView.shopLab4.text = @"商家4";
            scrollView.fansLab4.text = @"粉丝数:34";
            scrollView.shopLab5.text = @"商家5";
            scrollView.fansLab5.text = @"粉丝数:10";
            scrollView.shopLab6.text = @"商家6";
            scrollView.fansLab6.text = @"粉丝数:75";
            scrollView.shopLab7.text = @"商家7";
            scrollView.fansLab7.text = @"粉丝数:10";
            scrollView.shopLab8.text = @"商家8";
            scrollView.fansLab8.text = @"粉丝数:42";
            return cell;
        }else{
            MeAdCell *cell = [tableView dequeueReusableCellWithIdentifier:@"adTimeCell"];
            _timeCell = cell;
            cell.adNameLab.text = @"广告投放时间";
            cell.adPlLab.text = @"(不得小于7天)";
            [cell.endBtn setTitle:@"结束于" forState:UIControlStateNormal];
            [cell.startBtn setTitle:@"开始于" forState:UIControlStateNormal];
            cell.startTimeLab.text = @"-年-月-日";
            cell.endTimeLab.text = @"-年-月-日";
            cell.endCeshiLab.backgroundColor = [UIColor clearColor];
            cell.startCeshiLab.backgroundColor = [UIColor clearColor];
            JSTWeakSelf
            cell.setStartHandler = ^(){
                [weakSelf clickSetStartTimeBtn];
            };
            cell.setEndHandler = ^(){
                [weakSelf clickSetEndTimeBtn];
            };

            return cell;
        }
    }else {
         ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.ShopNameLab.text  = @"广告费用合计：";
        cell.ShopNameTF.text = @"￥560";
        cell.ShopNameTF.userInteractionEnabled = NO;
        cell.ShopNameTF.font = [UIFont systemFontOfSize:18];
        cell.ShopNameTF.textColor = bgColor(68, 162, 167);
        return cell;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            //1级联动
            [self clickChooseStyle];//所属板块
        }else if(indexPath.row == 1){
            //进入3级联动页面
            MeAdChooseViewController *chooseVC = [[MeAdChooseViewController alloc]init];
            [self.navigationController pushViewController:chooseVC animated:YES];
        }else if (indexPath.row == 3){
            //本页弹出时间的3级联动
        }
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 1) {
            return 120;
        }else {
            return 44;
        }
    }else if(indexPath.section == 1){
        if(indexPath.row == 2){
            return 100;
        }else {
            return 44;
        }
    }else{
        return 60;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section == 0) {
        return 5;
    }else {
        return 10;
    }
}
//时间选择的3级联动
-(void)clickSetEndTimeBtn
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getEndTime:) name:@"ThreeValues" object:nil];//所在地址
    YLSThPickerView *picker = [[YLSThPickerView alloc]init];
    picker.array = @[@[@"2017",@"2018",@"2019",@"2020",@"2021",@"2022",@"2023",@"2024",@"2025"],@[@"1月",@"2月",@"3月",@"4月",@"5月",@"6月",@"7月",@"8月",@"9月",@"10月",@"11月",@"12月"],@[@"1日",@"2日",@"3日",@"4日",@"5日",@"6日",@"7日",@"8日",@"9日",@"10日",@"11日",@"12日",@"13日",@"14日",@"15日",@"16日",@"17日",@"18日",@"19日",@"20日",@"21日",@"22日",@"23日",@"24日",@"25日",@"26日",@"27日",@"28日",@"29日",@"30日",@"31日"]];
    NSLog(@"%@",picker.array);
    self.arrayData = picker.array;
    [picker show];
}
-(void)getEndTime:(NSNotification *)notification
{
    _timeCell.endTimeLab.text = notification.object;
}


//时间选择的3级联动
-(void)clickSetStartTimeBtn
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getStartTime:) name:@"ThreeValues" object:nil];//所在地址
    YLSThPickerView *picker = [[YLSThPickerView alloc]init];
    picker.array = @[@[@"2017",@"2018",@"2019",@"2020",@"2021",@"2022",@"2023",@"2024",@"2025"],@[@"1月",@"2月",@"3月",@"4月",@"5月",@"6月",@"7月",@"8月",@"9月",@"10月",@"11月",@"12月"],@[@"1日",@"2日",@"3日",@"4日",@"5日",@"6日",@"7日",@"8日",@"9日",@"10日",@"11日",@"12日",@"13日",@"14日",@"15日",@"16日",@"17日",@"18日",@"19日",@"20日",@"21日",@"22日",@"23日",@"24日",@"25日",@"26日",@"27日",@"28日",@"29日",@"30日",@"31日"]];
    NSLog(@"%@",picker.array);
    self.arrayData = picker.array;
    [picker show];
}
-(void)getStartTime:(NSNotification *)notification
{
    _timeCell.startTimeLab.text = notification.object;
}
-(void)clickChooseStyle
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getValue1:) name:@"value" object:nil];//经营方式
    [MeNetWorking getShopStyleCompletionHandler:^(ShopStyleModel *model, NSError *error) {
        NSMutableArray * array = [[NSMutableArray alloc] init];
        for (int i = 0; i<model.type.count; i++) {
            [array addObject:model.type[i].name];
        }
        YLSOPickerView *picker = [[YLSOPickerView alloc]init];
        picker.array = array;
        self.arrayData = picker.array;
        [picker show];
    }];
}
-(void)getValue1:(NSNotification *)notification
{
    _plateCell.ShopNameTF.text = notification.object;
}

-(void)clickChoosePhoto
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];
}
#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    NSData *imageData = nil;
    if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
        _photoCell.ptoto1.image = image;
        imageData = UIImagePNGRepresentation(image);
    }else{
        _photoCell.ptoto1.image = image;
        imageData = UIImageJPEGRepresentation(image, .5);
        
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}

@end
