//
//  MeIssueInfoViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeIssueInfoViewController.h"
#import "MeIssueInfoCell.h"
@interface MeIssueInfoViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;

@end

@implementation MeIssueInfoViewController
static NSString * reuseIdentifier = @"CELL";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的发布";
    [self setTableView];
    [self loadDatas];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerNib:[UINib nibWithNibName:@"MeIssueInfoCell" bundle:nil] forCellReuseIdentifier:reuseIdentifier];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
}
-(void)loadDatas
{
    
    JSTWeakSelf
    [WSProgressHUD showSuccessWithStatus:@"查询服务器数据"];
//    [self.tableView addHeaderRefresh:^{
//        [weakSelf.meOrderVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
//            [weakSelf.tableView reloadData];
//            [weakSelf.tableView endHeaderRefresh];
//        }];
//    }];
//    [self.tableView beginHeaderRefresh];
    
}
#pragma mark - tableView dataSource
//组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 4;
}

//组中行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

//cell内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.row == 0) {
        UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.textLabel.text = @"测试-吉时商圈";
        cell.textLabel.textColor = bgColor(0, 171, 196);
        return cell;
    }else{
        MeIssueInfoCell * cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
        return cell;
    }
    return [UITableViewCell new];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 32;
    }else{
        return 75;
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
   
}

@end
