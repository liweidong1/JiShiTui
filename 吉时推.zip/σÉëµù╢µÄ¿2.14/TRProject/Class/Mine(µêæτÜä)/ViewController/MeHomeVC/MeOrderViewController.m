//
//  MeOrderViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeOrderViewController.h"
#import "MeNetWorking.h"
#import "MeOrderViewModel.h"
#import "SectionHeaderView.h"

#import "jstPayStyleViewController.h"

@interface MeOrderViewController ()
@property(nonatomic,strong)MeOrderViewModel *meOrderVM;
@end

@implementation MeOrderViewController
- (instancetype)initWithMsgType:(NSInteger)childVC{
    if (self = [super init]) {
        _childVC = childVC;
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%ld",_childVC);
    self.view.backgroundColor = [UIColor whiteColor];
    //去掉多余的cell
    self.tableView.tableFooterView = [UIView new];
    //去掉cell之间的分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];

    [self loadDatas];
}
-(void)loadDatas
{
    
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        [weakSelf.meOrderVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView reloadData];
            [weakSelf.tableView endHeaderRefresh];
        }];
    }];
    [self.tableView beginHeaderRefresh];

}
#pragma mark - tableView dataSource
//组数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.meOrderVM MeOrderSectionNumber];
}

//组中行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.meOrderVM numberOfItemsInSection:section];
}

//cell内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self.meOrderVM tableView:tableView cellForRowAtIndexPath:indexPath];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return [self.meOrderVM tableView:tableView heightForRowAtIndexPath:indexPath];
}
//设置头部标题 和尾部视图
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    SectionHeaderView*view1=[[SectionHeaderView alloc]initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 50)];
    //重新定义布局
    [view1.titleLab mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(10);
    }];
    view1.titleLab.text = [self.meOrderVM titleForHeaderInSection:section];
    return view1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 50;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
        //参数id
    if (_childVC == 0) {
        jstPayStyleViewController * jstBVC = [[jstPayStyleViewController alloc]init];
        [self.navigationController pushViewController:jstBVC animated:YES];
    }
}

- (MeOrderViewModel *)meOrderVM {
	if(_meOrderVM == nil) {
		_meOrderVM = [[MeOrderViewModel alloc] initWithUid:1 WithChildVC:_childVC];
	}
	return _meOrderVM;
}

@end
