//
//  MePageViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <WMPageController/WMPageController.h>

@interface MePageViewController : WMPageController

@end
