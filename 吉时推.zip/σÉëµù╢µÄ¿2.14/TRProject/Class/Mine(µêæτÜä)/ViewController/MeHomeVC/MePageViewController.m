//
//  MePageViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MePageViewController.h"
#import "MeOrderViewController.h"
#import "MeNetWorking.h"
@interface MePageViewController ()

@end

@implementation MePageViewController

- (NSArray<NSString *> *)titles{
    return @[@"待付款", @"已付款"];
}
- (NSInteger)numbersOfChildControllersInPageController:(WMPageController *)pageController{
    return self.titles.count;
}
- (__kindof UIViewController *)pageController:(WMPageController *)pageController viewControllerAtIndex:(NSInteger)index{
    
    MeOrderViewController *vc = [[MeOrderViewController alloc] init];
    vc.childVC = index;
    return vc;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的订单";
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}

@end
