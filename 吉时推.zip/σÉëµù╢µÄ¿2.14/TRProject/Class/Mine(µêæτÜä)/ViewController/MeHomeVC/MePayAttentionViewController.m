//
//  MePayAttentionViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/10.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MePayAttentionViewController.h"
#import "PayAttentionCell.h"
#import "MeNetWorking.h"
#import "MePayAttentionProductViewModel.h"
#import "jstBusinessViewController.h"
@interface MePayAttentionViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)MePayAttentionProductViewModel * gzProductVM;
@end

@implementation MePayAttentionViewController
static NSString * reuseIdentifierHeader = @"payHeaderCELL";
static NSString * reuseIdentifierNormal = @"payNormalCELL";

- (instancetype)initWithUid:(NSInteger)uid
{
    if (self = [super init]) {
        _uid = uid;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"关注店铺";
    [self setTableView];
    [self loadDatas];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.gzProductVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];
}

-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerClass:[PayAttentionHeaderCell class] forCellReuseIdentifier:reuseIdentifierHeader];
    [self.tableView registerClass:[PayAttentionNormalCell class] forCellReuseIdentifier:reuseIdentifierNormal];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 2;
    }else {
        //VM数据  +1
        return [self.gzProductVM rowNumber]+1;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.textLabel.text = @"| 已绑定的商铺";
            return cell;
        }else {
            PayAttentionHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierHeader];
           [MeNetWorking getPayAttentionProductWithUid:1 CompletionHandler:^(MePayAttentionProductModel *model, NSError *error) {
                [cell.iv setImageWithURL:model.bind.img.yx_URL placeholder:[UIImage imageNamed:@"my_storelogo"]];
               cell.shopLb.text = model.bind.title;

           }];
            return cell;
        }
    }else {
        if (indexPath.row == 0) {
            UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
            cell.textLabel.text = @"| 我关注的店铺";
            return cell;
        }else {
            PayAttentionNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierNormal];
            
            [cell.iv setImageWithURL:[self.gzProductVM gzProductIconURL:indexPath.row-1] placeholder:[UIImage imageNamed:@"my_storelogo"]];
            cell.shopLb.text = [self.gzProductVM gzProductTitle:indexPath.row-1];
            return cell;
        }
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.tableView deselectRowAtIndexPath:indexPath animated:NO];
    if (indexPath.row != 0) {
        //参数id
        jstBusinessViewController * jstBVC = [[jstBusinessViewController alloc]init];
        [self.navigationController pushViewController:jstBVC animated:YES];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 40;
        }else {
            return 140;
        }
    }else {
        if (indexPath.row == 0) {
            return 40;
        }else {
            return 70;
        }
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 5;
}

- (MePayAttentionProductViewModel *) gzProductVM {
	if(_gzProductVM == nil) {
		_gzProductVM = [[MePayAttentionProductViewModel alloc] init];
	}
	return _gzProductVM;
}

@end
