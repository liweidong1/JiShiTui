//
//  MePersonShopViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MePersonShopViewController.h"
#import "personShopHeaderView.h"
#import "personShopScrollView.h"

#import "PersonIssueShopViewController.h"
#import "PersonProductReviseViewController.h"
#import "PersonWheelPlayViewController.h"
#import "PersonInfoLaunchViewController.h"
#import "PersonFansViewController.h"
#import "PersonIncomeViewController.h"
@interface MePersonShopViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@end

@implementation MePersonShopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的店铺";
    self.view.backgroundColor = [UIColor whiteColor];
    [JSTFactory addBackItemForVC:self isPush:YES];
    [self setTableView];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    self.tableView.tableHeaderView = [[personShopHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.14)];
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    personShopScrollView *scrollView = [[personShopScrollView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.4)];
    [cell.contentView addSubview:scrollView];
    scrollView.navBtn.layer.masksToBounds = YES;
    scrollView.navBtn.layer.cornerRadius = 20;
    JSTWeakSelf
    scrollView.box1HeaderImgHandler = ^(){
        [weakSelf clickOneBox];
    };
    scrollView.box2HeaderImgHandler = ^(){
        [weakSelf clickTwoBox];
    };
    scrollView.box3HeaderImgHandler = ^(){
        [weakSelf clickThreeBox];
    };
    scrollView.box4HeaderImgHandler = ^(){
        [weakSelf clickFourBox];
    };
    scrollView.box5HeaderImgHandler = ^(){
        [weakSelf clickFifBox];
    };
//    scrollView.box6HeaderImgHandler = ^(){
//        [weakSelf clickSixBox];
//    };
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 11;
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return SCREEN_HEIGHT*.4;
}
#pragma 点击盒子事件
-(void)clickSixBox
{
    PersonIncomeViewController *issueVC = [[PersonIncomeViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickFifBox
{
    PersonFansViewController *issueVC = [[PersonFansViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickFourBox
{
    PersonInfoLaunchViewController *issueVC = [[PersonInfoLaunchViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickThreeBox
{
    PersonWheelPlayViewController *issueVC = [[PersonWheelPlayViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickTwoBox
{
     PersonProductReviseViewController*issueVC = [[PersonProductReviseViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickOneBox
{
    PersonIssueShopViewController *issueVC = [[PersonIssueShopViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
@end
