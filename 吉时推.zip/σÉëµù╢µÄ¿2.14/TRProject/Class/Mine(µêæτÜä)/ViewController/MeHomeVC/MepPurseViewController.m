//
//  MepPurseViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/14.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MepPurseViewController.h"

@interface MepPurseViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;


@end
static NSString * reuseIdentifier = @"MeCELL";
@implementation MepPurseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"余额";
    [self setTableView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    //表头
    [self setHeaderView];
}
-(void)setHeaderView
{
    UIView * view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.4)];
    view.backgroundColor = bgColor(0, 176, 199);
    self.tableView.tableHeaderView = view;
    [self loadHeaderDatas];
}
-(void)loadHeaderDatas
{
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        cell.textLabel.text = @"提现";
        return cell;
    }else{
        cell.textLabel.text = @"明细";
        return cell;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        
    }else{
        
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 44;
}

@end
