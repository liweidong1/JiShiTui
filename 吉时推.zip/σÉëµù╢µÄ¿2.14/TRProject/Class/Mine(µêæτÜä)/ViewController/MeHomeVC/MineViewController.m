//
//  MineViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "MineViewController.h"
#import "MeHeaderView.h"
#import "MeNormalCell.h"
#import "ApplyShopViewController.h"
#import "MePageViewController.h"
#import "MeShareViewController.h"
#import "MePayAttentionViewController.h"
#import "MePersonShopViewController.h"
#import "MeAdViewController.h"
#import "MeInfoViewController.h"
#import "jstBusinessViewController.h"
#import "BundingCardViewController.h"//绑定银行卡
#import "MeIssueInfoViewController.h"//我的发布
#import "SettingViewController.h"//设置
#import "MepPurseViewController.h"//余额
@interface MineViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)MeHeaderView *headerView;
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)MeNormalCell * cell;
@end
static NSString * reuseIdentifier = @"MeCELL";
@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setTableView];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    [self.navigationController setNavigationBarHidden:YES animated:NO];
    
    self.tabBarController.tabBar.hidden = NO;
     [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(showBunessView:) name:@"hiddenMineShop" object:nil];
}
-(void)showBunessView:(NSNotification *)notification
{
    //显示商家店铺
    _cell.contentView.hidden = NO;
    _cell.userInteractionEnabled = YES;
    //我要开店 --》 绑定银行卡
    self.headerView.bundingCardBtn.hidden = NO;
    self.headerView.applyShopBtn.hidden = YES;
    self.headerView.applyShopBtn.userInteractionEnabled = NO;
//    [self.headerView.bundingCardBtn bk_addEventHandler:^(id sender) {
//    } forControlEvents:UIControlEventTouchUpInside];
     [self.headerView.bundingCardBtn addTarget:self action:@selector(enterCardVC) forControlEvents:UIControlEventTouchUpInside];
    //进店逛逛 --> 余额
    self.headerView.lab.text = @"余额";
    self.headerView.iv.hidden = YES;
    self.headerView.moneyLab.hidden = NO;
    self.headerView.enterShopBtn.hidden = YES;
    self.headerView.moneyBtn.hidden = NO;
//    [self.headerView.moneyBtn bk_addEventHandler:^(id sender) {
//            } forControlEvents:UIControlEventTouchUpInside];
    [self.headerView.moneyBtn addTarget:self action:@selector(enterPurse) forControlEvents:UIControlEventTouchUpInside];
}
-(void)enterPurse
{
    MepPurseViewController *purseVC = [[MepPurseViewController alloc]init];
    [self.navigationController pushViewController:purseVC animated:YES];
}
-(void)enterCardVC
{
    BundingCardViewController *cardVC = [[BundingCardViewController alloc]init];
    [self.navigationController pushViewController:cardVC animated:YES];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[MeNormalCell class] forCellReuseIdentifier:reuseIdentifier];
     self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    //表头
    [self setHeaderView];
    
}
-(void)setHeaderView
{
    self.headerView = [[MeHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.4)];
    self.tableView.tableHeaderView = self.headerView;
    JSTWeakSelf
    self.headerView.setHandler = ^(){
        [weakSelf clickSetBtn];
    };
    self.headerView.setUserImgHandler = ^(){
        [weakSelf clickUserImg];
    };
    self.headerView.setEnterIssueHandler = ^(){
        [weakSelf clickEnterIssueView];
    };
//    self.headerView.setEnterShopHandler = ^(){
//        [weakSelf clickEnterShopView];
//    };
    [self loadHeaderDatas];
}
-(void)clickEnterIssueView
{
    //参数id
    MeIssueInfoViewController * issueVC = [[MeIssueInfoViewController alloc]init];
    [self.navigationController pushViewController:issueVC animated:YES];
}
-(void)clickEnterShopView
{
    //参数id
    jstBusinessViewController * jstBVC = [[jstBusinessViewController alloc]init];
    [self.navigationController pushViewController:jstBVC animated:YES];
}
-(void)clickUserImg
{
    MeInfoViewController * infoVC = [[MeInfoViewController alloc]init];
    [self.navigationController pushViewController:infoVC animated:YES];
}
-(void)clickApplyShopBtn
{
    [self.navigationController pushViewController:[ApplyShopViewController new] animated:YES];
}
-(void)clickSetBtn
{
    SettingViewController * setVC = [[SettingViewController alloc]init];
    [self.navigationController pushViewController:setVC animated:YES];
}
-(void)loadHeaderDatas
{
    //头部显示固定数据
    self.headerView.userIV.image = [UIImage imageNamed:@"my_user"];
    self.headerView.userLab.text = @"user name";
    //申请店铺点击事件   进入进店逛逛点击事件
    JSTWeakSelf
    [self.headerView.applyShopBtn bk_addEventHandler:^(id sender) {
        [weakSelf clickApplyShopBtn];
    } forControlEvents:UIControlEventTouchUpInside];
    [self.headerView.enterShopBtn bk_addEventHandler:^(id sender) {
        [weakSelf clickEnterShopView];
    } forControlEvents:UIControlEventTouchUpInside];
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 5;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    MeNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    _cell = cell;
    if (indexPath.section == 0) {
        cell.icon.image = [UIImage imageNamed:@"my_order"];
        cell.lab.text = @"我的订单";
        cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        return cell;
    }
    if (indexPath.section == 1) {
        cell.icon.image = [UIImage imageNamed:@"my_share"];
        cell.lab.text = @"邀请分享";
        cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        return cell;
    }
    if (indexPath.section == 2) {
        cell.icon.image = [UIImage imageNamed:@"my_store"];
        cell.lab.text = @"我关注的店铺";
        cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        return cell;
    }
    if (indexPath.section == 3) {
        cell.icon.image = [UIImage imageNamed:@"my_generalize"];
        cell.lab.text = @"广告推广";
        cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        return cell;
    }else{
        cell.icon.image = [UIImage imageNamed:@"my_store"];
        cell.lab.text = @"我的店铺";
        cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        cell.contentView.hidden = YES;
        cell.userInteractionEnabled = NO;
        return cell;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        //传参
        MePageViewController * orderVC = [[MePageViewController alloc]init];
        [self.navigationController pushViewController:orderVC animated:YES];
    }else if (indexPath.section == 1) {
        //传参
        MeShareViewController * shareVC = [[MeShareViewController alloc]init];
        [self.navigationController pushViewController:shareVC animated:YES];
    }else if (indexPath.section == 2) {
        //传参
        MePayAttentionViewController * payattVC = [[MePayAttentionViewController alloc]init];
        [self.navigationController pushViewController:payattVC animated:YES];
    }else if (indexPath.section == 3){
        //传参
        MeAdViewController * adVC = [[MeAdViewController alloc]init];
        [self.navigationController pushViewController:adVC animated:YES];
    }else{
        //传参
        MePersonShopViewController * perVC = [[MePersonShopViewController alloc]init];
        [self.navigationController pushViewController:perVC animated:YES];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 5;
}

@end
