//
//  SettingViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/14.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "SettingViewController.h"
#import "LoginViewController.h"
@interface SettingViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;

@end

@implementation SettingViewController
static NSString * reuseIdentifier = @"MeCELL";
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"设置";
    self.view.backgroundColor = bgColor(245, 245, 245);
    [self setTableView];
    [self setBactOut];
}
-(void)setBactOut
{
    JSTWeakSelf
    UIButton * btn = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*.1, SCREEN_HEIGHT*.8, SCREEN_WIDTH*.8, 40)];
    [btn setTitle:@"退出账号" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [btn bk_addEventHandler:^(id sender) {
        [WSProgressHUD showSuccessWithStatus:@"退出到登录页面"];
        // 切换界面
        LoginViewController * loginVC = [[LoginViewController alloc]init];
        UIWindow *window=[UIApplication sharedApplication].keyWindow;
        window.rootViewController= loginVC;
        
    } forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.7)];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:reuseIdentifier];
    self.tableView.separatorStyle = NO;//隐藏默认横线
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 6;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    if (indexPath.section == 0) {
        cell.textLabel.text = @"账号安全";
        return cell;
    }
    if (indexPath.section == 1) {
        cell.textLabel.text = @"消息管理";
        return cell;
    }
    if (indexPath.section == 2) {
        cell.textLabel.text = @"通用";
        return cell;
    }
    if (indexPath.section == 3) {
        cell.textLabel.text = @"清空缓存";
        return cell;
    }else if(indexPath.section == 4){
        cell.textLabel.text = @"帮助与反馈";
        return cell;
    }else{
        cell.textLabel.text = @"关于";
        return cell;
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
       
    }else if (indexPath.section == 1) {
   
    }else if (indexPath.section == 2) {
  
    }else if (indexPath.section == 3){
   
    }else if (indexPath.section == 4){
    
    }else{
        
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 10;
    }else{
        return 5;
    }
}

@end
