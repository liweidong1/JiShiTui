//
//  PersonFansDetailViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonFansDetailViewController : BaseNSViewController
-(instancetype)initWithFansUid:(NSInteger )fansUid;
@property(nonatomic,readonly) NSInteger fansUid;
@end
