//
//  PersonFansDetailViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonFansDetailViewController.h"
#import "FansDetailHeaderView.h"
#import "FansOrderDetailCell.h"
#import "FansProductDetailCell.h"
#import "FansOrderDetailViewModel.h"
@interface PersonFansDetailViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)FansDetailHeaderView * headerView;
@property(nonatomic,strong)FansOrderDetailViewModel * fansOrderDetailVM;
@property(nonatomic,assign)NSInteger row;
@end

@implementation PersonFansDetailViewController

- (instancetype)initWithFansUid:(NSInteger)fansUid
{
    if (self = [super init]) {
        _fansUid = fansUid;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _row = 1;
    NSLog(@"传入的粉丝的uid：%ld",_fansUid);
    self.navigationItem.title = @"粉丝详情";
     [self setTableView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    [self.tableView registerClass:[FansOrderDetailCell class] forCellReuseIdentifier:@"cellFansOrder"];
     [self.tableView registerClass:[FansProductDetailCell class] forCellReuseIdentifier:@"cellFansProduct"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
   self.headerView = [[FansDetailHeaderView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.3)];
    self.tableView.tableHeaderView = self.headerView;
    [self loadsHeaderData];
    [self loadDatas];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.fansOrderDetailVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];

}
-(void)loadsHeaderData
{
    [MeNetWorking getFansOrderDetailWithFansId:1 Uid:5 CompletionHandler:^(FansOrderProductModel *model, NSError *error) {
        [self.headerView.userImg setImageWithURL:model.user.avatar.yx_URL placeholder:nil];
        self.headerView.userLab.text = model.user.nickname;
        self.headerView.totalCountLab.text = [NSString stringWithFormat:@"%.2f",model.total];
        self.headerView.consumeCountLab.text  = [NSString stringWithFormat:@"%ld",model.count];
        self.headerView.totalCountLab.text = [NSString stringWithFormat:@"%.2f",model.total];
    }];
    self.headerView.userImg.image = [UIImage imageNamed:@"follower_user"];
    
    self.headerView.leftImg.image = [UIImage imageNamed:@"follower_consume"];
    
    self.headerView.consumeNoteLab.text = @"消费记录";
    self.headerView.rightImg.image = [UIImage imageNamed:@"follower_sum"];
    
    self.headerView.totalLab.text = @"消费总额";
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    //订单 +1
    return [self.fansOrderDetailVM rowNumber] +1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //VM数据
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        cell.textLabel.text = @" 时间    总额  -->  cell";
        return cell;
    }
    FansOrderDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellFansOrder"];
    cell.titleLb.text = [NSString stringWithFormat:@"订单编号:%@",[self.fansOrderDetailVM fansOrderName:indexPath.section-1]];
    cell.timeImg.image = [UIImage imageNamed:@"follower_time"];
    cell.timeLb.text = [NSString stringWithFormat:@"交易时间 %@",[self.fansOrderDetailVM fansOrderTime:indexPath.section-1]];
    cell.priceImg.image = [UIImage imageNamed:@"fanlist_wallet"];
    cell.priceLb.text = [NSString stringWithFormat:@"消费金额 ￥%ld",[self.fansOrderDetailVM fansOrderMoney:indexPath.section-1]];
    [cell.orderDetailBtn setImage:[UIImage imageNamed:@"fanlist_up"] forState:UIControlStateNormal];
    [cell setFansOrderDetailClicked:^(FansOrderDetailCell *cell) {
        NSLog(@"VC 获取cell中订单详情按钮点击事件");
        NSIndexPath *ip = [tableView indexPathForCell:cell];
        [self detail:ip.section];

    }];
    //商品详情
    
    return cell;
}
- (void)detail:(NSInteger)row{
    NSLog(@"%ld",row);
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 5;
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {// 时间    总额  -->  cell
        return 40;
    }else {
        return 90;
    }

}


- (FansOrderDetailViewModel *) fansOrderDetailVM {
	if(_fansOrderDetailVM == nil) {
		_fansOrderDetailVM = [[FansOrderDetailViewModel alloc] initWithFansUid:_fansUid];
	}
	return _fansOrderDetailVM;
}

@end
