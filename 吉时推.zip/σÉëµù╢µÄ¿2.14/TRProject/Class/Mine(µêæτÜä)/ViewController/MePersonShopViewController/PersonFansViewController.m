//
//  PersonFansViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonFansViewController.h"
#import "FansCell.h"
#import "PersonFansDetailViewController.h"
#import "FansListViewModel.h"
@interface PersonFansViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)FansListViewModel * fansVM;
@end

@implementation PersonFansViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"粉丝管理";
    [self setTableView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[FansCell class] forCellReuseIdentifier:@"cell"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self loadDatas];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.fansVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];

}
#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //VM数据
    return [self.fansVM rowNumber];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    FansCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    [cell.userImg setImageWithURL:[self.fansVM fansListiconURL:indexPath.row] placeholder:[UIImage imageNamed:@""]];
    cell.titleLb.text = [self.fansVM fansListNickName:indexPath.row];
    cell.phoneImg.image = [UIImage imageNamed:@"follower_phone"];
    cell.phoneLb.text = [self.fansVM fansListPhone:indexPath.row];
    cell.rightIv.image = [UIImage imageNamed:@"odetials_xrig"];
    cell.reviewLb.text = @"查看";
    cell.horiLine.backgroundColor = bgColor(227, 227, 227);
    cell.botClearView.backgroundColor = [UIColor clearColor];
    
    [cell setReViewFansClicked:^(FansCell *cell) {
        NSIndexPath *ip = [tableView indexPathForCell:cell];
        NSLog(@"-------%ld--------",ip.row);
        NSInteger fansUid = [self.fansVM fansListFansUid:ip.row];
        PersonFansDetailViewController * fansDetailVC = [[PersonFansDetailViewController alloc]initWithFansUid:fansUid];
        
        [self.navigationController pushViewController:fansDetailVC animated:YES];
    }];
    
    return cell;
}
//- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
//{
//
//}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

- (FansListViewModel *)fansVM {
	if(_fansVM == nil) {
		_fansVM = [[FansListViewModel alloc] init];
	}
	return _fansVM;
}

@end
