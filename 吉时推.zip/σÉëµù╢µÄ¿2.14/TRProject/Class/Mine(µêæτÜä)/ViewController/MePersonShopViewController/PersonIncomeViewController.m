//
//  PersonIncomeViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonIncomeViewController.h"

@interface PersonIncomeViewController ()

@end

@implementation PersonIncomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"我的收入";

}

@end
