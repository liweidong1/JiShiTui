
//
//  PersonInfoLaunchViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonInfoLaunchViewController.h"
#import "BotView.h"
@interface PersonInfoLaunchViewController ()<UITableViewDelegate,UITableViewDataSource,UITextViewDelegate>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)UITextView * textView;
@property(nonatomic,strong)UILabel * placeHolderLabel;
@end

@implementation PersonInfoLaunchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"消息推送";
    [self setTableView];
    [self setBotView];
}
-(void)setBotView
{
    BotView *botView = [[BotView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100)];
    [botView.applyBtn setTitle:@"发送" forState:UIControlStateNormal];
    [botView.ccelBtn setTitle:@"取消" forState:UIControlStateNormal];
    JSTWeakSelf
    botView.applyHandler = ^(){
        [weakSelf clickApplyBtn];
    };
    botView.ccelHandler = ^(){
        [weakSelf clickCcelBtn];
    };
    [self.view addSubview:botView];
}
-(void)clickCcelBtn
{
    [WSProgressHUD showSuccessWithStatus:@"取消"];
}
-(void)clickApplyBtn
{
    [WSProgressHUD showSuccessWithStatus:@"发送"];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"cell"];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
    UITapGestureRecognizer *tableViewGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(commentTableViewTouchInSide)];
    tableViewGesture.numberOfTapsRequired = 1;
    tableViewGesture.cancelsTouchesInView = NO;
    [self.tableView addGestureRecognizer:tableViewGesture];
}
- (void)commentTableViewTouchInSide{
    [_textView resignFirstResponder];
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (indexPath.section == 0) {
        UITextView * textView = [[UITextView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT*.35)];
        _textView = textView;
        textView.delegate = self;
        textView.backgroundColor = [UIColor clearColor];
        textView.textColor = [UIColor blackColor];
        //占位字符
        UILabel * placeHolderLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH/2, 20)];
        _placeHolderLabel = placeHolderLabel;
        placeHolderLabel.textColor = [UIColor grayColor];
        placeHolderLabel.textAlignment = NSTextAlignmentLeft;
        placeHolderLabel.font = [UIFont systemFontOfSize:15];
        placeHolderLabel.text = @"您有100字可以输入...";
        [textView addSubview:placeHolderLabel];
        [cell.contentView addSubview: textView];
        return cell;
    }else if(indexPath.section == 1){
        UILabel * lab = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 44)];
        lab.text = @"(您所发送的信息粉丝都会收到)";
        lab.textAlignment = NSTextAlignmentCenter;
        [cell.contentView addSubview:lab];
        return cell;
    }else {
        return [UITableViewCell new];
    }
    return [UITableViewCell new];
}
- (void)textViewDidChange:(UITextView *)textView
{
    if (textView.text.length == 0 )
    {
        _placeHolderLabel.text = @"您有100字可以输入...";
    }
    else
    {
        _placeHolderLabel.text = @"";
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return SCREEN_HEIGHT*.35;
    }else if(indexPath.section == 1){
        return 44;
    }else {
        return 0;
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 5;
    }else {
        return 3;
    }

}
@end
