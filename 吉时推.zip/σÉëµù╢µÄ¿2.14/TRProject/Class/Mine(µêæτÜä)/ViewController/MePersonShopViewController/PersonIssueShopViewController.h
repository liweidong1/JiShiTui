//
//  PersonIssueShopViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonIssueShopViewController : BaseNSViewController
-(instancetype)initWithPid:(NSInteger )pid;
@property(nonatomic,readonly) NSInteger pid;
@end
