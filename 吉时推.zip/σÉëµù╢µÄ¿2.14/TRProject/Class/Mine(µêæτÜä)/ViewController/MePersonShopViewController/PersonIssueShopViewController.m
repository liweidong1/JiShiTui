//
//  PersonIssueShopViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonIssueShopViewController.h"
#import "BotView.h"
#import "ProductReviseDetailCell.h"
#import "MeNetWorking.h"


#import "DPPhotoGroupViewController.h"

@interface PersonIssueShopViewController ()<UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIScrollViewDelegate>
@property(nonatomic,strong)UITableView * tableView;

/**
 *  定义全局8个cell,封装加载网络数据
 */
@property(nonatomic,strong)ProductReviseDetailStyleOneCell * oneCell;
@property(nonatomic,strong)ProductReviseDetailStyleTworCell * twoCell;
@property(nonatomic,strong)ProductReviseDetailStyleThreeCell * threeCell;
@property(nonatomic,strong)ProductReviseDetailStyleFourCell * fourCell;
@property(nonatomic,strong)ProductReviseDetailStyleTworCell * fifCell;
@property(nonatomic,strong)ProductReviseDetailStyleFifthCell * sixCell;
@property(nonatomic,strong)ProductReviseDetailStyleFifthCell * sevenCell;
@property(nonatomic,strong)ProductReviseDetailStyleFifthCell * eightCell;

@property(nonatomic,assign)BOOL didPickedImage;

@end

@implementation PersonIssueShopViewController
static NSString * reuseIdentifier = @"cell";
static NSString * reuseIdentifierStyleOne = @"cellOne";
static NSString * reuseIdentifierStyleTwo = @"cellTwo";
static NSString * reuseIdentifierStyleThree = @"cellThree";
static NSString * reuseIdentifierStyleFour = @"cellFour";
static NSString * reuseIdentifierStyleFif = @"cellFif";
- (instancetype)initWithPid:(NSInteger)pid
{
    if (self = [super init]) {
        _pid = pid;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    NSLog(@"%ld",_pid);
    self.navigationItem.title = @"发布商品";
    [self setTableView];
    [self setBotView];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[ProductReviseDetailStyleOneCell class] forCellReuseIdentifier:reuseIdentifierStyleOne];
    [self.tableView registerClass:[ProductReviseDetailStyleTworCell class] forCellReuseIdentifier:reuseIdentifierStyleTwo];
    [self.tableView registerClass:[ProductReviseDetailStyleThreeCell class] forCellReuseIdentifier:reuseIdentifierStyleThree];
    [self.tableView registerClass:[ProductReviseDetailStyleFourCell class] forCellReuseIdentifier:reuseIdentifierStyleFour];
    [self.tableView registerClass:[ProductReviseDetailStyleFifthCell class] forCellReuseIdentifier:reuseIdentifierStyleFif];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
//    [self loadDatas];
}
//-(void)loadDatas
//{
//    _oneCell.productNameTF.text = @"产品名称";
//    _twoCell.productNameTF.text = @"产品标题";
//    _fifCell.productNameTF.text = @"产品详情";
//    _threeCell.productIv.image = [UIImage imageNamed:@"placeholder"];
//    _sixCell.productmoneyTF.text = @"200";
//    _sevenCell.productmoneyTF.text = @"100";
//    _eightCell.productmoneyTF.text = @"3";
//}
-(void)setBotView
{
    BotView *botView = [[BotView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100)];
    [botView.applyBtn setTitle:@"发布" forState:UIControlStateNormal];
    [botView.ccelBtn setTitle:@"取消" forState:UIControlStateNormal];
    JSTWeakSelf
    botView.applyHandler = ^(){
        [weakSelf clickApplyBtn];
    };
    botView.ccelHandler = ^(){
        [weakSelf clickCcelBtn];
    };
    [self.view addSubview:botView];
}
-(void)clickCcelBtn
{
    [WSProgressHUD showSuccessWithStatus:@"取消"];
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)clickApplyBtn
{
    [WSProgressHUD showSuccessWithStatus:@"发布"];
    //修改成功，审核通过
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        ProductReviseDetailStyleOneCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStyleOne];
        _oneCell = cell;
        cell.productNameLab.text = @"产品名称:";
        cell.productNameTF.placeholder = @"请输入您的商品";
        return cell;
    }
    if (indexPath.row == 1 || indexPath.row == 4) {
        ProductReviseDetailStyleTworCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStyleTwo];
        if (indexPath.row == 1) {
            _twoCell = cell;
            cell.productNameLab.text = @"产品标题:";
            cell.promLb.text = @"(20字以内)";
        }else {
            _fifCell = cell;
            cell.productNameTF.text = @"xxxxxxxxxxxx";
            [cell.productNameTF mas_makeConstraints:^(MASConstraintMaker *make) {
                make.height.equalTo(60);
            }];
            cell.productNameLab.text = @"产品详情:";
            cell.promLb.text = @"(限制500字以内rt)";
        }
        return cell;
    }
    if (indexPath.row == 2) {
        ProductReviseDetailStyleThreeCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStyleThree];
        _threeCell = cell;
        cell.productNameLab.text = @"产品展示图:";
        cell.productIv.image = [UIImage imageNamed:@"my_addimg"];
        JSTWeakSelf
        cell.productIvHandler = ^(){
            [weakSelf chooseProductIv];//进入相册选择产品展示图
        };
        return cell;
    }
    if (indexPath.row == 3) {
        JSTWeakSelf
        ProductReviseDetailStyleFourCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStyleFour];
        
        _fourCell = cell;
        cell.productNameLab.text = @"产品多图:";
        [cell.photoBtn setImage:[UIImage imageNamed:@"my_addimg"] forState:UIControlStateNormal];
        cell.photoHandler =^(){
            [weakSelf clickChooseImages];
        };

        return  cell;
    }
    if (indexPath.row == 5 || indexPath.row == 6 || indexPath.row == 7) {
        ProductReviseDetailStyleFifthCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierStyleFif];
        if (indexPath.row == 5) {
            _sixCell = cell;
            cell.productPriceLab.text = @"产品价格:";
            cell.productmoneyTF.text = @"xx";
            cell.unitLab.text = @"元";
        } else if (indexPath.row == 6) {
            _sevenCell = cell;
            cell.productmoneyTF.text = @"xx";
            cell.productPriceLab.text = @"产品折扣后价格:";
            cell.unitLab.text = @"元";
        } else if (indexPath.row == 7) {
            _eightCell = cell;
            cell.productmoneyTF.text = @"xx";
            cell.productPriceLab.text = @"产品库存量:";
            cell.unitLab.text = @"件";
        }
        return cell;
    }
    return [UITableViewCell new];
}
-(void)clickChooseImages
{
    DPPhotoGroupViewController *groupVC = [DPPhotoGroupViewController new];
    groupVC.maxSelectionCount = 9;
    groupVC.delegate = self;
    [self presentViewController:[[UINavigationController alloc] initWithRootViewController:groupVC] animated:YES completion:nil];
}
#pragma mark - ---------------------- DPPhotoGroupViewControllerDelegate
- (void)didSelectPhotos:(NSMutableArray *)photos{
    NSLog(@"--%@--",photos);
    _fourCell.ptoto1.image = photos[0];
    if (photos.count == 2) {
        _fourCell.ptoto1.image = photos[0];
        _fourCell.ptoto2.image = photos[1];
    }
    if (photos.count == 3) {
        _fourCell.ptoto1.image = photos[0];
        _fourCell.ptoto2.image = photos[1];
        _fourCell.ptoto3.image = photos[2];
    }
    if (photos.count == 4) {
        _fourCell.ptoto1.image = photos[0];
        _fourCell.ptoto2.image = photos[1];
        _fourCell.ptoto3.image = photos[2];
        _fourCell.ptoto4.image = photos[3];
    }
    if (photos.count == 5) {
        _fourCell.ptoto1.image = photos[0];
        _fourCell.ptoto2.image = photos[1];
        _fourCell.ptoto3.image = photos[2];
        _fourCell.ptoto4.image = photos[3];
        _fourCell.ptoto5.image = photos[4];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        return 44;
    }else if(indexPath.row == 2 || indexPath.row == 3 || indexPath.row == 4){
        return 90;
    }else {
        return 50;
    }
}


#pragma  mark--进入相册
-(void)chooseProductIv
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];
}
#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
    if(image)
    {
        _threeCell.productIv.image = image;
        self.didPickedImage=YES;
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_oneCell.productNameTF resignFirstResponder];
    [_twoCell.productNameTF resignFirstResponder];
    [_fifCell.productNameTF resignFirstResponder];
    [_sixCell.productmoneyTF resignFirstResponder];
    [_sevenCell.productmoneyTF resignFirstResponder];
    [_eightCell.productmoneyTF resignFirstResponder];
}

@end
