//
//  PersonProductReciseDetailViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonProductReciseDetailViewController : BaseNSViewController
-(instancetype)initWithPid:(NSInteger )pid;
@property(nonatomic,readonly) NSInteger pid;
@end
