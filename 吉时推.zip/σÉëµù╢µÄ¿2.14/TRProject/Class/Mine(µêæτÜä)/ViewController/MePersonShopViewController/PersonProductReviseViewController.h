//
//  PersonProductReviseViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductReviseCell.h"
@interface PersonProductReviseViewController : BaseNSViewController


-(instancetype)initWithUid:(NSInteger )uid;
@property(nonatomic,readonly) NSInteger uid;

@end
