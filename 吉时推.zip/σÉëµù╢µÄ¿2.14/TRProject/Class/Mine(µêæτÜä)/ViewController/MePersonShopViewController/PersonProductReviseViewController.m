//
//  PersonProductReviseViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonProductReviseViewController.h"
#import "ProductReviseCell.h"
#import "ProductReviseListViewModel.h"
#import "PersonProductReciseDetailViewController.h"
@interface PersonProductReviseViewController ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
@property(nonatomic,strong)UICollectionView *collectionView;
@property(nonatomic,strong)ProductReviseListViewModel *productReiseVM;
@end

@implementation PersonProductReviseViewController
- (instancetype)initWithUid:(NSInteger)uid
{
    if (self = [super init]) {
        _uid = uid;
    }
    return self;
}


- (void)viewDidLoad {
    [super viewDidLoad];

    self.navigationItem.title = @"商品修改";
    [self setCollectionView];
}
-(void)setCollectionView
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
//    //设置对齐方式
//    [layout setScrollDirection:UICollectionViewScrollDirectionHorizontal];
    //cell间距
    layout.minimumInteritemSpacing = 5.0f;
    //cell行距
    layout.minimumLineSpacing = 4;
    //collectionViewLunBo = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 20, 320, 200)];
    //需要layout 否则崩溃：UICollectionView must be initialized with a non-nil layout parameter
    self.collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 5, SCREEN_WIDTH, SCREEN_HEIGHT-10) collectionViewLayout:layout];
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
    self.collectionView.collectionViewLayout = layout;
    self.collectionView.pagingEnabled = YES; 
    CGFloat width = (long)((SCREEN_WIDTH - 20) / 4);
    CGFloat height = (SCREEN_WIDTH - 20) / 4 + 30;
    layout.itemSize = CGSizeMake(width, height);
    self.collectionView.backgroundColor = [UIColor whiteColor];
    //注册Cell类，否则崩溃: must register a nib or a class for the identifier or connect a prototype cell in a storyboard
    [self.collectionView registerClass:[ProductReviseCell class] forCellWithReuseIdentifier:@"Cell"];
    [self.view addSubview:self.collectionView];
    //加载网络数据
    [self loadDatas];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.collectionView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.productReiseVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.collectionView endHeaderRefresh];
            [weakSelf.collectionView reloadData];
        }];
    }];
    [self.collectionView beginHeaderRefresh];
//    [self.collectionView addFooterRefresh:^{
//        //获取VM数据
//        [weakSelf.productReiseVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
//            [weakSelf.collectionView endFooterRefresh];
//            [weakSelf.collectionView reloadData];
//        }];
//    }];
    
}

#pragma mark-collectionViewDelegate
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return [self.productReiseVM rowNumber];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    ProductReviseCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Cell" forIndexPath:indexPath];
    //YYWebImage提供的网络图片获取方法
    //参数2:网络图片没有下载完毕之前的默认图.
//    cell.iconIV.image = [UIImage imageNamed:@"my_storelogo"];
    [cell.iconIV setImageWithURL:[self.productReiseVM productReviseListiconURL:indexPath.row] placeholder:[UIImage imageNamed:@""]];
    cell.titleLb.text = [self.productReiseVM productReviseListtitle:indexPath.row];
    return cell;
}
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSInteger pid = [self.productReiseVM productReviseListPid:indexPath.row];
    PersonProductReciseDetailViewController * detailVC = [[PersonProductReciseDetailViewController alloc]initWithPid:pid];
    [self.navigationController pushViewController:detailVC animated:YES];
}
- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    return UIEdgeInsetsMake(5, 4, 5, 4);// top left bottom right  Cell边界范围
}
- (ProductReviseListViewModel *)productReiseVM {
	if(_productReiseVM == nil) {
		_productReiseVM = [[ProductReviseListViewModel alloc] init];
	}
	return _productReiseVM;
}

@end
