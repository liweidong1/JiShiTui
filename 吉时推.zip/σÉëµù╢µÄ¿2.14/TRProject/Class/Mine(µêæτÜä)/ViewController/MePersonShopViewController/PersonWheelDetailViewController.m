//
//  PersonWheelDetailViewController.m
//  TRProject
//
//  Created by liweidong on 17/2/8.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonWheelDetailViewController.h"
#import "WheelAlterCell.h"
#import "MeNetWorking.h"

@interface PersonWheelDetailViewController ()<UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource>

@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)WheelAlterCell * cell1;
@property(nonatomic,strong)WheelAlterCell * cell2;
@property(nonatomic,strong)WheelAlterCell * cell3;
@property(nonatomic,strong)WheelAlterCell * cell4;
@property(nonatomic,strong)WheelAlterCell * cell5;
@property(nonatomic,strong)UIImage * image;
@property(nonatomic,assign)NSInteger rowForImage;//全局row，记录进入相册选取的图片存放在哪个iv上
@property(nonatomic,assign)BOOL didPickedImage;

@end

@implementation PersonWheelDetailViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"店面广告修改";
    [self setTableView];
    [self setBottomViews];
}
-(void)setBottomViews
{
    UIButton * btn = [[UIButton alloc]init];
    [btn setTitle:@"提交" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(0);
        make.height.equalTo(40);
    }];
    JSTWeakSelf
    [btn bk_addEventHandler:^(id sender) {
        [weakSelf submitBtn];
    } forControlEvents:UIControlEventTouchUpInside];
    
}
-(void)submitBtn//提交
{
    if (_rowForImage == 0) {
    //修改广告1
    }else if (_rowForImage == 1) {
    //修改广告2
    }if (_rowForImage == 2) {
    //修改广告3
    }if (_rowForImage == 3) {
    //修改广告4
    }if (_rowForImage == 4) {
    //修改广告5
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSLog(@"%ld",(long)_rowForImage);
    if (_rowForImage == 0) {
        _cell1.adIv.image = _image;
    }else if (_rowForImage == 1) {
        _cell2.adIv.image = _image;
    }if (_rowForImage == 2) {
        _cell3.adIv.image = _image;
    }if (_rowForImage == 3) {
        _cell4.adIv.image = _image;
    }if (_rowForImage == 4) {
        _cell5.adIv.image = _image;
    }
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[WheelAlterCell class] forCellReuseIdentifier:@"CELL"];
    //self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self setLoadDatas];
}
-(void)setLoadDatas
{
    [WSProgressHUD showSuccessWithStatus:@"查询服务器数据"];
    
}
#pragma mark - tableView dataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 5;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    WheelAlterCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CELL"];
    if (indexPath.section == 0) {
        _cell1 = cell;
    }else if (indexPath.section == 1) {
        _cell2 = cell;
    }else if (indexPath.section == 2) {
        _cell3 = cell;
    }else if (indexPath.section == 3) {
        _cell4 = cell;
    }else{
        _cell5 = cell;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    [MeNetWorking AlterShopAdWithUid:1 CompletionHandler:^(AlterShopAdModel *model, NSError *error) {
        for (int i = 0; i<model.ad.count; i++) {
            [cell.adIv setImageWithURL:model.ad[indexPath.row].pic.yx_URL placeholder:[UIImage imageNamed:@"placeholder"]];
            cell.adTF.text = model.ad[indexPath.row].info;
        }
        
    }];
    cell.adIv.image = [UIImage imageNamed:@"header1"];
    cell.adTF.text = @"广告标题内容";
    cell.adAleterIV.image = [UIImage imageNamed:@"my_revise(1)"];
    [cell.adAleterBtn setTitle:@"修改" forState:UIControlStateNormal];
    [cell setAdAleterBtnClicked:^(WheelAlterCell *cell) {
        NSLog(@"VC 获取cell中分享的按钮点击事件");
        NSIndexPath *ip = [tableView indexPathForCell:cell];
        [self alter:ip.section];
    }];
    return cell;
}


- (void)alter:(NSInteger)row
{
    _rowForImage = row;
    NSLog(@"%ld",row);
    if (row == 0) {
        _cell1.adTF.userInteractionEnabled = YES;
        _cell1.adIv.userInteractionEnabled = YES;
        [_cell1.adTF becomeFirstResponder];

         [_cell1.adAleterBtn setTitle:@"修改..." forState:UIControlStateNormal];
        _cell2.adTF.userInteractionEnabled = NO;
        _cell2.adIv.userInteractionEnabled = NO;
        _cell3.adTF.userInteractionEnabled = NO;
        _cell3.adIv.userInteractionEnabled = NO;
        _cell4.adTF.userInteractionEnabled = NO;
        _cell4.adIv.userInteractionEnabled = NO;
        _cell5.adTF.userInteractionEnabled = NO;
        _cell5.adIv.userInteractionEnabled = NO;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_cell1.adIv addGestureRecognizer:tapGR];
    }else if(row == 1){
        _cell2.adTF.userInteractionEnabled = YES;
        _cell2.adIv.userInteractionEnabled = YES;
        [_cell2.adTF becomeFirstResponder];
        _cell1.adTF.userInteractionEnabled = NO;
        _cell1.adIv.userInteractionEnabled = NO;
        _cell3.adTF.userInteractionEnabled = NO;
        _cell3.adIv.userInteractionEnabled = NO;
        _cell4.adTF.userInteractionEnabled = NO;
        _cell4.adIv.userInteractionEnabled = NO;
        _cell5.adTF.userInteractionEnabled = NO;
        _cell5.adIv.userInteractionEnabled = NO;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_cell2.adIv addGestureRecognizer:tapGR];
    }
    else if(row == 2){
        _cell3.adTF.userInteractionEnabled = YES;
        _cell3.adIv.userInteractionEnabled = YES;
        [_cell3.adTF becomeFirstResponder];
        _cell1.adTF.userInteractionEnabled = NO;
        _cell1.adIv.userInteractionEnabled = NO;
        _cell2.adTF.userInteractionEnabled = NO;
        _cell2.adIv.userInteractionEnabled = NO;
        _cell4.adTF.userInteractionEnabled = NO;
        _cell4.adIv.userInteractionEnabled = NO;
        _cell5.adTF.userInteractionEnabled = NO;
        _cell5.adIv.userInteractionEnabled = NO;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_cell3.adIv addGestureRecognizer:tapGR];
    }
    else if(row == 3){
        _cell4.adTF.userInteractionEnabled = YES;
        _cell4.adIv.userInteractionEnabled = YES;
        [_cell4.adTF becomeFirstResponder];
        _cell2.adTF.userInteractionEnabled = NO;
        _cell2.adIv.userInteractionEnabled = NO;
        _cell3.adTF.userInteractionEnabled = NO;
        _cell3.adIv.userInteractionEnabled = NO;
        _cell1.adTF.userInteractionEnabled = NO;
        _cell1.adIv.userInteractionEnabled = NO;
        _cell5.adTF.userInteractionEnabled = NO;
        _cell5.adIv.userInteractionEnabled = NO;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_cell4.adIv addGestureRecognizer:tapGR];
    }else{
        _cell5.adTF.userInteractionEnabled = YES;
        _cell5.adIv.userInteractionEnabled = YES;
        [_cell5.adTF becomeFirstResponder];
        _cell2.adTF.userInteractionEnabled = NO;
        _cell2.adIv.userInteractionEnabled = NO;
        _cell3.adTF.userInteractionEnabled = NO;
        _cell3.adIv.userInteractionEnabled = NO;
        _cell4.adTF.userInteractionEnabled = NO;
        _cell4.adIv.userInteractionEnabled = NO;
        _cell1.adTF.userInteractionEnabled = NO;
        _cell1.adIv.userInteractionEnabled = NO;
        UITapGestureRecognizer* tapGR=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(start:)];
        tapGR.numberOfTapsRequired=1;
        [_cell5.adIv addGestureRecognizer:tapGR];

    }
    
}
-(void)start:(UIPanGestureRecognizer*)gr
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];

}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    _image = image;
    NSData *imageData = nil;
    if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
        //_twoCell.ptoto1.image = image;
        imageData = UIImagePNGRepresentation(image);
    }else{
        //_twoCell.ptoto1.image = image;
        imageData = UIImageJPEGRepresentation(image, .5);
        
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_cell1.adTF resignFirstResponder];
    [_cell2.adTF resignFirstResponder];
    [_cell3.adTF resignFirstResponder];
    [_cell4.adTF resignFirstResponder];
    [_cell5.adTF resignFirstResponder];
}

@end
