//
//  PersonWheelPlayViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "PersonWheelPlayViewController.h"
#import "YLSOPickerView.h" //一级联动
#import "YLSThPickerView.h"//三级联动
#import "MeNetWorking.h"
#import "BotView.h"

#import "ApplyShopCell.h"
#import "ProductReviseDetailCell.h"
#import "PersonWheelDetailViewController.h"
@interface PersonWheelPlayViewController ()<UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)ApplyShopNormalCell * oneCell;//店铺名称
@property(nonatomic,strong)ApplyShopPhotoCell * twoCell;//店铺logo
@property(nonatomic,strong)ProductReviseDetailStyleTworCell * threeCell;//店铺公告
@property(nonatomic,strong)ApplyShopNormalCell * fourCell;//店铺轮播图

@property(nonatomic,strong)ApplyShopNormalCell * fifCell;//联系人
@property(nonatomic,strong)ApplyShopNormalCell * sixCell;//联系方式
@property(nonatomic,strong)ApplyShopNormalCell * sevenCell;//所在地址
@property(nonatomic,strong)ApplyShopNormalCell * eightCell;//详细地址
@property(nonatomic,strong)ApplyShopNormalCell * nineCell;//邮编地址
@property(nonatomic,strong)ApplyShopNormalCell * tenCell;//经营类别
@property(nonatomic,assign)BOOL didPickedImage;
/**
 *  弹出视图相关
 */
/** array */
@property (nonatomic,strong) NSArray *arrayData;
@end

@implementation PersonWheelPlayViewController
static NSString * reuseIdentifierOne = @"MeONECELL";//普通cell
static NSString * reuseIdentifiertwo = @"MeTWOCELL";//店铺logo
static NSString * reuseIdentifierthree = @"MeTHREECELL";//店铺公告
- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"店铺管理";
    [self setTableView];
    [self setBottomViews];
}
-(void)setBottomViews
{
    BotView *botView = [[BotView alloc]initWithFrame:CGRectMake(0, SCREEN_HEIGHT-100, SCREEN_WIDTH, 100)];
    [botView.applyBtn setTitle:@"提交" forState:UIControlStateNormal];
    [botView.ccelBtn setTitle:@"取消" forState:UIControlStateNormal];
    JSTWeakSelf
    botView.applyHandler = ^(){
        [weakSelf clickApplyBtn];
    };
    botView.ccelHandler = ^(){
        [weakSelf clickCcelBtn];
    };
    [self.view addSubview:botView];
}
-(void)clickCcelBtn
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)clickApplyBtn
{
    [WSProgressHUD showSuccessWithStatus:@"发送开店请求"];
    //如果开店审核通过，则pop我的主页面
    [[NSNotificationCenter defaultCenter]postNotificationName:@"hiddenMineShop" object:nil];
    
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)submitBtn//提交
{
    [WSProgressHUD showSuccessWithStatus:@"提交接口"];
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    
    [self.tableView registerClass:[ApplyShopNormalCell class] forCellReuseIdentifier:reuseIdentifierOne];
    [self.tableView registerClass:[ApplyShopPhotoCell class] forCellReuseIdentifier:reuseIdentifiertwo];
    [self.tableView registerClass:[ProductReviseDetailStyleTworCell class] forCellReuseIdentifier:reuseIdentifierthree];
    //self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.view addSubview:self.tableView];
    [self setLoadDatas];
}
-(void)setLoadDatas
{
    [WSProgressHUD showSuccessWithStatus:@"查询服务器数据"];
}
#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 10;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierOne];
    cell.textLabel.text = @"测试";
    if (indexPath.row == 1) {
        JSTWeakSelf
        ApplyShopPhotoCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifiertwo];
        _twoCell = cell;
        cell.userNameLab.text = @"店铺logo:";
        cell.userNameGrayLab.text = @"请上传您的店铺logo";
        [cell.photoBtn setImage:[UIImage imageNamed:@"my_addimg"] forState:UIControlStateNormal];
        cell.promptLab.text = @"上传照片";
        cell.photoHandler =^(){
            [weakSelf clickChoosePhoto];
        };
        return cell;
    }else if(indexPath.row == 2){
        ProductReviseDetailStyleTworCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierthree];
        _threeCell = cell;
        cell.productNameTF.text = @"xxxxxxx";
        [cell.productNameTF mas_makeConstraints:^(MASConstraintMaker *make) {
            make.height.equalTo(60);
        }];
        cell.productNameLab.text = @"店铺公告:";
        cell.productNameLab.textColor = [UIColor blackColor];
        cell.promLb.text = @"(0/50)";
        return cell;
        
    }else{
        ApplyShopNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierOne];
        if (indexPath.row == 0) {
            _oneCell = cell;
            cell.ShopNameLab.text = @"店铺名称:";
            cell.ShopNameTF.placeholder = @"(请输入您的店铺名称)";
        }else if(indexPath.row == 3){
            _fourCell = cell;
            cell.ShopNameLab.text = @"店铺轮播图:";
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        }else if(indexPath.row == 4){
            _fifCell = cell;
            cell.ShopNameLab.text = @"联系人:";
            cell.ShopNameTF.placeholder = @"(请填写您的真实姓名)";
        }else if(indexPath.row == 5){
            _sixCell = cell;
            cell.ShopNameLab.text = @"联系方式:";
            cell.ShopNameTF.placeholder = @"(请填写您的联系方式)";
        }else if(indexPath.row == 6){
            _sevenCell = cell;
            cell.ShopNameLab.text = @"所在地址:";
            
            cell.rightIv.hidden = NO;
            cell.ShopNameTF.placeholder = @"(请选择您的所在区域)";
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        }else if(indexPath.row == 7){
            _eightCell  = cell;
            cell.ShopNameLab.text = @"详细地址:";
            cell.ShopNameTF.placeholder = @"(请填写您真实有效的联系地址)";
        }else if(indexPath.row == 8){
            _nineCell = cell;
            cell.ShopNameLab.text = @"邮编:";
            cell.ShopNameTF.placeholder = @"(请填写您真实有效的邮编)";
        }else if(indexPath.row == 9){
            _tenCell = cell;
            cell.ShopNameLab.text = @"经营类别:";
            cell.ShopNameTF.userInteractionEnabled = NO;
            cell.rightIv.hidden = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
        }
        return  cell;
    }
    return [UITableViewCell new];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    if (indexPath.row == 3) {
        PersonWheelDetailViewController *wheelVC = [[PersonWheelDetailViewController alloc]init];
        [self.navigationController pushViewController:wheelVC animated:YES];
    }else if (indexPath.row == 6){
        [self clickChooseAddr];
    }
    if (indexPath.row ==9) {
        
        [self clickChooseStyle];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 1) {
        return 100;
    }else if (indexPath.row == 2){
        return 68;
    }else{
        return 40;
    }
}
-(void)clickChooseAddr
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getThreeValue:) name:@"ThreeValues" object:nil];//所在地址
    NSMutableArray * arrayProvince = [[NSMutableArray alloc] init];
    NSMutableArray * arrayCity = [[NSMutableArray alloc] init];
    NSMutableArray * arrayArea = [[NSMutableArray alloc] init];
    [MeNetWorking getPersonInfoChooseCityCompletionHandler:^(MeInfoModel *model, NSError *error) {
        for (int i = 0; i<model.city.province.count; i++) {
            [arrayProvince addObject:model.city.province[i].name];
        }
        for (int i = 0; i<model.city.city.count; i++) {
            [arrayCity addObject:model.city.city[i].name];
        }
        for (int i = 0; i<model.city.area.count; i++) {
            [arrayArea addObject:model.city.area[i].name];
        }
        
        YLSThPickerView *picker = [[YLSThPickerView alloc]init];
        picker.array = @[arrayProvince,arrayCity,arrayArea];
        self.arrayData = picker.array;
        [picker show];
    }];
    
}
-(void)clickChooseStyle
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getValue1:) name:@"value" object:nil];//经营方式
    [MeNetWorking getShopStyleCompletionHandler:^(ShopStyleModel *model, NSError *error) {
        NSMutableArray * array = [[NSMutableArray alloc] init];
        for (int i = 0; i<model.type.count; i++) {
            [array addObject:model.type[i].name];
        }
        YLSOPickerView *picker = [[YLSOPickerView alloc]init];
        picker.array = array;
        self.arrayData = picker.array;
        [picker show];
    }];
    //    YLSOPickerView *picker = [[YLSOPickerView alloc]init];
    //    picker.array = @[@"iPhone4",@"iPhone4S",@"iPhone5",@"iPhone5S",@"iPhone5C",@"iPhone6",@"iPhone6Plus",@"iPhone6S",@"iPhone6SPlus"];
    //    self.arrayData = picker.array;
    //    [picker show];
    
}
-(void)getValue1:(NSNotification *)notification
{
    _tenCell.ShopNameTF.text = notification.object;
}
-(void)getThreeValue:(NSNotification *)notification
{
    _sevenCell.ShopNameTF.text = notification.object;
}
-(void)clickChoosePhoto
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];
}
#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    NSData *imageData = nil;
    if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
        _twoCell.ptoto1.image = image;
        imageData = UIImagePNGRepresentation(image);
    }else{
        _twoCell.ptoto1.image = image;
        imageData = UIImageJPEGRepresentation(image, .5);
        
    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [_oneCell.ShopNameTF resignFirstResponder];
    [_threeCell.productNameTF resignFirstResponder];
    [_fifCell.ShopNameTF resignFirstResponder];
    [_sixCell.ShopNameTF resignFirstResponder];
    [_sevenCell.ShopNameTF resignFirstResponder];
    [_eightCell.ShopNameTF resignFirstResponder];
    [_nineCell.ShopNameTF resignFirstResponder];
}

@end
