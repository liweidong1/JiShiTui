//
//  MeInfoBindingViewController.h
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void(^BLOCK)(NSString*);
@interface MeInfoBindingViewController : BaseNSViewController
@property (nonatomic, strong)BLOCK block;
@end
