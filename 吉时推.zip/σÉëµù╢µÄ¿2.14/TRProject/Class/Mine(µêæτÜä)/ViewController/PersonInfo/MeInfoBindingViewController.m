//
//  MeInfoBindingViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeInfoBindingViewController.h"
#import "BindingCell.h"
#import "BundingViewModel.h"
@interface MeInfoBindingViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)BundingViewModel *bundingVM;
@property(nonatomic,strong)NSString *lat;
@property(nonatomic,strong)NSString *lng;
@end

@implementation MeInfoBindingViewController
static NSString * reuseIdentifier = @"MeBindingCELL";
- (void)viewDidLoad {
    [super viewDidLoad];
    [JSTFactory addSearchItemForVC:self clickedHandler:^{
        [WSProgressHUD showSuccessWithStatus:@"搜索"];
    }];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationItem.title = @"商家绑定";
    
    [self setTableView];
    
    //接收主视图定位通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(latLng:) name:@"EnterMeView" object:nil];
}
-(void)latLng:(NSNotification *)notification
{
    //获取通知的参数
    _lat = notification.userInfo[@"Latitude"];
    _lng  = notification.userInfo[@"Lngutude"];
    NSLog(@"%@-%@",_lat,_lng);
}

-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[BindingCell class] forCellReuseIdentifier:reuseIdentifier];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self loadDatas];
}
-(void)loadDatas
{
    JSTWeakSelf
    [self.tableView addHeaderRefresh:^{
        //获取VM数据
        [weakSelf.bundingVM getDataWithMode:RequestModeRefresh completionHandler:^(NSError *error) {
            [weakSelf.tableView endHeaderRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    [self.tableView beginHeaderRefresh];
    [self.tableView addFooterRefresh:^{
        //获取VM数据
        [weakSelf.bundingVM getDataWithMode:RequestModeMore completionHandler:^(NSError *error) {
            [weakSelf.tableView endFooterRefresh];
            [weakSelf.tableView reloadData];
        }];
    }];
    
}

#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.bundingVM rowNumber];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
        BindingCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
//    cell.iv.image = [UIImage imageNamed:@"header1"];
//    cell.titleLb.text = @"新东方(水清木华校区)";
//    cell.countLab.text = @"59";
    cell.loveIv.image = [UIImage imageNamed:@"store_laud1"];
//    cell.gRateLab.text = @"好评率 90%";
//    cell.distanceLab.text = @"大约1000m";
//    cell.descLab.text = @"假装此处就是商家介绍，假装此处就是商家介绍，加转此处就是商家介绍假装此处就是商家介绍，假装此处就是商家介绍xx假装此处就是商家介绍";
    [cell.iv setImageWithURL:[self.bundingVM bundingiconURL:indexPath.row] placeholder:[UIImage imageNamed:@""]];
    cell.titleLb.text = [self.bundingVM bundingtitle:indexPath.row];
    cell.countLab.text = [self.bundingVM bundingBd:indexPath.row];
    cell.distanceLab.text = [self.bundingVM bundingdistance:indexPath.row];
    cell.descLab.text = [self.bundingVM bundingdesc:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //方法1 发送通知、
    NSString *sidStr = [self.bundingVM bundingSid:indexPath.row];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"BUNDSID" object:self userInfo:@{@"BnudingSid" : sidStr}];
    //方法2 block
    NSString *text = [self.bundingVM bundingtitle:indexPath.row];
    //把要传出值 通过参数 传出去
    self.block(text);
    
    [self.navigationController popViewControllerAnimated:NO];
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}

- (BundingViewModel *) bundingVM {
	if(_bundingVM == nil) {
#pragma 此处需要修改
		_bundingVM = [[BundingViewModel alloc] initWithlngLat:@"40.073702" AndLng:@"116.31077"];
	}
	return _bundingVM;
}

@end
