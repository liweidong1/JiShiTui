//
//  MeInfoViewController.m
//  TRProject
//
//  Created by liweidong on 17/1/16.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeInfoViewController.h"
#import "MeInfoCell.h"
#import "MeInfoBindingViewController.h"
#import "YLSThPickerView.h"
#import "MeNetWorking.h"
#import "PickerModel.h"
@interface MeInfoViewController ()<UITableViewDelegate,UITableViewDataSource,UIActionSheetDelegate,UINavigationControllerDelegate,UIImagePickerControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource>
@property(nonatomic,strong)UITableView * tableView;
@property(nonatomic,strong)MeInfoOneCell * infoOneCell;  //行1
@property(nonatomic,strong)MeInfoTwoCell * infoTwoCell;
@property(nonatomic,strong)MeInfoNormalCell * infoThreeCell;
@property(nonatomic,strong)MeInfoNormalCell * infoFourCell;
@property(nonatomic,strong)MeInfoNormalCell * infoFifCell;
//性别
@property(nonatomic,strong)MeInfoSexCell * infoSexCell;//行6
//地址
@property(nonatomic,strong)MeInfoNormalCell *addrCell;//行7
@property(nonatomic,strong)MeInfoNormalCell * infoEightCell;
@property(nonatomic,strong)MeInfoNormalCell * infoNineCell;


@property(nonatomic,assign)BOOL didPickedImage;
@property(nonatomic,assign)int countMan;
@property(nonatomic,assign)int countWomen;


/**
 *  弹出视图相关
 */
/** array */
@property (nonatomic,strong) NSArray *arrayData;

@end

@implementation MeInfoViewController
static NSString * reuseIdentifierOne = @"MeOneCELL";
static NSString * reuseIdentifierTwo = @"MeTwoCELL";
static NSString * reuseIdentifierSex = @"MeSexCELL";
static NSString * reuseIdentifierNormal = @"MeNormalCELL";

- (void)viewDidLoad {
    [super viewDidLoad];
    [JSTFactory addBackItemForVC:self isPush:YES];
    self.tabBarController.tabBar.hidden = YES;
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"个人资料";
    
    [self setTableView];
    [self setBottomViews];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.tabBarController.tabBar.hidden = YES;
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.barStyle = UIBarStyleDefault;
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    
}
-(void)setTableView
{
    self.tableView = [[UITableView alloc]initWithFrame:self.view.frame];
    [self.tableView registerClass:[MeInfoOneCell class] forCellReuseIdentifier:reuseIdentifierOne];
    [self.tableView registerClass:[MeInfoTwoCell class] forCellReuseIdentifier:reuseIdentifierTwo];
    [self.tableView registerClass:[MeInfoSexCell class] forCellReuseIdentifier:reuseIdentifierSex];
    [self.tableView registerClass:[MeInfoNormalCell class] forCellReuseIdentifier:reuseIdentifierNormal];
    self.tableView.scrollEnabled =NO; //设置tableview 不能滚动
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    [self setLoadDatas];
}
-(void)setLoadDatas
{
    //个人信息
    [MeNetWorking getPersonInfoWithUid:1 CompletionHandler:^(MeShowInfoModel *model, NSError *error) {
        [_infoOneCell.rightIv setImageWithURL:model.details.avatar.yx_URL placeholder:[UIImage imageNamed:@""]];
        _infoTwoCell.infoTF.text = model.details.nickname;
        _infoThreeCell.infoTF.text =  model.details.name;
        _infoFourCell.infoTF.text =  model.details.phone;
        _infoFifCell.infoTF.text =  model.details.email;
         _addrCell.infoTF.text = [NSString stringWithFormat:@"%@,%@,%@",model.details.province,model.details.city,model.details.area];
        _infoEightCell.infoTF.text =  model.details.addr;
        _infoNineCell.infoTF.text =  model.details.title;
        [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
        [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
        
        if ([model.details.sex isEqualToString:@"1"]) {
            [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio1"] forState:UIControlStateNormal];
            [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
        }else {
            [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
            [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio1"] forState:UIControlStateNormal];
        }
    }];
}
-(void)setBottomViews
{
    UIButton * btn = [[UIButton alloc]init];
    [btn setTitle:@"提交" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    btn.backgroundColor = bgColor(0, 177, 200);
    [self.view addSubview:btn];
    [btn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.bottom.right.equalTo(0);
        make.height.equalTo(40);
    }];
    JSTWeakSelf
    [btn bk_addEventHandler:^(id sender) {
        [weakSelf submitBtn];
    } forControlEvents:UIControlEventTouchUpInside];
}
-(void)submitBtn//提交
{
        NSLog(@"%@",_infoOneCell.rightIv.image);

        NSData *imageData = UIImageJPEGRepresentation(_infoOneCell.rightIv.image, .5);
        //NSData *imageData = UIImagePNGRepresentation(_infoOneCell.rightIv.image);

//    NSURL *imageURL = [NSURL URLWithString:@"http://pic31.nipic.com/20130713/7447430_161806835000_2.jpg"];
//    NSData *imageData = [NSData dataWithContentsOfURL:imageURL];

    NSMutableDictionary *params = [NSMutableDictionary new];
    [params setObject:@"1" forKey:@"uid"];//后期许取登录用户的uid
    [params setObject:_infoThreeCell.infoTF.text forKey:@"name"];
    [params setObject:_infoTwoCell.infoTF.text forKey:@"nickname"];
    [params setObject:_infoFourCell.infoTF.text forKey:@"phone"];
    [params setObject:_infoFifCell.infoTF.text forKey:@"email"];
    [params setObject:@"1" forKey:@"sex"];
   [params setObject:_addrCell.infoTF.text forKey:@"area"];//三级联动，拼接
    [params setObject:_infoEightCell.infoTF.text forKey:@"addr"];
    
//    NSDictionary *parameters =@{@"uid":@"1",@"name":@"薛文举"};
    [MeNetWorking getPersonInfoUpDateWithParameters:params Data:imageData ParmsKey:@"avatar" CompletionHandler:^(testModel *model, NSError *error) {
        [WSProgressHUD showSuccessWithStatus:@"提交成功"];
    [self.tableView reloadData];
    }];
    [self.tableView reloadData];
}
#pragma mark - tableView dataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 9;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    JSTWeakSelf
    if (indexPath.row == 0) {
    MeInfoOneCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierOne];
        _infoOneCell = cell;
        cell.leftLab.text = @"头像:";
        cell.plcLab.text = @"(可修改)";
        cell.styleHeaderImgHandler =^(){
            [weakSelf clickImg];
        };

        return cell;
    }else if(indexPath.row == 1){
    MeInfoTwoCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierTwo];
        _infoTwoCell = cell;
        cell.leftLab.text = @"昵称:";
        return cell;
    }else if(indexPath.row == 5){
    MeInfoSexCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierSex];
        _infoSexCell = cell;
        cell.leftLab.text = @"性别:";
        cell.noLab.text = @"男";
        cell.weixinLab.text = @"女";
        
        cell.noChooseHandler =^(){
            [weakSelf clickMan];
        };
        cell.weixinChooseHandler =^(){
            [weakSelf clickWomen];
        };

        return cell;
    }else {
    MeInfoNormalCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifierNormal];
        if (indexPath.row == 2) {
            _infoThreeCell = cell;
            cell.leftLab.text = @"真实姓名:";
            return cell;
        }else if(indexPath.row == 3){
            _infoFourCell = cell;
            cell.leftLab.text = @"手机号:";
            cell.infoTF.placeholder =  @"(请输入您11位手机号)";
            return cell;
        }else if(indexPath.row == 4){
            _infoFifCell = cell;
            cell.leftLab.text = @"邮箱:";
            cell.infoTF.placeholder =  @"(请输入您的邮箱)";
            return cell;
        }else if(indexPath.row == 6){
            _addrCell = cell;
            cell.leftLab.text = @"所在地址:";
            cell.infoTF.userInteractionEnabled = NO;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            cell.rightIv.hidden = NO;
            return cell;
        }else if(indexPath.row == 7){
            _infoEightCell = cell;
            cell.leftLab.text = @"详细地址:";
            cell.infoTF.placeholder =  @"(请填写详细地址)";
            return cell;
        }else if(indexPath.row == 8){
            _infoNineCell = cell;
            cell.leftLab.text = @"绑定商家:";
            cell.infoTF.userInteractionEnabled = NO;
            cell.infoTF.font = [UIFont systemFontOfSize:16];
            cell.rightIv.hidden = YES;
            cell.rightIv.image = [UIImage imageNamed:@"my_right"];
            cell.infoTF.placeholder =  @"(为了您更好的享受优惠请绑定一个商家)";
            return cell;
        }
    }
    return [UITableViewCell new];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self.view endEditing:YES];
    
  if(indexPath.row == 6){
          [self clickChooseAddr];
    }
}
//设置行高
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}
#pragma mark- 点击事件   
-(void)clickMan
{
    _countMan++;
    if (_countMan %2 != 0) {
        [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio1"] forState:UIControlStateNormal];
    }else {
        [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
    }
    [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
    
}
-(void)clickWomen
{
    _countWomen++;
    if (_countWomen %2 != 0) {
        [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio1"] forState:UIControlStateNormal];
    }else{
        [_infoSexCell.wexinBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
    }
    [_infoSexCell.noBtn setImage:[UIImage imageNamed:@"my_radio"] forState:UIControlStateNormal];
}
-(void)clickImg
{
    UIActionSheet *sheet=[[UIActionSheet alloc]initWithTitle:@"请选择照片来源" delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"相机",@"相册",nil];
    [sheet showInView:self.view];
}
#pragma mark - UIActionSheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    UIImagePickerController *picker=[[UIImagePickerController alloc]init];
    switch (buttonIndex) {
        case 0:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera])
            {
                [self showAlertWithTitle:@"提示" descString:@"相机不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypeCamera;
            picker.cameraCaptureMode=UIImagePickerControllerCameraCaptureModePhoto;
            picker.allowsEditing=YES;
            picker.showsCameraControls=YES;
            picker.delegate=self;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        case 1:
        {
            if(![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypePhotoLibrary])
            {
                [self showAlertWithTitle:@"提示" descString:@"相册不可用"];
                return;
            }
            picker.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
            picker.delegate=self;
            picker.allowsEditing=YES;
            if(picker)
                [self presentViewController:picker animated:YES completion:nil];
            break;
        }
        default:
            break;
    }
    
}
#pragma mark - UIImagePicker
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{

//    UIImage *image=[info objectForKey:UIImagePickerControllerEditedImage];
//    NSData *imageData = [[NSData alloc]init];
//    _imageData = imageData;
//        if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
//            _infoOneCell.rightIv.image = image;
//            imageData = UIImagePNGRepresentation(image);
//                NSLog(@"%@",_imageData);
//        }else{
//            _infoOneCell.rightIv.image = image;
//            imageData = UIImageJPEGRepresentation(image, .5);
//            
//         NSLog(@"%@",_imageData);
//        }
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    NSData *imageData = nil;
    if ([[info[UIImagePickerControllerReferenceURL] description] hasSuffix:@"PNG"]) {
        _infoOneCell.rightIv.image = image;
        imageData = UIImagePNGRepresentation(image);
    }else{
        _infoOneCell.rightIv.image = image;
        imageData = UIImageJPEGRepresentation(image, .5);

    }
    [picker dismissViewControllerAnimated:YES completion:nil];
}
-(void)showAlertWithTitle:(NSString *)title descString:(NSString *)string
{
    UIAlertView *alert=[[UIAlertView alloc]initWithTitle:title
                                                 message:string
                                                delegate:nil
                                       cancelButtonTitle:@"确定"
                                       otherButtonTitles:nil, nil];
    [alert show];
}

#pragma mark--3级联动
-(void)clickChooseAddr
{
    //弹出pickView视图
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getThreeValue:) name:@"ThreeValues" object:nil];//所在地址
    NSMutableArray * arrayProvince = [[NSMutableArray alloc] init];
    NSMutableArray * arrayCity = [[NSMutableArray alloc] init];
    NSMutableArray * arrayArea = [[NSMutableArray alloc] init];
    [MeNetWorking getPersonInfoChooseCityCompletionHandler:^(MeInfoModel *model, NSError *error) {
        for (int i = 0; i<model.city.province.count; i++) {
            [arrayProvince addObject:model.city.province[i].name];
        }
        for (int i = 0; i<model.city.city.count; i++) {
            [arrayCity addObject:model.city.city[i].name];
        }
        for (int i = 0; i<model.city.area.count; i++) {
            [arrayArea addObject:model.city.area[i].name];
        }

        YLSThPickerView *picker = [[YLSThPickerView alloc]init];
        picker.array = @[arrayProvince,arrayCity,arrayArea];
        self.arrayData = picker.array;
        [picker show];
    }];
//    //弹出pickView视图
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(getThreeValue:) name:@"ThreeValues" object:nil];//所在地址
//    YLSThPickerView *picker = [[YLSThPickerView alloc]init];
//    picker.array = @[@[@"Mr",@"Mrs",@"Ms",@"Miss"],@[@"Funny",@"Cool",@"Hot",@"Wonderful",@"Raining",@"Happy",@"Super",@"Lazy",@"Amazing",@"Bat",@"Iron",@"Bat",@"Rocket",@"Pretty",@"Lex"],@[@"Man",@"Luthor",@"Boy",@"Girl",@"Person",@"Cutie",@"Babe",@"Raccoon"]];
//    NSLog(@"%@",picker.array);
//    self.arrayData = picker.array;
//    [picker show];
}
-(void)getThreeValue:(NSNotification *)notification
{
    _addrCell.infoTF.text = notification.object;
}
// returns the # of rows in each component.
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.arrayData count];
}

#pragma mark - 代理
// 返回第component列第row行的标题
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    return self.arrayData[row];
}

// 选中第component第row的时候调用
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    _addrCell.infoTF.text = self.arrayData[row];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

@end
