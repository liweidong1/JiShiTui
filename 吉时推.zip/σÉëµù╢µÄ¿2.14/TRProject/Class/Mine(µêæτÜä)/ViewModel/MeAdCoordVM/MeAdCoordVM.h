//
//  MeAdCoordVM.h
//  TRProject
//
//  Created by liweidong on 17/2/14.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"
@interface MeAdCoordVM : BaseViewModel

//UI决定
@property (nonatomic, readonly) NSInteger OneRowNumber;
@property (nonatomic, readonly) NSInteger TwoRowNumber;
@property (nonatomic, readonly) NSInteger ThreeRowNumber;
- (NSString *)OnetableViewText:(NSInteger)row;
- (NSString *)OnetableViewID:(NSInteger)row;

- (NSString *)TwotableViewText:(NSInteger)row;
- (NSString *)TwotableViewCid:(NSInteger)row;

- (NSString *)ThreetableViewText:(NSInteger)row;
- (NSString *)ThreetableViewSid:(NSInteger)row;
//- (NSString *)ThreetableViewCount:(NSInteger)row;
//根据model
@property (nonatomic) NSMutableArray<MeAdCoordCitysModel *> *oneList;
@property (nonatomic) NSMutableArray<MeAdCoordCoordModel *> *twoList;
@property (nonatomic) NSMutableArray<MeAdCoordShopModel *> *threeList;



@end
