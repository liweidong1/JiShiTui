//
//  MeAdCoordVM.m
//  TRProject
//
//  Created by liweidong on 17/2/14.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeAdCoordVM.h"

@implementation MeAdCoordVM

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    //需设置uid参数
    [MeNetWorking getAdCoordCompletionHandler:^(MeAdCoordModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.oneList removeAllObjects];
                [self.twoList removeAllObjects];
                [self.threeList removeAllObjects];
            }
            [self.oneList addObjectsFromArray:model.citys];
            [self.twoList addObjectsFromArray:model.citys[2].coord];
            [self.threeList addObjectsFromArray:model.citys[2].coord[1].shop];
            NSLog(@"%ld",self.oneList.count);
            NSLog(@"%ld",self.twoList.count);
            NSLog(@"%ld",self.threeList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}
//城市tableView
-(NSInteger)OneRowNumber
{
    return self.oneList.count;
}
- (NSString *)OnetableViewText:(NSInteger)row
{
    return self.oneList[row].name;
}
- (NSString *)OnetableViewID:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.oneList[row].ID];
}
//商圈tableView
-(NSInteger)TwoRowNumber
{
    return self.twoList.count;
}
-(NSString *)TwotableViewText:(NSInteger)row
{
    return self.twoList[row].sname;
}
-(NSString *)TwotableViewCid:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.twoList[row].cid];
}
//商家tableView
-(NSInteger)ThreeRowNumber
{
    return self.threeList.count;
}
-(NSString *)ThreetableViewText:(NSInteger)row
{
    return [NSString stringWithFormat:@"%@ %ld",self.threeList[row].title,self.threeList[row].count];
}
-(NSString *)ThreetableViewSid:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.threeList[row].sid];
}

- (NSMutableArray<MeAdCoordCitysModel *> *)oneList {
    if(_oneList == nil) {
        _oneList = [[NSMutableArray<MeAdCoordCitysModel *> alloc] init];
    }
    return _oneList;
}

- (NSMutableArray<MeAdCoordCoordModel *> *)twoList {
    if(_twoList == nil) {
        _twoList = [[NSMutableArray<MeAdCoordCoordModel *> alloc] init];
    }
    return _twoList;
}

- (NSMutableArray<MeAdCoordShopModel *> *)threeList {
    if(_threeList == nil) {
        _threeList = [[NSMutableArray<MeAdCoordShopModel *> alloc] init];
    }
    return _threeList;
}
@end
