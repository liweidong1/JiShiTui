//
//  MeOrderViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"


#import <UIKit/UIKit.h>
@class MeOrderCell,shopCarHeaderCell, UITableView;
@interface MeOrderViewModel : BaseViewModel

-(instancetype)initWithUid:(NSInteger )uid WithChildVC:(NSInteger)childVC;
@property(nonatomic,readonly) NSInteger uid;
@property (nonatomic, assign) NSInteger childVC;


- (NSString *)MeOrderSectionTitle:(NSInteger)section;
//根据model
@property (nonatomic) NSMutableArray<MeOrderUnpayModel *> *MeOrderSectionList;//待付款
@property (nonatomic) NSMutableArray<MeOrderPayModel *> *MeOrderDoneSectionList;//已付款
@property (nonatomic, readonly) NSInteger MeOrderSectionNumber;
- (NSInteger)numberOfItemsInSection:(NSInteger)section;
- (NSString *)titleForHeaderInSection:(NSInteger)section;

- (MeOrderCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath;

@property (nonatomic, assign) NSInteger page;




@end
