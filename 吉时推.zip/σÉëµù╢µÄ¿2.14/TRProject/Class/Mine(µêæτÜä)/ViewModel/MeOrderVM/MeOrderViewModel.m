//
//  MeOrderViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/17.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MeOrderViewModel.h"
#import "MeOrderCell.h"
@implementation MeOrderViewModel

- (instancetype)initWithUid:(NSInteger)uid WithChildVC:(NSInteger)childVC
{
    if (self = [super init]) {
        _uid = uid;
        _childVC = childVC;
    }
    return self;
    
}

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    //需设置uid参数
    [MeNetWorking getMeOrderWithUid:1 CompletionHandler:^(MeOrderModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.MeOrderSectionList removeAllObjects];
                [self.MeOrderDoneSectionList removeAllObjects];
            }
            [self.MeOrderSectionList addObjectsFromArray:model.unpay];
             [self.MeOrderDoneSectionList addObjectsFromArray:model.pay];
            NSLog(@"%ld",self.MeOrderSectionList.count);
            
        }
        !completionHandler ?: completionHandler(error);
    }];
}
/** 待付款数据-----通过传入的childVC值来判断-------已付款数据 */
//分区
- (NSInteger)MeOrderSectionNumber
{
    
    NSLog(@"%ld",self.MeOrderSectionList.count);
    if (_childVC == 0) {
        return self.MeOrderSectionList.count;
    }else {
        return self.MeOrderDoneSectionList.count;
    }
}
- (NSString *)MeOrderSectionTitle:(NSInteger)section
{
    if (_childVC == 0) {
    return self.MeOrderSectionList[section].title;
    }else {
    return self.MeOrderDoneSectionList[section].title;
    }

}
- (NSInteger)numberOfItemsInSection:(NSInteger)section
{
    if (_childVC == 0) {
        NSLog(@"%ld",self.MeOrderSectionList[section].product.count);
        return self.MeOrderSectionList[section].product.count;
    }else {
        return self.MeOrderDoneSectionList[section].product.count;
    }

}

- (MeOrderCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MeOrderCell *cell = [MeOrderCell cellWIthTableView:tableView];
    if (_childVC == 0) {
    cell.model = self.MeOrderSectionList[indexPath.section].product[indexPath.row];
    }else {
    cell.model = self.MeOrderDoneSectionList[indexPath.section].product[indexPath.row];
    }

    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 100;
}

- (NSString *)titleForHeaderInSection:(NSInteger)section
{

    if (_childVC == 0) {
    return self.MeOrderSectionList[section].title;
    }else {
    return self.MeOrderDoneSectionList[section].title;
    }
}
/** 已付款数据------------ */



- (NSMutableArray<MeOrderUnpayModel *> *)MeOrderSectionList {//待付款
    if(_MeOrderSectionList == nil) {
        _MeOrderSectionList = [[NSMutableArray<MeOrderUnpayModel *> alloc] init];
    }
    return _MeOrderSectionList;
}
- (NSMutableArray<MeOrderPayModel *> *)MeOrderDoneSectionList {//已付款
    if(_MeOrderDoneSectionList == nil) {
        _MeOrderDoneSectionList = [[NSMutableArray<MeOrderPayModel *> alloc] init];
    }
    return _MeOrderDoneSectionList;
}

@end
