//
//  MePayAttentionShopViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"
@interface MePayAttentionProductViewModel : BaseViewModel

//UI决定
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)gzProductIconURL:(NSInteger)row;
- (NSString *)gzProductTitle:(NSInteger)row;

- (NSInteger)gzProductSid:(NSInteger)row;

//根据model
//readonly可以保证某属性只有本身.m文件能修改,非本对象无法修改
@property (nonatomic, assign) NSInteger page;
@property (nonatomic) NSMutableArray<MePayAttentionProductGzModel *> *gzProductList;




@end
