//
//  MePayAttentionShopViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "MePayAttentionProductViewModel.h"

@implementation MePayAttentionProductViewModel
- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    [MeNetWorking getPayAttentionProductWithUid:1 CompletionHandler:^(MePayAttentionProductModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.gzProductList removeAllObjects];
            }
            [self.gzProductList addObjectsFromArray:model.gz];
            NSLog(@"%ld",self.gzProductList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}

/**
 *  VM数据
 *
 *  @return liweidong
 */
- (NSInteger)rowNumber
{
    NSLog(@"%ld",self.gzProductList.count);
    return self.gzProductList.count;
}
- (NSURL *)gzProductIconURL:(NSInteger)row
{
    return self.gzProductList[row].img.yx_URL;
}
- (NSString *)gzProductTitle:(NSInteger)row
{
    return self.gzProductList[row].title;
}
- (NSInteger)gzProductSid:(NSInteger)row
{
    return self.gzProductList[row].sid;
}

- (NSMutableArray<MePayAttentionProductGzModel *> *)gzProductList {
    if(_gzProductList == nil) {
        _gzProductList = [[NSMutableArray<MePayAttentionProductGzModel *> alloc] init];
    }
    return _gzProductList;
}
@end
