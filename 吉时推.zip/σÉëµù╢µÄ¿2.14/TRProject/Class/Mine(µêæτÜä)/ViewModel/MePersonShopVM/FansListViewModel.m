//
//  FansListViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansListViewModel.h"

@implementation FansListViewModel

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    [MeNetWorking getFansListWithUid:4 CompletionHandler:^(MeFansListModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.fansList removeAllObjects];
            }
            [self.fansList addObjectsFromArray:model.user];
            NSLog(@"%ld",self.fansList.count);
        }
        !completionHandler ?: completionHandler(error);
    }];
}

/**
 *  VM数据
 *
 *  @return liweidong
 */
- (NSInteger)rowNumber
{
    NSLog(@"%ld",self.fansList.count);
    return self.fansList.count;
}
- (NSURL *)fansListiconURL:(NSInteger)row
{
    return self.fansList[row].avatar.yx_URL;
}
- (NSString *)fansListNickName:(NSInteger)row
{
    return self.fansList[row].nickname;
}
- (NSString *)fansListPhone:(NSInteger)row
{
    return self.fansList[row].phone;
}
-(NSInteger)fansListFansUid:(NSInteger)row  //粉丝的uid
{
    return self.fansList[row].uid;
}


- (NSMutableArray<MeFansListUserModel *> *)fansList {
    if(_fansList == nil) {
        _fansList = [[NSMutableArray<MeFansListUserModel *> alloc] init];
    }
    return _fansList;
}
@end
