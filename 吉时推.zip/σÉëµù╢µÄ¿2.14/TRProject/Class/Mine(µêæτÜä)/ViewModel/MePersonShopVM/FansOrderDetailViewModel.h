//
//  FansOrderDetailViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"
@interface FansOrderDetailViewModel : BaseViewModel

-(instancetype)initWithFansUid:(NSInteger )fansUid;
@property(nonatomic,readonly) NSInteger fansUid;


//UI决定
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSString *)fansOrderName:(NSInteger)row;
- (NSString *)fansOrderTime:(NSInteger)row;
- (NSInteger)fansOrderMoney:(NSInteger)row;

//根据model
//readonly可以保证某属性只有本身.m文件能修改,非本对象无法修改
@property (nonatomic, assign) NSInteger page;
@property (nonatomic) NSMutableArray<FansOrderProductOrderModel *> *fansOrderList;

/**
 *  商品详情
 */
@property (nonatomic, readonly) NSInteger rowProductNumber;
- (NSURL *)fansProductImg:(NSInteger)rowProduct;
- (NSString *)fansProductName:(NSInteger)rowProduct;
- (NSString *)fansProductPrice:(NSInteger)rowProduct;
- (NSInteger)fansProductQuality:(NSInteger)rowProduct;
//根据model
@property (nonatomic) NSMutableArray<FansOrderProductProductModel *> *fansProductList;


@end
