//
//  FansOrderDetailViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/19.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "FansOrderDetailViewModel.h"

@implementation FansOrderDetailViewModel
- (instancetype)initWithFansUid:(NSInteger)fansUid
{
    if (self = [super init]) {
        _fansUid = fansUid;
    }
    return self;
}
- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    [MeNetWorking getFansOrderDetailWithFansId:_fansUid Uid:5 CompletionHandler:^(FansOrderProductModel *model, NSError *error) {
        if (!error) {
            NSLog(@"%ld",_fansUid);
            if (requestMode == RequestModeRefresh) {
                [self.fansOrderList removeAllObjects];
                [self.fansProductList removeAllObjects];
            }
            [self.fansOrderList addObjectsFromArray:model.order];
            //0为可变量，记录是哪一个订单分组
            [self.fansProductList addObjectsFromArray:model.order[0].product];
            NSLog(@"%ld",self.fansProductList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}

/**
 *  VM数据
 *
 *  @return liweidong
 */
- (NSInteger)rowNumber
{
    NSLog(@"%ld",self.fansOrderList.count);
    return self.fansOrderList.count;
}
- (NSString *)fansOrderName:(NSInteger)row
{
    return self.fansOrderList[row].order_number;
}
- (NSString *)fansOrderTime:(NSInteger)row
{
    return self.fansOrderList[row].pay_time;
}
-(NSInteger)fansOrderMoney:(NSInteger)row
{
    return self.fansOrderList[row].total;
}

- (NSMutableArray<FansOrderProductOrderModel *> *)fansOrderList {
    if(_fansOrderList == nil) {
        _fansOrderList = [[NSMutableArray<FansOrderProductOrderModel *> alloc] init];
    }
    return _fansOrderList;
}

/**
 *  商品详情
 *
 *  @return 李伟东
 */
- (NSInteger)rowProductNumber
{
    return self.fansProductList.count;
}
- (NSURL *)fansProductImg:(NSInteger)rowProduct
{
    return self.fansProductList[rowProduct].img.yx_URL;
}
- (NSString *)fansProductName:(NSInteger)rowProduct
{
    return self.fansProductList[rowProduct].title;
}
- (NSString *)fansProductPrice:(NSInteger)rowProduct
{
    if ((self.fansProductList[rowProduct].disprice = nil)) {
        return [NSString stringWithFormat:@"%ld",self.fansProductList[rowProduct].price];
    }else{
        return [NSString stringWithFormat:@"%ld",self.fansProductList[rowProduct].disprice];
    }
}
- (NSInteger)fansProductQuality:(NSInteger)rowProduct
{
    return self.fansProductList[rowProduct].count;
}
- (NSMutableArray<FansOrderProductProductModel *> *)fansProductList {
    if(_fansProductList == nil) {
        _fansProductList = [[NSMutableArray<FansOrderProductProductModel *> alloc] init];
    }
    return _fansProductList;
}
@end
