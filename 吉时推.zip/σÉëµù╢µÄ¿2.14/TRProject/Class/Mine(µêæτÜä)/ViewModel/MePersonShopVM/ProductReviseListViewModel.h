//
//  ProductReviseListViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"
@interface ProductReviseListViewModel : BaseViewModel
//UI决定
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)productReviseListiconURL:(NSInteger)row;
- (NSString *)productReviseListtitle:(NSInteger)row;

- (NSInteger)productReviseListPid:(NSInteger)row;

//根据model
//readonly可以保证某属性只有本身.m文件能修改,非本对象无法修改
@property (nonatomic, assign) NSInteger page;
@property (nonatomic) NSMutableArray<ProductReviseListProductModel *> *productReviseList;



@end
