//
//  ProductReviseListViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "ProductReviseListViewModel.h"

@implementation ProductReviseListViewModel


- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    [MeNetWorking getProductReviseListWithUid:1 CompletionHandler:^(ProductReviseListModel *model, NSError *error) {
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.productReviseList removeAllObjects];
            }
            [self.productReviseList addObjectsFromArray:model.product];
            NSLog(@"%ld",self.productReviseList.count);
        }
        !completionHandler ?: completionHandler(error);

    }];
}

/**
 *  VM数据
 *
 *  @return liweidong
 */
- (NSInteger)rowNumber
{
    NSLog(@"%ld",self.productReviseList.count);
    return self.productReviseList.count;
}
- (NSURL *)productReviseListiconURL:(NSInteger)row
{
    return self.productReviseList[row].img.yx_URL;
}
- (NSString *)productReviseListtitle:(NSInteger)row
{
    return self.productReviseList[row].title;
}
- (NSInteger)productReviseListPid:(NSInteger)row
{
    return self.productReviseList[row].pid;
}
- (NSMutableArray<ProductReviseListProductModel *> *)productReviseList {
    if(_productReviseList == nil) {
        _productReviseList = [[NSMutableArray<ProductReviseListProductModel *> alloc] init];
    }
    return _productReviseList;
}
@end
