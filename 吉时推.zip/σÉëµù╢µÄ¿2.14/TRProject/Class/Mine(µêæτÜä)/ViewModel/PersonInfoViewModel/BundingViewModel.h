//
//  BundingViewModel.h
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BaseViewModel.h"
#import "MeNetWorking.h"
@interface BundingViewModel : BaseViewModel


- (instancetype)initWithlngLat:(NSString *)Lat AndLng:(NSString *)Lng;
@property (nonatomic, readonly) NSString *Lat;
@property (nonatomic, readonly) NSString *Lng;


//UI决定
@property (nonatomic, readonly) NSInteger rowNumber;
- (NSURL *)bundingiconURL:(NSInteger)row;
- (NSString *)bundingtitle:(NSInteger)row;

- (NSString *)bundingdistance:(NSInteger)row;
- (NSString *)bundingdesc:(NSInteger)row;

- (NSString *)bundingBd:(NSInteger)row;//绑定人数

- (NSString *)bundingSid:(NSInteger)row;//绑定sid
//根据model
//readonly可以保证某属性只有本身.m文件能修改,非本对象无法修改
@property (nonatomic, assign) NSInteger page;
@property (nonatomic) NSMutableArray<MeProductBundingDataModel *> *bundingList;



@end
