//
//  BundingViewModel.m
//  TRProject
//
//  Created by liweidong on 17/1/18.
//  Copyright © 2017年 yingxin. All rights reserved.
//

#import "BundingViewModel.h"

@implementation BundingViewModel


- (instancetype)initWithlngLat:(NSString *)Lat AndLng:(NSString *)Lng
{
    self = [super init];
    if (self) {
        _Lat = Lat;
        _Lng = Lng;
    }
    return self;
}

- (void)getDataWithMode:(RequestMode)requestMode completionHandler:(void (^)(NSError *))completionHandler {
    NSInteger tmpStart = 1;
    if (requestMode == RequestModeMore) {
        tmpStart = _page + 1;
        
    }
    [MeNetWorking getPersonInfoBundingWithLat:_Lat Lng:_Lng Page:tmpStart CompletionHandler:^(MeProductBundingModel *model, NSError *error) {
        NSLog(@"%@,%@",_Lat,_Lng);
        NSLog(@"%ld",tmpStart);
        if (!error) {
            if (requestMode == RequestModeRefresh) {
                [self.bundingList removeAllObjects];
            }
            
            _page = tmpStart;
            [self.bundingList addObjectsFromArray:model.datas.data];
            NSLog(@"%ld",self.bundingList.count);
        }
        !completionHandler ?: completionHandler(error);
    }];
}

/**
 *  VM数据
 *
 *  @return liweidong
 */
- (NSInteger)rowNumber
{
    return self.bundingList.count;
}
- (NSURL *)bundingiconURL:(NSInteger)row
{
    return self.bundingList[row].img.yx_URL;
}
- (NSString *)bundingtitle:(NSInteger)row
{
    return self.bundingList[row].title;
}
- (NSString *)bundingdistance:(NSInteger)row
{
    return self.bundingList[row].juli;
}
- (NSString *)bundingdesc:(NSInteger)row
{
    return self.bundingList[row].descript;
}
-(NSString *)bundingBd:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.bundingList[row].bd];
}
- (NSString *)bundingSid:(NSInteger)row
{
    return [NSString stringWithFormat:@"%ld",self.bundingList[row].sid];
}
- (NSMutableArray<MeProductBundingDataModel *> *)bundingList {
    if(_bundingList == nil) {
        _bundingList = [[NSMutableArray<MeProductBundingDataModel *> alloc] init];
    }
    return _bundingList;
}
@end
