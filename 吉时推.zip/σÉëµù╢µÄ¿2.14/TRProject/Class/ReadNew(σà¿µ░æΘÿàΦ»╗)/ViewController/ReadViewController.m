//
//  ReadViewController.m
//  吉时推
//
//  Created by liweidong on 16/12/5.
//  Copyright © 2016年 Sillen. All rights reserved.
//

#import "ReadViewController.h"

@interface ReadViewController ()

@end

@implementation ReadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
        self.view.backgroundColor = [UIColor whiteColor];
}

@end
